--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.22
-- Dumped by pg_dump version 9.6.22

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE dbo.th_transaction ALTER COLUMN regid DROP DEFAULT;
ALTER TABLE dbo.th_order ALTER COLUMN regid DROP DEFAULT;
ALTER TABLE dbo.td_transaction_delete ALTER COLUMN regid DROP DEFAULT;
ALTER TABLE dbo.td_transaction ALTER COLUMN regid DROP DEFAULT;
ALTER TABLE dbo.td_order ALTER COLUMN regid DROP DEFAULT;
ALTER TABLE dbo.t_510_historyims ALTER COLUMN sysid DROP DEFAULT;
ALTER TABLE dbo.t_500_historyims ALTER COLUMN sysid DROP DEFAULT;
ALTER TABLE dbo.t_30_actmgr ALTER COLUMN sysid DROP DEFAULT;
ALTER TABLE dbo.m_vendor ALTER COLUMN regid DROP DEFAULT;
ALTER TABLE dbo.m_userrole ALTER COLUMN sysid DROP DEFAULT;
ALTER TABLE dbo.m_userg5 ALTER COLUMN sysid DROP DEFAULT;
ALTER TABLE dbo.m_user ALTER COLUMN regid DROP DEFAULT;
ALTER TABLE dbo.m_shift2 ALTER COLUMN sysid DROP DEFAULT;
ALTER TABLE dbo.m_qccheck ALTER COLUMN sysid DROP DEFAULT;
ALTER TABLE dbo.m_project ALTER COLUMN regid DROP DEFAULT;
ALTER TABLE dbo.m_productionprocess ALTER COLUMN sysid DROP DEFAULT;
ALTER TABLE dbo.m_product ALTER COLUMN regid DROP DEFAULT;
ALTER TABLE dbo.m_partner2 ALTER COLUMN id DROP DEFAULT;
ALTER TABLE dbo.m_partner ALTER COLUMN sysid DROP DEFAULT;
ALTER TABLE dbo.m_materialtype ALTER COLUMN regid DROP DEFAULT;
ALTER TABLE dbo.m_masterby ALTER COLUMN regid DROP DEFAULT;
ALTER TABLE dbo.m_machine ALTER COLUMN regid DROP DEFAULT;
ALTER TABLE dbo.m_location ALTER COLUMN sysid DROP DEFAULT;
ALTER TABLE dbo.m_line ALTER COLUMN idline DROP DEFAULT;
ALTER TABLE dbo.m_level ALTER COLUMN id_level DROP DEFAULT;
ALTER TABLE dbo.m_jabatan ALTER COLUMN regid DROP DEFAULT;
ALTER TABLE dbo.m_detailstatus ALTER COLUMN regid DROP DEFAULT;
ALTER TABLE dbo.m_detailict ALTER COLUMN sysid DROP DEFAULT;
ALTER TABLE dbo.m_department ALTER COLUMN id DROP DEFAULT;
ALTER TABLE dbo.m_customer ALTER COLUMN regid DROP DEFAULT;
ALTER TABLE dbo.m_childpart_conecting ALTER COLUMN sysid DROP DEFAULT;
ALTER TABLE dbo.m_category ALTER COLUMN id DROP DEFAULT;
ALTER TABLE dbo.m_addressdlv ALTER COLUMN sysid DROP DEFAULT;
ALTER TABLE dbo.loguser ALTER COLUMN sysid DROP DEFAULT;
ALTER TABLE dbo.g_docnummat ALTER COLUMN regid DROP DEFAULT;
ALTER TABLE dbo.d_comment ALTER COLUMN idcoment DROP DEFAULT;
ALTER TABLE dbo.cmproduct_bom ALTER COLUMN sysid DROP DEFAULT;
ALTER TABLE dbo.bomrm ALTER COLUMN sysid DROP DEFAULT;
ALTER TABLE dbo.bomchild ALTER COLUMN sysid DROP DEFAULT;
ALTER TABLE dbo.bombuild ALTER COLUMN sysid DROP DEFAULT;
DROP VIEW dbo.wipstock;
DROP SEQUENCE dbo.th_transaction_regid_seq;
DROP SEQUENCE dbo.th_order_regid_seq;
DROP TABLE dbo.th_order;
DROP SEQUENCE dbo.td_transaction_regid_seq;
DROP SEQUENCE dbo.td_transaction_delete_regid_seq;
DROP TABLE dbo.td_transaction_delete;
DROP SEQUENCE dbo.td_order_regid_seq;
DROP TABLE dbo.td_order;
DROP SEQUENCE dbo.t_510_historyims_sysid_seq;
DROP TABLE dbo.t_510_historyims;
DROP SEQUENCE dbo.t_500_historyims_sysid_seq;
DROP TABLE dbo.t_500_historyims;
DROP SEQUENCE dbo.t_30_actmgr_sysid_seq;
DROP TABLE dbo.t640_trc;
DROP TABLE dbo.t510_temp;
DROP TABLE dbo.t500_temp;
DROP TABLE dbo.t500_node;
DROP TABLE dbo.t500_lastact;
DROP TABLE dbo.t500_assource;
DROP TABLE dbo.t064_prtype;
DROP TABLE dbo.t040_addressdlv;
DROP VIEW dbo.sumrm;
DROP VIEW dbo.stocktr;
DROP VIEW dbo.stockict;
DROP VIEW dbo.stockga;
DROP VIEW dbo.scwip;
DROP VIEW dbo.scwip_ext;
DROP VIEW dbo.scwip_out;
DROP VIEW dbo.scwip_in;
DROP VIEW dbo.sctoolroom;
DROP VIEW dbo.sctoolroom_ext;
DROP VIEW dbo.sctoolroom_out;
DROP VIEW dbo.sctoolroom_in;
DROP VIEW dbo.scrawmaterial;
DROP VIEW dbo.scrawmaterial_ext;
DROP VIEW dbo.scmaterial_out;
DROP VIEW dbo.scict;
DROP VIEW dbo.scict_ext;
DROP VIEW dbo.scict_out;
DROP VIEW dbo.scict_in;
DROP VIEW dbo.scga;
DROP VIEW dbo.scga_ext;
DROP VIEW dbo.scga_out;
DROP VIEW dbo.scga_in;
DROP VIEW dbo.qtrace_docnum;
DROP TABLE dbo.t500_500;
DROP VIEW dbo.qth_transaction;
DROP VIEW dbo.qtd_transaction1;
DROP VIEW dbo.qrm_detailtrc;
DROP VIEW dbo.qproduction_detailtrc;
DROP VIEW dbo.qmaster_asset;
DROP VIEW dbo.qm_userrole;
DROP TABLE dbo.t_30_usergrpflow;
DROP TABLE dbo.t_30_actmgr;
DROP VIEW dbo.qm_childpart_conecting2;
DROP VIEW dbo.qm_childpart_conecting;
DROP VIEW dbo.qlist_qustomer;
DROP VIEW dbo.qcmproduct_bom2;
DROP VIEW dbo.qcmproduct_bom1;
DROP VIEW dbo.qcmproduct_bom;
DROP VIEW dbo.q_g2_proc_other;
DROP VIEW dbo.q_g2_proc;
DROP TABLE dbo.t510_proc;
DROP VIEW dbo.q_g1_proc;
DROP TABLE dbo.t500_proc;
DROP TABLE dbo.t064_prcategory;
DROP VIEW dbo.q_77_mledger_detail;
DROP VIEW dbo.q_77_mledger_cashbank;
DROP VIEW dbo.q610_jurnal;
DROP TABLE dbo.t_77_mledger_sub2;
DROP TABLE dbo.t_77_mledger_sub1;
DROP TABLE dbo.t_76_sledger;
DROP TABLE dbo.t610_trc;
DROP VIEW dbo.q106_fa_activity_inprogress;
DROP TABLE dbo.t106_fa_activity;
DROP TABLE dbo.t105_activitycategory;
DROP TABLE dbo.t101_groupasset;
DROP TABLE dbo.t100_fixedasset;
DROP VIEW dbo.q094_costcenterdetail;
DROP VIEW dbo.q093_costcenter;
DROP TABLE dbo.t093_costcenter;
DROP TABLE dbo.t015_department;
DROP VIEW dbo.q680_summarybudget;
DROP TABLE dbo.t680_trc;
DROP VIEW dbo.q094_costcenterdetail_sum;
DROP TABLE dbo.t094_costcenterdetail;
DROP VIEW dbo.q077_postcategory;
DROP TABLE dbo.t_77_mledger;
DROP TABLE dbo.t066_itemgroup;
DROP TABLE dbo.pr_doctype;
DROP TABLE dbo.mytable;
DROP VIEW dbo.monitoringrmlistcust;
DROP VIEW dbo.monitoringrm;
DROP VIEW dbo.monitoringrm_ext;
DROP VIEW dbo.rmstock;
DROP VIEW dbo.scmaterial_in;
DROP VIEW dbo.monitoringfglistcust;
DROP VIEW dbo.monitoringfg;
DROP VIEW dbo.warehousestock;
DROP VIEW dbo.warehousestock_ext;
DROP VIEW dbo.scwarehouse;
DROP VIEW dbo.scwarehouse_ext;
DROP VIEW dbo.scwarehouse_out;
DROP VIEW dbo.scwarehouse_in;
DROP VIEW dbo.qtd_transaction;
DROP TABLE dbo.th_transaction;
DROP TABLE dbo.td_transaction;
DROP TABLE dbo.t_connecting;
DROP VIEW dbo.q01_mproduct;
DROP TABLE dbo.t077_postcategory;
DROP VIEW dbo.qm_userg5;
DROP VIEW dbo.master_bom1;
DROP VIEW dbo.master_bom;
DROP SEQUENCE dbo.m_vendor_regid_seq;
DROP TABLE dbo.m_vendor;
DROP SEQUENCE dbo.m_userrole_sysid_seq;
DROP TABLE dbo.m_userrole;
DROP SEQUENCE dbo.m_userg5_sysid_seq;
DROP SEQUENCE dbo.m_user_regid_seq;
DROP TABLE dbo.m_unit;
DROP TABLE dbo.m_shipper;
DROP SEQUENCE dbo.m_shift2_sysid_seq;
DROP TABLE dbo.m_shift2;
DROP SEQUENCE dbo.m_qccheck_sysid_seq;
DROP TABLE dbo.m_qccheck;
DROP SEQUENCE dbo.m_project_regid_seq;
DROP TABLE dbo.m_project;
DROP SEQUENCE dbo.m_productionprocess_sysid_seq;
DROP TABLE dbo.m_productionprocess;
DROP SEQUENCE dbo.m_product_regid_seq;
DROP SEQUENCE dbo.m_partner_sysid_seq;
DROP SEQUENCE dbo.m_partner2_id_seq;
DROP TABLE dbo.m_partner2;
DROP SEQUENCE dbo.m_materialtype_regid_seq;
DROP TABLE dbo.m_materialtype;
DROP SEQUENCE dbo.m_masterby_regid_seq;
DROP TABLE dbo.m_masterby;
DROP SEQUENCE dbo.m_machine_regid_seq;
DROP SEQUENCE dbo.m_location_sysid_seq;
DROP TABLE dbo.m_location;
DROP SEQUENCE dbo.m_line_idline_seq;
DROP SEQUENCE dbo.m_level_id_level_seq;
DROP SEQUENCE dbo.m_jabatan_regid_seq;
DROP TABLE dbo.m_jabatan;
DROP SEQUENCE dbo.m_detailstatus_regid_seq;
DROP SEQUENCE dbo.m_detailict_sysid_seq;
DROP TABLE dbo.m_detailict;
DROP SEQUENCE dbo.m_department_id_seq;
DROP VIEW dbo.m_custwip;
DROP VIEW dbo.m_custwarehouse;
DROP SEQUENCE dbo.m_customer_regid_seq;
DROP TABLE dbo.m_customer;
DROP VIEW dbo.m_custmaterial;
DROP TABLE dbo.m_product;
DROP TABLE dbo.m_partner;
DROP TABLE dbo.m_currency;
DROP SEQUENCE dbo.m_childpart_conecting_sysid_seq;
DROP TABLE dbo.m_childpart_conecting;
DROP SEQUENCE dbo.m_category_id_seq;
DROP TABLE dbo.m_category;
DROP TABLE dbo.m_bank;
DROP TABLE dbo.m_assetict;
DROP TABLE dbo.m_asset;
DROP SEQUENCE dbo.m_addressdlv_sysid_seq;
DROP TABLE dbo.m_addressdlv;
DROP SEQUENCE dbo.loguser_sysid_seq;
DROP TABLE dbo.loguser;
DROP VIEW dbo.listpictr;
DROP TABLE dbo.m_userg5;
DROP TABLE dbo.lastact;
DROP VIEW dbo.imsuser;
DROP TABLE dbo.m_user;
DROP TABLE dbo.m_level;
DROP TABLE dbo.m_detailstatus;
DROP TABLE dbo.m_department;
DROP SEQUENCE dbo.g_docnummat_regid_seq;
DROP TABLE dbo.g_docnummat;
DROP VIEW dbo.detailmachine;
DROP TABLE dbo.m_machine;
DROP TABLE dbo.m_line;
DROP SEQUENCE dbo.d_comment_idcoment_seq;
DROP TABLE dbo.d_comment;
DROP SEQUENCE dbo.cmproduct_bom_sysid_seq;
DROP TABLE dbo.cmproduct_bom;
DROP SEQUENCE dbo.bomrm_sysid_seq;
DROP TABLE dbo.bomrm;
DROP SEQUENCE dbo.bomchild_sysid_seq;
DROP TABLE dbo.bomchild;
DROP SEQUENCE dbo.bombuild_sysid_seq;
DROP TABLE dbo.bombuild;
DROP TABLE dbo.bom6;
DROP TABLE dbo.bom5;
DROP TABLE dbo.bom4;
DROP TABLE dbo.bom3;
DROP TABLE dbo.bom2;
DROP TABLE dbo.bom1;
DROP TABLE dbo.actionbutton;
DROP FUNCTION dbo.splitstring(stringtosplit character varying);
DROP FUNCTION dbo.schedule(startdate date, trctypeid bigint, partnerid bigint);
DROP FUNCTION dbo.production(startdate date, trctypeid bigint, partnerid bigint);
DROP FUNCTION dbo."StatusReturn"(partnerid bigint, itemid bigint);
DROP FUNCTION dbo."FindMonitoring"(partner bigint, deliverydate date, inputdate date, inputtime time without time zone);
DROP EXTENSION plpgsql;
DROP SCHEMA public;
DROP SCHEMA guest;
DROP SCHEMA dbo;
--
-- Name: dbo; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA dbo;


ALTER SCHEMA dbo OWNER TO postgres;

--
-- Name: guest; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA guest;


ALTER SCHEMA guest OWNER TO postgres;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: FindMonitoring(bigint, date, date, time without time zone); Type: FUNCTION; Schema: dbo; Owner: postgres
--

CREATE FUNCTION dbo."FindMonitoring"(partner bigint, deliverydate date, inputdate date, inputtime time without time zone) RETURNS TABLE(linkid character varying, child character varying, level integer, itemid bigint, partno character varying, num character varying, parttype character varying, supplierid bigint, fglocation character varying, partnername character varying, itemno integer, code character varying, custname character varying, projectname character varying, materialtype bigint, partname character varying, totalp double precision, regid bigint, partnerid bigint, qtypercar double precision, assy double precision, wip double precision, spot_gun double precision, robot double precision, linea double precision, linebc double precision, pcstock double precision, qgate double precision, handwork double precision, pressline double precision, rawmat double precision, totalall double precision, onprocess text)
    LANGUAGE plpgsql
    AS $$
DECLARE
    retFindReports record;
BEGIN  
RETURN QUERY
WITH rel_tree (LinkID,Child,level,ItemID,PartNo,num,PartType,SupplierID,MaterialType,ItemNo,FGLocation,Code,CustName,ProjectName,PartName) -- CTE name and columns  
    AS (  
        SELECT a.SysID AS LinkID,CAST(a.SysID AS VARCHAR) AS Child,0 AS level,CAST(0 AS BIGINT) AS ItemID,a.PartNo
            ,CAST(a.SysID AS VARCHAR) AS num, a.PartTypeID AS PartType,CAST(0 AS BIGINT) AS SupplierID,CAST(0 AS BIGINT) AS MaterialType
            ,ROW_NUMBER() OVER(ORDER BY a.SysID ASC) as ItemNo,a.FGLocation,b.Code,b.CustName,c.ProjectName
            ,a.PartName
        FROM BOM1 a
        LEFT JOIN M_Customer b ON b.RegID = a.IDCust
        LEFT JOIN M_Project c ON c.RegID = a.IDProject
        WHERE a.IDCust = Partner AND a.IsDelete = 0
        UNION ALL
        SELECT b.LinkID,CAST('0' AS VARCHAR) as Child,level+1,a.ItemID,a.PartNo
            ,CAST(CAST(p.num AS VARCHAR)||'-'||CAST(a.ItemID AS VARCHAR) AS VARCHAR) AS num
            ,a.PartType,a.SupplierID,a.MaterialType
            ,p.ItemNo,a.FGLocation,p.Code,p.CustName,p.ProjectName
            ,a.PartName
        FROM BOMBuild b
        JOIN BOM2 a ON a.ItemID = b.ItemID
        INNER JOIN rel_tree p ON p.Child = b.LinkID
        UNION ALL
        SELECT CAST(p.LinkID AS VARCHAR) AS LinkID,CAST('0' AS VARCHAR) AS Child,level+1,l.ItemID,l.PartNo
            ,CAST(CAST(p.num AS VARCHAR)||'-'||CAST(k.SysID AS VARCHAR) AS VARCHAR) AS num
            ,l.PartType,l.SupplierID,l.MaterialType
            ,p.ItemNo,l.FGLocation,p.Code,p.CustName,p.ProjectName
            ,l.PartName
        FROM BOMChild k
        JOIN BOM2 l ON l.ItemID = k.ItemChild
        INNER JOIN rel_tree p ON p.ItemID = k.ItemID
        )  
-- copy the required columns to the result of the function   
--    INSERT retFindReports  
    SELECT x.LinkID,x.Child,x.level,x.ItemID,x.PartNo,x.num,x.PartType,x.SupplierID
          ,x.FGLocation,c.PartnerName,x.ItemNo
          ,x.Code,x.CustName,x.ProjectName,x.MaterialType,x.PartName, SUM(j.Qty) as TotalP,i.RegID,PartnerID as PartnerID
          , (CASE WHEN isnull(y.QtyPerCar,0) = 0 THEN 1 ELSE y.QtyPerCar END) AS QtyPerCar
          , SUM(k.assy) as assy, SUM(k.wip) as wip, SUM(k.spot_gun) as spot_gun, SUM(k.robot) as robot, SUM(k.lineA) as lineA, SUM(k.lineBC) as lineBC
          , SUM(k.PCStock) as PCStock, SUM(k.QGate) as QGate, SUM(k.Handwork) as Handwork, SUM(k.PressLine) as PressLine, SUM(k.RawMat) as RawMat, SUM(k.TotalAll) as TotalAll
          , CAST(z.OnProcess as varchar(250)) as OnProcess
    FROM rel_tree x
    LEFT JOIN BOM2 y ON y.ItemID = x.ItemID
    LEFT JOIN BOM3 z ON z.ItemID = x.ItemID
    LEFT JOIN M_Partner c ON c.SysID = x.SupplierID 
    INNER JOIN CMProduct_BOM h ON h.ItemID_BOM = (CASE WHEN x.ItemID = 0 THEN x.LinkID ELSE CAST(x.ItemID as varchar(50)) END) -- 
    JOIN M_Product i ON i.RegID = h.ItemID_Product AND i.IDCust = PartnerID
    LEFT JOIN TD_Order j ON j.TrcTypeID = 423 AND j.ItemID = i.RegID AND j.IsDelete = 0 AND cast(j.DeliveryDate as date) = cast(DeliveryDate as date)
    LEFT JOIN 
    (
      SELECT b.ItemID,a.FromAreaID
          , CASE WHEN a.FromAreaID = 1 THEN SUM(b.Qty_1) ELSE 0 END AS assy
          , CASE WHEN a.FromAreaID = 2 THEN SUM(b.Qty_1) ELSE 0 END AS wip
          , CASE WHEN a.FromAreaID = 3 THEN SUM(b.Qty_1) ELSE 0 END AS spot_gun
          , CASE WHEN a.FromAreaID = 4 THEN SUM(b.Qty_1) ELSE 0 END AS robot
          , CASE WHEN a.FromAreaID = 5 THEN SUM(b.Qty_1) ELSE 0 END AS lineA
          , CASE WHEN a.FromAreaID = 6 THEN SUM(b.Qty_1) ELSE 0 END AS lineBC
          , CASE WHEN a.FromAreaID = 7 THEN SUM(b.Qty_1) ELSE 0 END AS PCStock
          , CASE WHEN a.FromAreaID = 8 THEN SUM(b.Qty_1) ELSE 0 END AS QGate
          , CASE WHEN a.FromAreaID = 9 THEN SUM(b.Qty_1) ELSE 0 END AS Handwork
          , CASE WHEN a.FromAreaID = 10 THEN SUM(b.Qty_1) ELSE 0 END AS PressLine
          , CASE WHEN a.FromAreaID = 11 THEN SUM(b.Qty_1) ELSE 0 END AS RawMat
          , SUM(b.Qty_1) as TotalAll
      FROM
          TH_Transaction a
      JOIN 
          TD_Transaction b ON b.TrcTypeID = a.TrcTypeID AND b.MonthID = a.MonthID AND b.TrcID = a.TrcID AND CAST (b.IsDelete AS INT) = 0
      WHERE a.TrcTypeID = 2017 AND (cast(a.DocDate as date) = cast(InputDate as date) AND cast(a.DocTime as time) <= cast(InputTime as time) AND cast(a.DocDate_Ext as date) = cast(DeliveryDate as date))
      GROUP BY b.ItemID,a.FromAreaID
    ) k ON k.ItemID = i.RegID 
    WHERE x.PartType NOT LIKE 'RM%' 
    GROUP BY x.LinkID,x.Child,x.level,x.ItemID,x.PartNo,x.num,x.PartType,x.SupplierID
      ,x.FGLocation,c.PartnerName,x.ItemNo
      ,x.Code,x.CustName,x.ProjectName,x.MaterialType,x.PartName,i.RegID,y.QtyPerCar,CAST(z.OnProcess as varchar(250))
    ORDER BY x.num;
--   RETURN;
END;
$$;


ALTER FUNCTION dbo."FindMonitoring"(partner bigint, deliverydate date, inputdate date, inputtime time without time zone) OWNER TO postgres;

--
-- Name: StatusReturn(bigint, bigint); Type: FUNCTION; Schema: dbo; Owner: postgres
--

CREATE FUNCTION dbo."StatusReturn"(partnerid bigint, itemid bigint) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
    DECLARE 
    status VARCHAR(250);
 BEGIN
    status := partnerid;
	/*
    SET Work = REPLACE(Work, 'www.', '')
    SET Work = REPLACE(Work, '.com', '')
	*/
   RETURN status;
END; $$;


ALTER FUNCTION dbo."StatusReturn"(partnerid bigint, itemid bigint) OWNER TO postgres;

--
-- Name: production(date, bigint, bigint); Type: FUNCTION; Schema: dbo; Owner: postgres
--

CREATE FUNCTION dbo.production(startdate date, trctypeid bigint, partnerid bigint) RETURNS TABLE(itemid bigint, partno character varying, partname character varying, tgl1d bigint, tgl1n bigint, tgl2d bigint, tgl2n bigint, tgl3d bigint, tgl3n bigint, tgl4d bigint, tgl4n bigint, tgl5d bigint, tgl5n bigint, tgl6d bigint, tgl6n bigint)
    LANGUAGE plpgsql
    AS $$
DECLARE
    rtTable record;
begin
	-- SELECT * FROM dbo.production('2017/09/19',423,745)
    insert into rtTable
    SELECT t1.ItemID,t1.PartNo,t1.PartName,SUM(t1.tgl1d) as tgl1d,SUM(t1.tgl1n) as tgl1n,
    	SUM(t1.tgl2d) as tgl2d,SUM(t1.tgl2n) as tgl2n,SUM(t1.tgl3d) as tgl3d,SUM(t1.tgl3n) as tgl3n,SUM(t1.tgl4d) as tgl4d,
    	SUM(t1.tgl4n) as tgl4n,SUM(t1.tgl5d) as tgl5d,SUM(t1.tgl5n) as tgl5n,SUM(t1.tgl6d) as tgl6d,SUM(t1.tgl6n) as tgl6n
    FROM (
      SELECT a.ItemID,c.PartNo, c.PartName
        ,CASE WHEN (a.Cycle = 1 OR a.Cycle = 3) AND CAST(DATEADD(Day, -2, a.DeliveryDate) AS DATE) = CAST(startdate AS DATE) THEN SUM(a.Qty)
        ELSE 0 END AS tgl1d
        ,CASE WHEN (a.Cycle = 5 OR a.Cycle = 7) AND CAST(DATEADD(Day, -2, a.DeliveryDate) AS DATE) = CAST(startdate AS DATE) THEN SUM(a.Qty)
        ELSE 0 END AS tgl1n
        ,CASE WHEN (a.Cycle = 1 OR a.Cycle = 3) AND CAST(DATEADD(Day, -2, a.DeliveryDate) AS DATE) = CAST(DATEADD(Day, 1, startdate) AS DATE) THEN SUM(a.Qty)
        ELSE 0 END AS tgl2d
        ,CASE WHEN (a.Cycle = 5 OR a.Cycle = 7) AND CAST(DATEADD(Day, -2, a.DeliveryDate) AS DATE) = CAST(DATEADD(Day, 1, startdate) AS DATE) THEN SUM(a.Qty)
        ELSE 0 END AS tgl2n
        ,CASE WHEN (a.Cycle = 1 OR a.Cycle = 3) AND CAST(DATEADD(Day, -2, a.DeliveryDate) AS DATE) = CAST(DATEADD(Day, 2, startdate) AS DATE) THEN SUM(a.Qty)
        ELSE 0 END AS tgl3d
        ,CASE WHEN (a.Cycle = 5 OR a.Cycle = 7) AND CAST(DATEADD(Day, -2, a.DeliveryDate) AS DATE) = CAST(DATEADD(Day, 2, startdate) AS DATE) THEN SUM(a.Qty)
        ELSE 0 END AS tgl3n
        ,CASE WHEN (a.Cycle = 1 OR a.Cycle = 3) AND CAST(DATEADD(Day, -2, a.DeliveryDate) AS DATE) = CAST(DATEADD(Day, 3, startdate) AS DATE) THEN SUM(a.Qty)
        ELSE 0 END AS tgl4d
        ,CASE WHEN (a.Cycle = 5 OR a.Cycle = 7) AND CAST(DATEADD(Day, -2, a.DeliveryDate) AS DATE) = CAST(DATEADD(Day, 3, startdate) AS DATE) THEN SUM(a.Qty)
        ELSE 0 END AS tgl4n
        ,CASE WHEN (a.Cycle = 1 OR a.Cycle = 3) AND CAST(DATEADD(Day, -2, a.DeliveryDate) AS DATE) = CAST(DATEADD(Day, 4, startdate) AS DATE) THEN SUM(a.Qty)
        ELSE 0 END AS tgl5d
        ,CASE WHEN (a.Cycle = 5 OR a.Cycle = 7) AND CAST(DATEADD(Day, -2, a.DeliveryDate) AS DATE) = CAST(DATEADD(Day, 4, startdate) AS DATE) THEN SUM(a.Qty)
        ELSE 0 END AS tgl5n
        ,CASE WHEN (a.Cycle = 1 OR a.Cycle = 3) AND CAST(DATEADD(Day, -2, a.DeliveryDate) AS DATE) = CAST(DATEADD(Day, 5, startdate) AS DATE) THEN SUM(a.Qty)
        ELSE 0 END AS tgl6d
        ,CASE WHEN (a.Cycle = 5 OR a.Cycle = 7) AND CAST(DATEADD(Day, -2, a.DeliveryDate) AS DATE) = CAST(DATEADD(Day, 5, startdate) AS DATE) THEN SUM(a.Qty)
        ELSE 0 END AS tgl6n
      FROM TD_Order a 
      JOIN M_Vendor b ON b.RegID = a.VendorID 
      JOIN M_Product c ON c.RegID = a.ItemID 
      JOIN M_UserG5 d ON d.SysID = a.UserID 
      JOIN TH_Order e ON e.TrcTypeID = a.TrcTypeID AND e.MonthID = a.MonthID AND e.TrcID = a.TrcID 
      WHERE a.TrcTypeID = TrcTypeID AND a.IsDelete = 0 AND a.PartnerID = PartnerID AND CAST(DATEADD(Day, -2, a.DeliveryDate) AS DATE) BETWEEN CAST(startdate AS DATE) AND CAST(DATEADD(Day, 5, startdate) AS DATE)
      GROUP BY c.PartNo, c.PartName, a.ItemID, a.PONum, a.Cycle,a.DeliveryDate
      ) t1
      GROUP BY t1.ItemID,t1.PartNo,t1.PartName
      ORDER BY t1.PartName;
return;
end;
$$;


ALTER FUNCTION dbo.production(startdate date, trctypeid bigint, partnerid bigint) OWNER TO postgres;

--
-- Name: schedule(date, bigint, bigint); Type: FUNCTION; Schema: dbo; Owner: postgres
--

CREATE FUNCTION dbo.schedule(startdate date, trctypeid bigint, partnerid bigint) RETURNS TABLE(itemid bigint, partno character varying, partname character varying, acycle1 bigint, acycle3 bigint, acycle5 bigint, acycle7 bigint, bcycle1 bigint, bcycle3 bigint, bcycle5 bigint, bcycle7 bigint, ccycle1 bigint, ccycle3 bigint, ccycle5 bigint, ccycle7 bigint, dcycle1 bigint, dcycle3 bigint, dcycle5 bigint, dcycle7 bigint, ecycle1 bigint, ecycle3 bigint, ecycle5 bigint, ecycle7 bigint, fcycle1 bigint, fcycle3 bigint, fcycle5 bigint, fcycle7 bigint)
    LANGUAGE plpgsql
    AS $$
DECLARE
    rtTable record;
begin
	-- SELECT * FROM dbo.schedule('9/23/2017',423,745);
    insert into rtTable
    SELECT t1.ItemID,t1.PartNo, t1.PartName, SUM(t1.acycle1) as acycle1, SUM(t1.acycle3) as acycle3
	    , SUM(t1.acycle5) as acycle5, SUM(t1.acycle7) as acycle7, SUM(t1.bcycle1) as bcycle1, SUM(t1.bcycle3) as bcycle3
        , SUM(t1.bcycle5) as bcycle5, SUM(t1.bcycle7) as bcycle7, SUM(t1.ccycle1) as ccycle1, SUM(t1.ccycle3) as ccycle3
        , SUM(t1.ccycle5) as ccycle5, SUM(t1.ccycle7) as ccycle7, SUM(t1.dcycle1) as dcycle1, SUM(t1.dcycle3) as dcycle3
        , SUM(t1.dcycle5) as dcycle5, SUM(t1.dcycle7) as dcycle7, SUM(t1.ecycle1) as ecycle1, SUM(t1.ecycle3) as ecycle3
        , SUM(t1.ecycle5) as ecycle5, SUM(t1.ecycle7) as ecycle7, SUM(t1.fcycle1) as fcycle1, SUM(t1.fcycle3) as fcycle3
        , SUM(t1.fcycle5) as fcycle5, SUM(t1.fcycle7) as fcycle7
    FROM
    (
      SELECT a.ItemID,c.PartNo, c.PartName, a.DeliveryDate
        ,CASE WHEN a.Cycle = 1 AND CAST(a.DeliveryDate AS DATE) = CAST(startdate AS DATE) THEN SUM(a.Qty)
        ELSE 0 END AS acycle1
        ,CASE WHEN a.Cycle = 3 AND CAST(a.DeliveryDate AS DATE) = CAST(startdate AS DATE) THEN SUM(a.Qty)
        ELSE 0 END AS acycle3
        ,CASE WHEN a.Cycle = 5 AND CAST(a.DeliveryDate AS DATE) = CAST(startdate AS DATE) THEN SUM(a.Qty)
        ELSE 0 END AS acycle5
        ,CASE WHEN a.Cycle = 7 AND CAST(a.DeliveryDate AS DATE) = CAST(startdate AS DATE) THEN SUM(a.Qty)
        ELSE 0 END AS acycle7
        ,CASE WHEN a.Cycle = 1 AND a.DeliveryDate = DATEADD(Day, 1, startdate) THEN SUM(a.Qty)
        ELSE 0 END AS bcycle1
        ,CASE WHEN a.Cycle = 3 AND a.DeliveryDate = DATEADD(Day, 1, startdate) THEN SUM(a.Qty)
        ELSE 0 END AS bcycle3
        ,CASE WHEN a.Cycle = 5 AND a.DeliveryDate = DATEADD(Day, 1, startdate) THEN SUM(a.Qty)
        ELSE 0 END AS bcycle5
        ,CASE WHEN a.Cycle = 7 AND a.DeliveryDate = DATEADD(Day, 1, startdate) THEN SUM(a.Qty)
        ELSE 0 END AS bcycle7
        ,CASE WHEN a.Cycle = 1 AND a.DeliveryDate = DATEADD(Day, 2, startdate) THEN SUM(a.Qty)
        ELSE 0 END AS ccycle1
        ,CASE WHEN a.Cycle = 3 AND a.DeliveryDate = DATEADD(Day, 2, startdate) THEN SUM(a.Qty)
        ELSE 0 END AS ccycle3
        ,CASE WHEN a.Cycle = 5 AND a.DeliveryDate = DATEADD(Day, 2, startdate) THEN SUM(a.Qty)
        ELSE 0 END AS ccycle5
        ,CASE WHEN a.Cycle = 7 AND a.DeliveryDate = DATEADD(Day, 2, startdate) THEN SUM(a.Qty)
        ELSE 0 END AS ccycle7
        ,CASE WHEN a.Cycle = 1 AND a.DeliveryDate = DATEADD(Day, 3, startdate) THEN SUM(a.Qty)
        ELSE 0 END AS dcycle1
        ,CASE WHEN a.Cycle = 3 AND a.DeliveryDate = DATEADD(Day, 3, startdate) THEN SUM(a.Qty)
        ELSE 0 END AS dcycle3
        ,CASE WHEN a.Cycle = 5 AND a.DeliveryDate = DATEADD(Day, 3, startdate) THEN SUM(a.Qty)
        ELSE 0 END AS dcycle5
        ,CASE WHEN a.Cycle = 7 AND a.DeliveryDate = DATEADD(Day, 3, startdate) THEN SUM(a.Qty)
        ELSE 0 END AS dcycle7
        ,CASE WHEN a.Cycle = 1 AND a.DeliveryDate = DATEADD(Day, 4, startdate) THEN SUM(a.Qty)
        ELSE 0 END AS ecycle1
        ,CASE WHEN a.Cycle = 3 AND a.DeliveryDate = DATEADD(Day, 4, startdate) THEN SUM(a.Qty)
        ELSE 0 END AS ecycle3
        ,CASE WHEN a.Cycle = 5 AND a.DeliveryDate = DATEADD(Day, 4, startdate) THEN SUM(a.Qty)
        ELSE 0 END AS ecycle5
        ,CASE WHEN a.Cycle = 7 AND a.DeliveryDate = DATEADD(Day, 4, startdate) THEN SUM(a.Qty)
        ELSE 0 END AS ecycle7
        ,CASE WHEN a.Cycle = 1 AND a.DeliveryDate = DATEADD(Day, 5, startdate) THEN SUM(a.Qty)
        ELSE 0 END AS fcycle1
        ,CASE WHEN a.Cycle = 3 AND a.DeliveryDate = DATEADD(Day, 5, startdate) THEN SUM(a.Qty)
        ELSE 0 END AS fcycle3
        ,CASE WHEN a.Cycle = 5 AND a.DeliveryDate = DATEADD(Day, 5, startdate) THEN SUM(a.Qty)
        ELSE 0 END AS fcycle5
        ,CASE WHEN a.Cycle = 7 AND a.DeliveryDate = DATEADD(Day, 5, startdate) THEN SUM(a.Qty)
        ELSE 0 END AS fcycle7
      FROM TD_Order a 
      JOIN M_Vendor b ON b.RegID = a.VendorID 
      JOIN M_Product c ON c.RegID = a.ItemID 
      JOIN M_UserG5 d ON d.SysID = a.UserID 
      JOIN TH_Order e ON e.TrcTypeID = a.TrcTypeID AND e.MonthID = a.MonthID AND e.TrcID = a.TrcID 
      WHERE a.TrcTypeID = TrcTypeID AND a.IsDelete = 0 AND a.PartnerID = PartnerID AND a.DeliveryDate BETWEEN CAST(startdate AS DATE) AND CAST(DATEADD(Day, 5, startdate) AS DATE)
      GROUP BY c.PartNo, c.PartName, a.ItemID, a.Cycle, a.DeliveryDate
    ) t1
    GROUP BY t1.ItemID,t1.PartNo, t1.PartName
    ORDER BY t1.PartName;
return;
end;
$$;


ALTER FUNCTION dbo.schedule(startdate date, trctypeid bigint, partnerid bigint) OWNER TO postgres;

--
-- Name: splitstring(character varying); Type: FUNCTION; Schema: dbo; Owner: postgres
--

CREATE FUNCTION dbo.splitstring(stringtosplit character varying) RETURNS TABLE(name character varying)
    LANGUAGE plpgsql
    AS $$
 -- SELECT * FROM dbo.splitstring('Driver|Section')
DECLARE 
    name VARCHAR(250);
    pos INT;
BEGIN

 WHILE (CHARINDEX('|', stringToSplit) > 0)
   LOOP
     BEGIN
      SELECT pos  = CHARINDEX('|', stringToSplit);
      SELECT name = SUBSTRING(stringToSplit, 1, pos-1);

      INSERT INTO returnList 
      SELECT name;

      SELECT stringToSplit = SUBSTRING(stringToSplit, pos+1, LEN(stringToSplit)-pos);
     END;
 END LOOP;
 INSERT INTO returnList
 SELECT stringToSplit;

 RETURN;
END;
$$;


ALTER FUNCTION dbo.splitstring(stringtosplit character varying) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: actionbutton; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.actionbutton (
    sysid bigint,
    description character varying(50),
    docdate date,
    status boolean,
    countx double precision
);


ALTER TABLE dbo.actionbutton OWNER TO postgres;

--
-- Name: bom1; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.bom1 (
    sysid character varying(50),
    itemno bigint,
    partno character varying(150),
    partname character varying(250),
    idcust bigint,
    image character varying(100),
    idproject bigint,
    packingtype character varying(50),
    parttypeid character varying(5),
    stdpack double precision,
    fglocation character varying(50),
    qtypercar double precision,
    supplierid bigint,
    createby bigint,
    isactive boolean DEFAULT true,
    isdelete boolean DEFAULT false,
    nametype integer
);


ALTER TABLE dbo.bom1 OWNER TO postgres;

--
-- Name: bom2; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.bom2 (
    sysid character varying(50),
    itemno bigint,
    itemnosub bigint,
    nourut bigint,
    linkid character varying(50),
    partno character varying(150),
    partname character varying(250),
    levelpart bigint,
    parttype character varying(5),
    qtypercar double precision,
    supplierid bigint,
    spec character varying(50),
    thick double precision,
    width double precision,
    length double precision,
    pcspersheet double precision,
    kgpersheet double precision,
    partweight double precision,
    pcsperday double precision,
    materialtype bigint,
    fglocation character varying(50),
    packingtype character varying(50),
    stdpack double precision,
    isactivedetail boolean DEFAULT true,
    isdeletedetail boolean DEFAULT false,
    specorder1 character varying(60),
    specorder2 character varying(70),
    qtypart double precision,
    ratio double precision,
    iscommon boolean DEFAULT false,
    partno_ext character varying(150),
    partname_ext character varying(150),
    iscommongroup boolean DEFAULT false,
    groupcommonid character varying(50),
    nametype integer,
    itemid bigint,
    partno2 character varying(150),
    isrhlh boolean DEFAULT false,
    images character varying(50)
);


ALTER TABLE dbo.bom2 OWNER TO postgres;

--
-- Name: bom3; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.bom3 (
    sysid character varying(50),
    linkid character varying(50),
    op5m character varying(50),
    op10m character varying(50),
    op20m character varying(50),
    op30m character varying(50),
    op40m character varying(50),
    op50m character varying(50),
    op60m character varying(50),
    op70m character varying(50),
    itemid bigint,
    onprocess text
);


ALTER TABLE dbo.bom3 OWNER TO postgres;

--
-- Name: bom4; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.bom4 (
    sysid character varying(50),
    linkid character varying(50),
    op5 character varying(50),
    op10 character varying(50),
    op20 character varying(50),
    op30 character varying(50),
    op40 character varying(50),
    op50 character varying(50),
    op60 character varying(50),
    op70 character varying(50),
    category character varying(25),
    itemid bigint
);


ALTER TABLE dbo.bom4 OWNER TO postgres;

--
-- Name: bom5; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.bom5 (
    sysid character varying(50),
    linkid character varying(50),
    processassy character varying(50),
    lineassy character varying(50),
    itemid bigint
);


ALTER TABLE dbo.bom5 OWNER TO postgres;

--
-- Name: bom6; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.bom6 (
    sysid character varying(5),
    parttype character varying(50),
    remark character varying(150)
);


ALTER TABLE dbo.bom6 OWNER TO postgres;

--
-- Name: bombuild; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.bombuild (
    sysid integer NOT NULL,
    linkid character varying(50),
    itemid bigint,
    createby bigint,
    createdate date,
    createtime time without time zone,
    isdelete boolean DEFAULT false
);


ALTER TABLE dbo.bombuild OWNER TO postgres;

--
-- Name: bombuild_sysid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.bombuild_sysid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.bombuild_sysid_seq OWNER TO postgres;

--
-- Name: bombuild_sysid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.bombuild_sysid_seq OWNED BY dbo.bombuild.sysid;


--
-- Name: bomchild; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.bomchild (
    sysid integer NOT NULL,
    itemid bigint,
    itemchild bigint
);


ALTER TABLE dbo.bomchild OWNER TO postgres;

--
-- Name: bomchild_sysid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.bomchild_sysid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.bomchild_sysid_seq OWNER TO postgres;

--
-- Name: bomchild_sysid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.bomchild_sysid_seq OWNED BY dbo.bomchild.sysid;


--
-- Name: bomrm; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.bomrm (
    sysid integer NOT NULL,
    itemid bigint,
    itemrm bigint
);


ALTER TABLE dbo.bomrm OWNER TO postgres;

--
-- Name: bomrm_sysid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.bomrm_sysid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.bomrm_sysid_seq OWNER TO postgres;

--
-- Name: bomrm_sysid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.bomrm_sysid_seq OWNED BY dbo.bomrm.sysid;


--
-- Name: cmproduct_bom; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.cmproduct_bom (
    sysid integer NOT NULL,
    itemid_product bigint,
    itemid_bom character varying(50),
    parttypeid character varying(50)
);


ALTER TABLE dbo.cmproduct_bom OWNER TO postgres;

--
-- Name: cmproduct_bom_sysid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.cmproduct_bom_sysid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.cmproduct_bom_sysid_seq OWNER TO postgres;

--
-- Name: cmproduct_bom_sysid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.cmproduct_bom_sysid_seq OWNED BY dbo.cmproduct_bom.sysid;


--
-- Name: d_comment; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.d_comment (
    idcoment integer NOT NULL,
    idcoment_detail bigint,
    kode_com text,
    topic text,
    coment text,
    tgl_in date,
    username text,
    id_dept bigint,
    foto text,
    foto2 text,
    jam time without time zone,
    likecom double precision,
    qtycoment double precision,
    fitureid integer
);


ALTER TABLE dbo.d_comment OWNER TO postgres;

--
-- Name: d_comment_idcoment_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.d_comment_idcoment_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.d_comment_idcoment_seq OWNER TO postgres;

--
-- Name: d_comment_idcoment_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.d_comment_idcoment_seq OWNED BY dbo.d_comment.idcoment;


--
-- Name: m_line; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_line (
    idline integer NOT NULL,
    line character varying(150),
    category character varying(50),
    factory character varying(10)
);


ALTER TABLE dbo.m_line OWNER TO postgres;

--
-- Name: m_machine; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_machine (
    regid integer NOT NULL,
    code character varying(50),
    mcname character varying(50),
    tonage double precision,
    idline bigint,
    detailline bigint,
    isactive bigint
);


ALTER TABLE dbo.m_machine OWNER TO postgres;

--
-- Name: detailmachine; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.detailmachine AS
 SELECT m_machine.regid,
    m_machine.code,
    m_machine.mcname,
    m_machine.tonage,
    m_machine.idline,
    m_machine.detailline,
    m_machine.isactive,
    m_line.line,
    m_line.category,
    m_line.factory
   FROM (dbo.m_machine
     JOIN dbo.m_line ON ((m_machine.idline = m_line.idline)));


ALTER TABLE dbo.detailmachine OWNER TO postgres;

--
-- Name: g_docnummat; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.g_docnummat (
    regid integer NOT NULL,
    docnum text,
    createby bigint,
    createdate timestamp with time zone,
    docdate date,
    hideh text,
    itemid bigint,
    prosesh bigint,
    shiftid bigint,
    gtstroke double precision,
    gtstrokeplan double precision,
    trctypeid bigint,
    trcid bigint,
    monthid character varying(4)
);


ALTER TABLE dbo.g_docnummat OWNER TO postgres;

--
-- Name: g_docnummat_regid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.g_docnummat_regid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.g_docnummat_regid_seq OWNER TO postgres;

--
-- Name: g_docnummat_regid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.g_docnummat_regid_seq OWNED BY dbo.g_docnummat.regid;


--
-- Name: m_department; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_department (
    id integer NOT NULL,
    dept_code text,
    dept_name text,
    descr text,
    deptsysid bigint
);


ALTER TABLE dbo.m_department OWNER TO postgres;

--
-- Name: m_detailstatus; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_detailstatus (
    regid integer NOT NULL,
    detail character varying(50)
);


ALTER TABLE dbo.m_detailstatus OWNER TO postgres;

--
-- Name: m_level; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_level (
    id_level integer NOT NULL,
    level character varying(50)
);


ALTER TABLE dbo.m_level OWNER TO postgres;

--
-- Name: m_user; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_user (
    regid integer NOT NULL,
    code character varying(50),
    username character varying(150),
    id_user character varying(150),
    password character varying(150),
    nama_lengkap text,
    level character varying(60),
    blokir character varying(3),
    foto character varying(150),
    id_dept bigint,
    password2 character varying(150),
    isstoreroom bigint,
    musertr bigint,
    muser bigint,
    mprodmaterial bigint,
    mprodstamping bigint,
    mprodwelding bigint,
    mproddelivery bigint,
    mprodstoreroom bigint,
    mpartner bigint,
    mcategory bigint,
    munit bigint,
    mcust bigint,
    trcmaterial bigint,
    trcstamping bigint,
    trcwelding bigint,
    trcwh bigint,
    trcstoreroom bigint,
    trcga bigint,
    trcmtc bigint,
    trcict bigint,
    caneditmaster bigint,
    caneditdoc bigint,
    caneditmanuser bigint,
    mprodict bigint,
    mprodmtnt bigint,
    mprodmtnm bigint,
    mprodga bigint,
    trcmtnm bigint,
    trcmtnt bigint,
    trcasset boolean,
    caneditdocadmin bigint,
    mproduct bigint,
    mutility bigint,
    muserims bigint,
    trcwip bigint,
    isdelete character varying(10),
    email character varying(150),
    activationid character varying(250),
    activation bigint,
    masset boolean,
    mbom boolean,
    trcsony boolean,
    trcproduction boolean,
    dailygap boolean,
    trcbpfg boolean,
    area bigint
);


ALTER TABLE dbo.m_user OWNER TO postgres;

--
-- Name: imsuser; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.imsuser AS
 SELECT m_user.regid,
    m_user.username,
    m_user.id_user,
    m_user.password,
    m_user.nama_lengkap,
    m_user.level AS idlevel,
    m_user.blokir AS idblokir,
    m_user.foto,
    m_user.id_dept,
    m_user.password2,
    m_department.dept_code,
    m_department.dept_name AS dept,
    m_detailstatus_1.detail AS blokir,
    m_level.level,
    m_user.isstoreroom,
    m_user.code,
    m_user.musertr,
    m_user.muser,
    m_user.mprodmaterial,
    m_user.mprodstamping,
    m_user.mprodwelding,
    m_user.mproddelivery,
    m_user.mprodstoreroom,
    m_user.mpartner,
    m_user.mcategory,
    m_user.munit,
    m_user.mcust,
    m_user.trcmaterial,
    m_user.trcstamping,
    m_user.trcwelding,
    m_user.trcwh,
    m_user.trcstoreroom,
    m_user.trcga,
    m_user.trcmtc,
    m_user.caneditmaster,
    m_user.caneditdoc,
    m_user.caneditmanuser,
    m_user.trcict,
    m_user.mprodict,
    m_user.mprodga,
    m_user.mproduct,
    m_user.mutility,
    m_user.muserims,
    m_user.trcwip,
    m_user.isdelete,
    m_user.caneditdocadmin,
    m_user.masset,
    m_user.trcasset,
    m_user.mbom,
    m_user.trcsony,
    m_user.trcproduction,
    m_user.activation,
    m_user.email,
    m_user.dailygap,
    m_user.trcbpfg,
    m_user.area
   FROM (((dbo.m_user
     LEFT JOIN dbo.m_detailstatus m_detailstatus_1 ON (((m_user.blokir)::bigint = m_detailstatus_1.regid)))
     LEFT JOIN dbo.m_level ON (((m_user.level)::bigint = m_level.id_level)))
     LEFT JOIN dbo.m_department ON ((m_user.id_dept = m_department.id)))
  WHERE (((m_user.isdelete)::bpchar = 'X'::bpchar) AND (m_user.activation = 1))
  ORDER BY m_user.regid DESC;


ALTER TABLE dbo.imsuser OWNER TO postgres;

--
-- Name: lastact; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.lastact (
    sysid bigint,
    url character varying(150),
    headmenuactive character varying(50),
    menuactive character varying(50),
    iconactive character varying(50),
    ip_address character varying(50),
    status boolean
);


ALTER TABLE dbo.lastact OWNER TO postgres;

--
-- Name: m_userg5; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_userg5 (
    sysid integer NOT NULL,
    regid bigint,
    username character varying(50),
    fullname character varying(50),
    deptid bigint,
    password character varying(150),
    passwordx character varying(150),
    image character varying(50),
    email character varying(150),
    isactive boolean,
    isstoreroom boolean,
    activationid character varying(250),
    activation boolean,
    area character varying(50),
    pin text,
    signature text,
    jabatanid integer
);


ALTER TABLE dbo.m_userg5 OWNER TO postgres;

--
-- Name: listpictr; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.listpictr AS
 SELECT m_department.dept_code,
    m_department.dept_name,
    m_userg5.sysid,
    m_userg5.fullname,
    m_userg5.isstoreroom,
    m_userg5.username
   FROM (dbo.m_department
     RIGHT JOIN dbo.m_userg5 ON ((m_department.id = m_userg5.deptid)))
  WHERE ((m_userg5.isstoreroom)::integer = 1);


ALTER TABLE dbo.listpictr OWNER TO postgres;

--
-- Name: loguser; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.loguser (
    sysid integer NOT NULL,
    username character varying(150),
    docdate date,
    doctime time without time zone,
    query character varying(150),
    ip_address character varying(50),
    status boolean
);


ALTER TABLE dbo.loguser OWNER TO postgres;

--
-- Name: loguser_sysid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.loguser_sysid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.loguser_sysid_seq OWNER TO postgres;

--
-- Name: loguser_sysid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.loguser_sysid_seq OWNED BY dbo.loguser.sysid;


--
-- Name: m_addressdlv; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_addressdlv (
    sysid integer NOT NULL,
    partnerid integer,
    titleaddres character varying(20),
    address character varying(200),
    city character varying(50),
    postcode character varying(50),
    country character varying(50),
    currencyid integer,
    priceperiodactiveid integer,
    isbilling boolean,
    isoffice boolean,
    isdelivery boolean,
    phone character varying(50),
    fax character varying(50)
);


ALTER TABLE dbo.m_addressdlv OWNER TO postgres;

--
-- Name: m_addressdlv_sysid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.m_addressdlv_sysid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.m_addressdlv_sysid_seq OWNER TO postgres;

--
-- Name: m_addressdlv_sysid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.m_addressdlv_sysid_seq OWNED BY dbo.m_addressdlv.sysid;


--
-- Name: m_asset; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_asset (
    sysid bigint,
    itemid character varying(50),
    itemno text,
    itemname character varying(100),
    spec character varying(150),
    categoryid bigint,
    remark text,
    locationid bigint,
    userid bigint,
    datepur date,
    lastupdate date,
    purchasedate date,
    vendorid bigint,
    qty double precision,
    qtybal double precision,
    jurnalid character varying(50),
    unitid bigint,
    image character varying(150),
    imagerev double precision,
    isactive boolean,
    price double precision,
    amount double precision
);


ALTER TABLE dbo.m_asset OWNER TO postgres;

--
-- Name: m_assetict; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_assetict (
    sysid character varying(150),
    ram bigint,
    hdd bigint,
    netcard bigint,
    vgacard bigint,
    processor bigint,
    os bigint,
    office bigint,
    autocad bigint,
    nx bigint,
    sw bigint,
    catia bigint,
    fb bigint,
    db bigint,
    hardware bigint,
    printertype bigint,
    colortype bigint,
    sizepaper bigint,
    remark text
);


ALTER TABLE dbo.m_assetict OWNER TO postgres;

--
-- Name: m_bank; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_bank (
    sysid smallint,
    code character varying(10),
    bankname character varying(50)
);


ALTER TABLE dbo.m_bank OWNER TO postgres;

--
-- Name: m_category; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_category (
    id integer NOT NULL,
    code character varying(25),
    category_name character varying(100),
    descr text,
    groupby character varying(50),
    isdelete character varying(1)
);


ALTER TABLE dbo.m_category OWNER TO postgres;

--
-- Name: m_category_id_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.m_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.m_category_id_seq OWNER TO postgres;

--
-- Name: m_category_id_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.m_category_id_seq OWNED BY dbo.m_category.id;


--
-- Name: m_childpart_conecting; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_childpart_conecting (
    sysid integer NOT NULL,
    itemid bigint,
    childpartid character varying(50),
    parttypeid character varying(50)
);


ALTER TABLE dbo.m_childpart_conecting OWNER TO postgres;

--
-- Name: m_childpart_conecting_sysid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.m_childpart_conecting_sysid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.m_childpart_conecting_sysid_seq OWNER TO postgres;

--
-- Name: m_childpart_conecting_sysid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.m_childpart_conecting_sysid_seq OWNED BY dbo.m_childpart_conecting.sysid;


--
-- Name: m_currency; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_currency (
    sysid integer,
    code character varying(5),
    descr character varying(50),
    desimal smallint,
    desimal2 smallint,
    titikkoma smallint,
    rate double precision
);


ALTER TABLE dbo.m_currency OWNER TO postgres;

--
-- Name: m_partner; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_partner (
    sysid integer NOT NULL,
    partnercode character varying(50),
    partnername character varying(100),
    address character varying(150),
    termofpayment integer,
    isppn boolean DEFAULT true,
    npwp character varying(50),
    emailaddress character varying(50),
    iscustomer boolean,
    isvendor boolean,
    issubcont boolean,
    currencyid integer,
    priceperiodactiveid integer,
    telp character varying(50),
    fax character varying(50),
    picname character varying(50),
    mayprintinv boolean DEFAULT false,
    repeatprint smallint,
    creditlimit double precision,
    creditlimitactive boolean,
    norek character varying(50),
    banknameid smallint,
    cabang character varying(50),
    atasnama character varying(50),
    isdelete boolean DEFAULT false
);


ALTER TABLE dbo.m_partner OWNER TO postgres;

--
-- Name: m_product; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_product (
    regid integer NOT NULL,
    partno character varying(50),
    partname text,
    spec1 character varying(50),
    spec2 character varying(50),
    pcspersheet double precision,
    pcsperkg double precision,
    idcust bigint,
    idproject bigint,
    idcategory bigint,
    ismaterial bigint,
    isstamping bigint,
    iswelding bigint,
    isdelivery bigint,
    isstoreroom bigint,
    isactive bigint,
    price double precision,
    pcsperday double precision,
    min double precision,
    max double precision,
    docdate date,
    updateby bigint,
    materialtype bigint,
    stockfg double precision,
    image text,
    stockwip double precision,
    masterby bigint,
    idunit bigint,
    idunit_buy bigint,
    isict bigint,
    isga bigint,
    stockwip2 double precision,
    iswip smallint,
    sparating double precision,
    stdpack double precision,
    issubcon boolean,
    isdelete character varying(1),
    convertion double precision,
    currencyid bigint,
    jobnum character varying(150),
    description character varying(150),
    isg5 boolean DEFAULT false,
    postcategoryid integer
);


ALTER TABLE dbo.m_product OWNER TO postgres;

--
-- Name: m_custmaterial; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.m_custmaterial AS
 SELECT count(m_product.idcust) AS count,
    m_partner.sysid AS regid,
    m_partner.partnercode AS code,
    m_partner.partnername AS custname
   FROM (dbo.m_product
     JOIN dbo.m_partner ON ((m_product.idcust = m_partner.sysid)))
  WHERE ((m_product.isactive = 1) AND (m_product.ismaterial = 1))
  GROUP BY m_partner.sysid, m_partner.partnercode, m_partner.partnername
 HAVING (count(m_product.idcust) > 0);


ALTER TABLE dbo.m_custmaterial OWNER TO postgres;

--
-- Name: m_customer; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_customer (
    regid integer NOT NULL,
    code text,
    custname text,
    isdelete character varying(10)
);


ALTER TABLE dbo.m_customer OWNER TO postgres;

--
-- Name: m_customer_regid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.m_customer_regid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.m_customer_regid_seq OWNER TO postgres;

--
-- Name: m_customer_regid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.m_customer_regid_seq OWNED BY dbo.m_customer.regid;


--
-- Name: m_custwarehouse; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.m_custwarehouse AS
 SELECT count(m_product.idcust) AS count,
    m_partner.sysid AS regid,
    m_partner.partnercode AS code,
    m_partner.partnername AS custname
   FROM (dbo.m_product
     JOIN dbo.m_partner ON ((m_product.idcust = m_partner.sysid)))
  WHERE ((m_product.isactive = 1) AND (m_product.isdelivery = 1))
  GROUP BY m_partner.sysid, m_partner.partnercode, m_partner.partnername;


ALTER TABLE dbo.m_custwarehouse OWNER TO postgres;

--
-- Name: m_custwip; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.m_custwip AS
 SELECT count(m_product.idcust) AS count,
    m_partner.sysid AS regid,
    m_partner.partnercode AS code,
    m_partner.partnername AS custname,
    m_product.idcust
   FROM (dbo.m_product
     JOIN dbo.m_partner ON ((m_product.idcust = m_partner.sysid)))
  WHERE ((m_product.iswip = 1) AND (m_product.isactive = 1))
  GROUP BY m_partner.sysid, m_partner.partnercode, m_partner.partnername, m_product.idcust
 HAVING (count(m_product.idcust) > 0);


ALTER TABLE dbo.m_custwip OWNER TO postgres;

--
-- Name: m_department_id_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.m_department_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.m_department_id_seq OWNER TO postgres;

--
-- Name: m_department_id_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.m_department_id_seq OWNED BY dbo.m_department.id;


--
-- Name: m_detailict; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_detailict (
    sysid integer NOT NULL,
    code character varying(50),
    description character varying(50),
    category character varying(50),
    remark character varying(50),
    isdelete boolean
);


ALTER TABLE dbo.m_detailict OWNER TO postgres;

--
-- Name: m_detailict_sysid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.m_detailict_sysid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.m_detailict_sysid_seq OWNER TO postgres;

--
-- Name: m_detailict_sysid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.m_detailict_sysid_seq OWNED BY dbo.m_detailict.sysid;


--
-- Name: m_detailstatus_regid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.m_detailstatus_regid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.m_detailstatus_regid_seq OWNER TO postgres;

--
-- Name: m_detailstatus_regid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.m_detailstatus_regid_seq OWNED BY dbo.m_detailstatus.regid;


--
-- Name: m_jabatan; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_jabatan (
    regid integer NOT NULL,
    levelname character varying(150)
);


ALTER TABLE dbo.m_jabatan OWNER TO postgres;

--
-- Name: m_jabatan_regid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.m_jabatan_regid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.m_jabatan_regid_seq OWNER TO postgres;

--
-- Name: m_jabatan_regid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.m_jabatan_regid_seq OWNED BY dbo.m_jabatan.regid;


--
-- Name: m_level_id_level_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.m_level_id_level_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.m_level_id_level_seq OWNER TO postgres;

--
-- Name: m_level_id_level_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.m_level_id_level_seq OWNED BY dbo.m_level.id_level;


--
-- Name: m_line_idline_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.m_line_idline_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.m_line_idline_seq OWNER TO postgres;

--
-- Name: m_line_idline_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.m_line_idline_seq OWNED BY dbo.m_line.idline;


--
-- Name: m_location; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_location (
    sysid integer NOT NULL,
    location character varying(50),
    remark character varying(50),
    category character varying(50),
    isactive boolean
);


ALTER TABLE dbo.m_location OWNER TO postgres;

--
-- Name: m_location_sysid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.m_location_sysid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.m_location_sysid_seq OWNER TO postgres;

--
-- Name: m_location_sysid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.m_location_sysid_seq OWNED BY dbo.m_location.sysid;


--
-- Name: m_machine_regid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.m_machine_regid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.m_machine_regid_seq OWNER TO postgres;

--
-- Name: m_machine_regid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.m_machine_regid_seq OWNED BY dbo.m_machine.regid;


--
-- Name: m_masterby; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_masterby (
    regid integer NOT NULL,
    masterby character varying(50)
);


ALTER TABLE dbo.m_masterby OWNER TO postgres;

--
-- Name: m_masterby_regid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.m_masterby_regid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.m_masterby_regid_seq OWNER TO postgres;

--
-- Name: m_masterby_regid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.m_masterby_regid_seq OWNED BY dbo.m_masterby.regid;


--
-- Name: m_materialtype; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_materialtype (
    regid integer NOT NULL,
    materialname character varying(50)
);


ALTER TABLE dbo.m_materialtype OWNER TO postgres;

--
-- Name: m_materialtype_regid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.m_materialtype_regid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.m_materialtype_regid_seq OWNER TO postgres;

--
-- Name: m_materialtype_regid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.m_materialtype_regid_seq OWNED BY dbo.m_materialtype.regid;


--
-- Name: m_partner2; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_partner2 (
    id integer NOT NULL,
    partner_code text,
    partner_name text,
    address text,
    dlvaddress text,
    telp text,
    isdelete character varying(10),
    category character varying(50)
);


ALTER TABLE dbo.m_partner2 OWNER TO postgres;

--
-- Name: m_partner2_id_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.m_partner2_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.m_partner2_id_seq OWNER TO postgres;

--
-- Name: m_partner2_id_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.m_partner2_id_seq OWNED BY dbo.m_partner2.id;


--
-- Name: m_partner_sysid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.m_partner_sysid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.m_partner_sysid_seq OWNER TO postgres;

--
-- Name: m_partner_sysid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.m_partner_sysid_seq OWNED BY dbo.m_partner.sysid;


--
-- Name: m_product_regid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.m_product_regid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.m_product_regid_seq OWNER TO postgres;

--
-- Name: m_product_regid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.m_product_regid_seq OWNED BY dbo.m_product.regid;


--
-- Name: m_productionprocess; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_productionprocess (
    sysid integer NOT NULL,
    code character varying(50),
    description character varying(50),
    category character varying(50),
    isdelete character varying(1)
);


ALTER TABLE dbo.m_productionprocess OWNER TO postgres;

--
-- Name: m_productionprocess_sysid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.m_productionprocess_sysid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.m_productionprocess_sysid_seq OWNER TO postgres;

--
-- Name: m_productionprocess_sysid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.m_productionprocess_sysid_seq OWNED BY dbo.m_productionprocess.sysid;


--
-- Name: m_project; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_project (
    regid integer NOT NULL,
    idcust bigint,
    projectname character varying(50)
);


ALTER TABLE dbo.m_project OWNER TO postgres;

--
-- Name: m_project_regid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.m_project_regid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.m_project_regid_seq OWNER TO postgres;

--
-- Name: m_project_regid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.m_project_regid_seq OWNED BY dbo.m_project.regid;


--
-- Name: m_qccheck; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_qccheck (
    sysid integer NOT NULL,
    qccheck character varying(50),
    category character varying(50)
);


ALTER TABLE dbo.m_qccheck OWNER TO postgres;

--
-- Name: m_qccheck_sysid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.m_qccheck_sysid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.m_qccheck_sysid_seq OWNER TO postgres;

--
-- Name: m_qccheck_sysid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.m_qccheck_sysid_seq OWNED BY dbo.m_qccheck.sysid;


--
-- Name: m_shift2; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_shift2 (
    sysid integer NOT NULL,
    codeshift character varying(1),
    shift character varying(50)
);


ALTER TABLE dbo.m_shift2 OWNER TO postgres;

--
-- Name: m_shift2_sysid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.m_shift2_sysid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.m_shift2_sysid_seq OWNER TO postgres;

--
-- Name: m_shift2_sysid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.m_shift2_sysid_seq OWNED BY dbo.m_shift2.sysid;


--
-- Name: m_shipper; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_shipper (
    sysid smallint,
    shipper character varying(50)
);


ALTER TABLE dbo.m_shipper OWNER TO postgres;

--
-- Name: m_unit; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_unit (
    id bigint,
    code character varying(90),
    unit character varying(180),
    descr character varying(180),
    isdelete character varying(1)
);


ALTER TABLE dbo.m_unit OWNER TO postgres;

--
-- Name: m_user_regid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.m_user_regid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.m_user_regid_seq OWNER TO postgres;

--
-- Name: m_user_regid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.m_user_regid_seq OWNED BY dbo.m_user.regid;


--
-- Name: m_userg5_sysid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.m_userg5_sysid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.m_userg5_sysid_seq OWNER TO postgres;

--
-- Name: m_userg5_sysid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.m_userg5_sysid_seq OWNED BY dbo.m_userg5.sysid;


--
-- Name: m_userrole; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_userrole (
    sysid integer NOT NULL,
    userid bigint,
    numof bigint,
    activityid bigint,
    activity character varying(50),
    activitycode character varying(50),
    deldata boolean,
    updata boolean,
    retdata boolean,
    viewjurnal boolean,
    usergroupflow bigint
);


ALTER TABLE dbo.m_userrole OWNER TO postgres;

--
-- Name: m_userrole_sysid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.m_userrole_sysid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.m_userrole_sysid_seq OWNER TO postgres;

--
-- Name: m_userrole_sysid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.m_userrole_sysid_seq OWNED BY dbo.m_userrole.sysid;


--
-- Name: m_vendor; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.m_vendor (
    regid integer NOT NULL,
    vendorcode character varying(50),
    vendorname character varying(125)
);


ALTER TABLE dbo.m_vendor OWNER TO postgres;

--
-- Name: m_vendor_regid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.m_vendor_regid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.m_vendor_regid_seq OWNER TO postgres;

--
-- Name: m_vendor_regid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.m_vendor_regid_seq OWNED BY dbo.m_vendor.regid;


--
-- Name: master_bom; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.master_bom AS
 SELECT bom1.sysid,
    bom2.sysid AS sysid2,
    bom2.nourut,
    bom1.idcust,
    bom1.idproject,
    bom2.partno,
    bom2.partname,
    m_customer.custname,
    bom1.createby,
    bom2.levelpart,
    bom2.parttype AS parttypeid,
    bom2.qtypercar,
    bom2.supplierid,
    bom2.spec,
    bom2.thick,
    bom2.width,
    bom2.length,
    bom2.pcspersheet,
    bom2.kgpersheet,
    bom2.partweight,
    bom2.materialtype AS materialtypeid,
    bom3.op5m,
    bom3.op10m,
    bom3.op20m,
    bom3.op30m,
    bom3.op40m,
    bom3.op50m,
    bom3.op60m,
    bom3.op70m,
    bom4.op5,
    bom4.op10,
    bom4.op20,
    bom4.op30,
    bom4.op40,
    bom4.op50,
    bom4.op60,
    bom4.op70,
    bom5.processassy,
    bom5.lineassy,
    m_materialtype.materialname AS materialtype,
    m_project.projectname,
    bom6.parttype,
    m_partner.partnername,
    bom2.fglocation,
    bom2.stdpack,
    bom2.packingtype,
    bom2.itemno,
    bom2.itemnosub,
    bom1.isdelete,
    bom1.isactive,
    bom2.isactivedetail,
    bom2.isdeletedetail,
    m_customer.code,
    bom2.pcsperday,
    bom2.linkid,
    bom2.specorder1,
    bom2.specorder2,
    bom2.iscommon,
    bom2.qtypart,
    bom2.ratio,
    bom2.partno_ext,
    bom2.partname_ext,
    bom2.iscommongroup,
    bom2.groupcommonid
   FROM ((((dbo.bom4
     RIGHT JOIN (dbo.bom5
     RIGHT JOIN (dbo.m_materialtype
     RIGHT JOIN (dbo.bom6
     RIGHT JOIN (dbo.bom2
     LEFT JOIN dbo.m_partner ON ((m_partner.sysid = bom2.supplierid))) ON (((bom6.sysid)::text = (bom2.parttype)::text))) ON ((m_materialtype.regid = bom2.materialtype))) ON (((bom5.sysid)::text = (bom2.sysid)::text))) ON (((bom4.sysid)::text = (bom2.sysid)::text)))
     LEFT JOIN dbo.bom3 ON (((bom2.sysid)::text = (bom3.sysid)::text)))
     LEFT JOIN (dbo.m_project
     RIGHT JOIN dbo.bom1 ON ((m_project.regid = bom1.idproject))) ON (((bom2.linkid)::text = (bom1.sysid)::text)))
     LEFT JOIN dbo.m_customer ON ((bom1.idcust = m_customer.regid)))
  WHERE (((bom1.isdelete)::integer = 0) AND ((bom2.isdeletedetail)::integer = 0))
  ORDER BY bom1.sysid, bom2.nourut, bom2.itemnosub;


ALTER TABLE dbo.master_bom OWNER TO postgres;

--
-- Name: master_bom1; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.master_bom1 AS
 SELECT bom1.sysid,
    bom1.partno,
    bom1.partname,
    bom1.idcust,
    bom1.image,
    bom1.idproject,
    bom1.packingtype,
    bom1.parttypeid,
    bom1.stdpack,
    bom1.fglocation,
    bom1.createby,
    bom1.isactive,
    bom1.isdelete,
    m_customer.custname,
    m_project.projectname,
    bom6.parttype,
    bom1.qtypercar,
    bom1.supplierid,
    m_partner.partnername,
    m_partner.partnercode,
    bom1.itemno,
    m_customer.code
   FROM ((dbo.m_customer
     RIGHT JOIN ((dbo.m_partner
     RIGHT JOIN dbo.bom1 ON ((bom1.supplierid = m_partner.sysid)))
     LEFT JOIN dbo.bom6 ON (((bom1.parttypeid)::text = (bom6.sysid)::text))) ON ((m_customer.regid = bom1.idcust)))
     LEFT JOIN dbo.m_project ON ((bom1.idproject = m_project.regid)))
  WHERE ((bom1.isdelete)::integer = 0)
  ORDER BY bom1.sysid DESC;


ALTER TABLE dbo.master_bom1 OWNER TO postgres;

--
-- Name: qm_userg5; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.qm_userg5 AS
 SELECT m_userg5.sysid,
    m_userg5.regid,
    m_userg5.username,
    m_userg5.fullname,
    m_userg5.deptid,
    m_userg5.password,
    m_userg5.passwordx,
    m_userg5.image,
    m_userg5.email,
    m_department.dept_name,
    m_userg5.isactive,
    m_userg5.activationid,
    m_userg5.activation,
    m_userg5.area,
    m_location.location,
    m_department.deptsysid
   FROM ((dbo.m_userg5
     LEFT JOIN dbo.m_location ON (((m_userg5.area)::bigint = m_location.sysid)))
     LEFT JOIN dbo.m_department ON ((m_userg5.deptid = m_department.id)))
  WHERE ((m_userg5.isactive)::integer = 1);


ALTER TABLE dbo.qm_userg5 OWNER TO postgres;

--
-- Name: t077_postcategory; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t077_postcategory (
    sysid smallint,
    doctypeid smallint,
    postcategory character varying(80),
    mledgerid smallint,
    trctypeid smallint,
    itemgroupid smallint
);


ALTER TABLE dbo.t077_postcategory OWNER TO postgres;

--
-- Name: q01_mproduct; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.q01_mproduct AS
 SELECT m_product.regid,
    m_product.partno,
    m_product.partname,
    m_product.idcust,
    m_product.idproject,
    m_project.projectname,
    m_category.code AS codecategory,
    m_category.category_name,
    m_product.spec1,
    m_product.spec2,
    COALESCE(m_product.pcspersheet, (0)::double precision) AS pcspersheet,
    COALESCE(m_product.pcsperkg, (0)::double precision) AS pcsperkg,
    m_product.idcategory,
    m_product.ismaterial,
    m_product.isstamping,
    m_product.iswelding,
    m_product.isdelivery,
    m_product.isstoreroom,
    m_product.isactive,
    m_product.price,
    m_product.pcsperday,
    m_product.min,
    m_product.max,
    m_product.docdate,
    m_product.updateby,
    m_product.materialtype,
    COALESCE(m_product.stockfg, (0)::double precision) AS stockfg,
    m_product.image,
    m_product.stockwip,
    m_product.idunit,
    m_product.masterby AS idmasterby,
    m_product.isict,
    m_product.isga,
    m_product.iswip,
    m_product.stdpack,
    m_product.issubcon,
    m_partner.partnercode AS code,
    m_partner.partnername AS custname,
    m_partner.address,
    m_product.isdelete,
    m_unit_1.code AS codeunit,
    m_unit_1.unit,
    qm_userg5.username,
    qm_userg5.deptid,
    m_product.idunit_buy,
    m_unit.code AS code_buy,
    m_unit.unit AS unit_buy,
    m_product.convertion,
    m_product.currencyid,
    m_product.jobnum,
    m_product.description,
    m_currency.code AS currency,
    m_currency.desimal,
    m_currency.titikkoma,
    m_product.isg5,
    m_product.postcategoryid,
    t077_postcategory.mledgerid
   FROM ((((((((dbo.m_product
     LEFT JOIN dbo.t077_postcategory ON ((m_product.postcategoryid = t077_postcategory.sysid)))
     LEFT JOIN dbo.m_currency ON ((m_product.currencyid = m_currency.sysid)))
     LEFT JOIN dbo.m_unit ON ((m_product.idunit_buy = m_unit.id)))
     LEFT JOIN dbo.qm_userg5 ON ((m_product.masterby = qm_userg5.sysid)))
     LEFT JOIN dbo.m_partner ON ((m_product.idcust = m_partner.sysid)))
     LEFT JOIN dbo.m_project ON ((m_product.idproject = m_project.regid)))
     LEFT JOIN dbo.m_unit m_unit_1 ON ((m_product.idunit = m_unit_1.id)))
     LEFT JOIN dbo.m_category ON ((m_product.idcategory = m_category.id)))
  WHERE ((m_product.isdelete)::bpchar = 'X'::bpchar);


ALTER TABLE dbo.q01_mproduct OWNER TO postgres;

--
-- Name: t_connecting; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t_connecting (
    trctypeid bigint,
    monthid bigint,
    trcid bigint,
    lineid bigint,
    trctypeid_to bigint,
    monthid_to bigint,
    trcid_to bigint,
    lineid_to bigint
);


ALTER TABLE dbo.t_connecting OWNER TO postgres;

--
-- Name: td_transaction; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.td_transaction (
    regid integer NOT NULL,
    trctypeid bigint,
    monthid bigint,
    trcid bigint,
    lineid bigint,
    itemid bigint,
    qty_1 double precision,
    qty_2 double precision,
    qty_3 double precision,
    qty_4 double precision,
    qty_5 double precision,
    convertion_1 double precision,
    convertion_2 double precision,
    typeid bigint,
    detaildate date,
    detailtime time without time zone,
    addressid bigint,
    detaildocnum character varying(25),
    starttime timestamp with time zone,
    endtime timestamp with time zone,
    duration double precision,
    processd bigint,
    processh bigint,
    processid bigint,
    addressdetail bigint,
    remarkd character varying(225),
    lotno bigint,
    vanno bigint,
    achievement double precision,
    totaldt double precision,
    totalps double precision,
    gsph double precision,
    createby bigint,
    partnerid bigint,
    sjnum character varying(50),
    sjdate date,
    reffnum character varying(50),
    matnum character varying(50),
    isdelete boolean DEFAULT false,
    trctypeid_ext bigint,
    monthid_ext bigint,
    trcid_ext bigint,
    lineid_ext bigint,
    price double precision,
    amount double precision,
    balamount double precision,
    op1 text,
    op2 text,
    picname bigint
);


ALTER TABLE dbo.td_transaction OWNER TO postgres;

--
-- Name: th_transaction; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.th_transaction (
    regid integer NOT NULL,
    trctypeid bigint,
    monthid character varying(4),
    trcid bigint,
    docnum character varying(25),
    docdate date,
    doctime time without time zone,
    docdate_ext date,
    userid bigint,
    partnerid bigint,
    picname text,
    docnum_2 character varying(25),
    docdate_2 timestamp with time zone,
    docnum_3 character varying(25),
    docdate_3 timestamp with time zone,
    shiftid bigint,
    createdate timestamp with time zone,
    lastupdate timestamp with time zone,
    userupdateid bigint,
    lineid bigint,
    fromareaid bigint,
    remarkh character varying(225),
    statusid bigint,
    op1 character varying(25),
    op2 text
);


ALTER TABLE dbo.th_transaction OWNER TO postgres;

--
-- Name: qtd_transaction; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.qtd_transaction AS
 SELECT td_transaction.regid,
    td_transaction.trctypeid,
    td_transaction.monthid,
    td_transaction.trcid,
    td_transaction.lineid,
    td_transaction.itemid,
    td_transaction.qty_1,
    td_transaction.qty_2,
    td_transaction.qty_3,
    td_transaction.qty_4,
    td_transaction.qty_5,
    td_transaction.convertion_1,
    td_transaction.convertion_2,
    td_transaction.typeid,
    td_transaction.detaildate,
    td_transaction.detailtime,
    td_transaction.addressid,
    td_transaction.detaildocnum,
    td_transaction.starttime,
    td_transaction.endtime,
    td_transaction.duration,
    td_transaction.processd,
    td_transaction.processh,
    td_transaction.addressdetail,
    td_transaction.remarkd,
    td_transaction.lotno,
    td_transaction.vanno,
    td_transaction.achievement,
    td_transaction.totaldt,
    td_transaction.totalps,
    td_transaction.gsph,
    td_transaction.createby,
    td_transaction.sjnum,
    td_transaction.sjdate,
    td_transaction.reffnum,
    td_transaction.matnum,
    q01_mproduct.partno,
    q01_mproduct.partname,
    q01_mproduct.spec1,
    q01_mproduct.spec2,
    q01_mproduct.pcspersheet,
    q01_mproduct.pcsperkg,
    q01_mproduct.idcust,
    q01_mproduct.idproject,
    q01_mproduct.idcategory,
    qm_userg5.dept_name,
    q01_mproduct.codecategory AS category,
    q01_mproduct.category_name,
    qm_userg5.username AS usercreate,
    q01_mproduct.projectname,
    q01_mproduct.materialtype,
    q01_mproduct.stockwip,
    q01_mproduct.stockfg,
    q01_mproduct.idunit,
    q01_mproduct.codeunit,
    floor((td_transaction.qty_1 - td_transaction.qty_3)) AS canedit,
    th_transaction.docdate,
    th_transaction.docnum_2,
    th_transaction.partnerid,
    td_transaction_1.qty_3 AS balmatsource,
    td_transaction_1.qty_4 AS balpcssource,
    td_transaction_1.trctypeid AS trctypeid_from,
    td_transaction_1.monthid AS monthid_from,
    td_transaction_1.trcid AS trcid_from,
    td_transaction_1.lineid AS lineid_from,
    td_transaction_1.itemid AS itemidext,
    th_transaction.remarkh,
    th_transaction.statusid,
    th_transaction.userid,
    th_transaction.docnum_3,
    th_transaction.docdate_3,
    th_transaction.docdate_2,
    q01_mproduct_1.partno AS partno_from,
    q01_mproduct_1.partname AS partname_from,
    q01_mproduct_1.spec1 AS spec1_from,
    q01_mproduct_1.spec2 AS spec2_from,
    td_transaction.trctypeid_ext,
    td_transaction.monthid_ext,
    td_transaction.trcid_ext,
    td_transaction.lineid_ext,
    th_transaction.docdate_ext,
    td_transaction_1.convertion_1 AS convertion_1_from,
    td_transaction_1.convertion_2 AS convertion_2_from,
    td_transaction.amount,
    td_transaction.balamount,
    td_transaction.price,
    td_transaction_1.amount AS amountsource,
    td_transaction.partnerid AS partneriddetail,
    m_partner.partnercode AS partnercodedetail,
    m_partner.partnername AS partnernamedetail,
    m_partner.address AS partneraddressdetail,
    td_transaction_1.balamount AS balamountsource,
    td_transaction.op1,
    td_transaction.op2,
    qm_userg5_1.fullname AS fullnametr,
    qm_userg5_1.deptid AS deptidtr,
    td_transaction.picname,
    qm_userg5_1.dept_name AS dept_nametr,
    q01_mproduct.code,
    q01_mproduct.custname,
    th_transaction.docnum,
    th_transaction.doctime,
    th_transaction.picname AS picnameid_detail,
    th_transaction.shiftid,
    th_transaction.createdate,
    th_transaction.lastupdate,
    q01_mproduct.unit,
    m_partner_1.partnercode,
    m_partner_1.partnername,
    m_partner_1.address,
    td_transaction.isdelete
   FROM (((((dbo.q01_mproduct q01_mproduct_1
     JOIN dbo.td_transaction td_transaction_1 ON ((q01_mproduct_1.regid = td_transaction_1.itemid)))
     RIGHT JOIN (dbo.t_connecting
     RIGHT JOIN (((dbo.td_transaction
     JOIN dbo.th_transaction ON (((td_transaction.trctypeid = th_transaction.trctypeid) AND (td_transaction.monthid = (th_transaction.monthid)::bigint) AND (td_transaction.trcid = th_transaction.trcid))))
     LEFT JOIN dbo.m_partner m_partner_1 ON ((th_transaction.partnerid = m_partner_1.sysid)))
     LEFT JOIN dbo.m_partner ON ((td_transaction.partnerid = m_partner.sysid))) ON (((t_connecting.trctypeid_to = td_transaction.trctypeid) AND (t_connecting.monthid_to = td_transaction.monthid) AND (t_connecting.trcid_to = td_transaction.trcid) AND (t_connecting.lineid_to = td_transaction.lineid)))) ON (((td_transaction_1.trctypeid = t_connecting.trctypeid) AND (td_transaction_1.monthid = t_connecting.monthid) AND (td_transaction_1.trcid = t_connecting.trcid) AND (td_transaction_1.lineid = t_connecting.lineid))))
     LEFT JOIN dbo.qm_userg5 qm_userg5_1 ON ((td_transaction.picname = qm_userg5_1.sysid)))
     LEFT JOIN dbo.qm_userg5 ON ((th_transaction.userid = qm_userg5.sysid)))
     LEFT JOIN dbo.q01_mproduct ON ((td_transaction.itemid = q01_mproduct.regid)))
  WHERE ((td_transaction.isdelete)::integer = 0);


ALTER TABLE dbo.qtd_transaction OWNER TO postgres;

--
-- Name: scwarehouse_in; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.scwarehouse_in AS
 SELECT qtd_transaction.docnum,
    qtd_transaction.detaildocnum,
    qtd_transaction.docdate,
    qtd_transaction.itemid,
    qtd_transaction.partno,
    qtd_transaction.partname,
    qtd_transaction.qty_1 AS inmat,
    COALESCE(qtd_transaction.qty_5, (0)::double precision) AS outmat,
    qtd_transaction.idcust,
    qtd_transaction.code,
    qtd_transaction.custname,
    qtd_transaction.spec1,
    qtd_transaction.spec2,
    qtd_transaction.pcspersheet,
    qtd_transaction.pcsperkg,
    qtd_transaction.detailtime AS doctime,
    qtd_transaction.qty_3 AS balmat,
    qtd_transaction.qty_4 AS balpcs,
    qtd_transaction.regid,
    qtd_transaction.trctypeid,
    qtd_transaction.monthid,
    qtd_transaction.trcid,
    qtd_transaction.lineid
   FROM dbo.qtd_transaction
  WHERE (qtd_transaction.trctypeid = 1500)
  ORDER BY qtd_transaction.docdate;


ALTER TABLE dbo.scwarehouse_in OWNER TO postgres;

--
-- Name: scwarehouse_out; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.scwarehouse_out AS
 SELECT qtd_transaction.docnum,
    qtd_transaction.detaildocnum,
    qtd_transaction.docdate,
    qtd_transaction.itemid,
    qtd_transaction.partno,
    qtd_transaction.partname,
    qtd_transaction.qty_1 AS outmat,
    COALESCE(qtd_transaction.qty_5, (0)::double precision) AS inmat,
    qtd_transaction.idcust,
    qtd_transaction.code,
    qtd_transaction.custname,
    qtd_transaction.spec1,
    qtd_transaction.spec2,
    qtd_transaction.pcspersheet,
    qtd_transaction.pcsperkg,
    qtd_transaction.detailtime AS doctime,
    qtd_transaction.qty_3 AS balmat,
    qtd_transaction.qty_4 AS balpcs,
    qtd_transaction.regid,
    qtd_transaction.trctypeid,
    qtd_transaction.monthid,
    qtd_transaction.trcid,
    qtd_transaction.lineid
   FROM dbo.qtd_transaction
  WHERE (qtd_transaction.trctypeid = 1600)
  ORDER BY qtd_transaction.docdate;


ALTER TABLE dbo.scwarehouse_out OWNER TO postgres;

--
-- Name: scwarehouse_ext; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.scwarehouse_ext AS
 SELECT scwarehouse_in.docnum,
    scwarehouse_in.detaildocnum,
    scwarehouse_in.docdate,
    scwarehouse_in.itemid,
    scwarehouse_in.partno,
    scwarehouse_in.partname,
    scwarehouse_in.inmat,
    scwarehouse_in.outmat,
    scwarehouse_in.idcust,
    scwarehouse_in.code,
    scwarehouse_in.custname,
    scwarehouse_in.doctime,
    scwarehouse_in.regid,
    scwarehouse_in.trctypeid,
    scwarehouse_in.monthid,
    scwarehouse_in.trcid,
    scwarehouse_in.lineid
   FROM dbo.scwarehouse_in
UNION
 SELECT scwarehouse_out.docnum,
    scwarehouse_out.detaildocnum,
    scwarehouse_out.docdate,
    scwarehouse_out.itemid,
    scwarehouse_out.partno,
    scwarehouse_out.partname,
    scwarehouse_out.inmat,
    scwarehouse_out.outmat,
    scwarehouse_out.idcust,
    scwarehouse_out.code,
    scwarehouse_out.custname,
    scwarehouse_out.doctime,
    scwarehouse_out.regid,
    scwarehouse_out.trctypeid,
    scwarehouse_out.monthid,
    scwarehouse_out.trcid,
    scwarehouse_out.lineid
   FROM dbo.scwarehouse_out;


ALTER TABLE dbo.scwarehouse_ext OWNER TO postgres;

--
-- Name: scwarehouse; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.scwarehouse AS
 SELECT scwarehouse_ext.docnum,
    scwarehouse_ext.detaildocnum,
    scwarehouse_ext.docdate,
    scwarehouse_ext.doctime,
    scwarehouse_ext.itemid,
    scwarehouse_ext.partno,
    scwarehouse_ext.partname,
    scwarehouse_ext.inmat,
    scwarehouse_ext.outmat,
    scwarehouse_ext.idcust,
    scwarehouse_ext.code,
    scwarehouse_ext.custname,
    scwarehouse_ext.trctypeid,
    scwarehouse_ext.monthid,
    scwarehouse_ext.trcid,
    scwarehouse_ext.lineid
   FROM dbo.scwarehouse_ext
  ORDER BY scwarehouse_ext.docdate, scwarehouse_ext.doctime;


ALTER TABLE dbo.scwarehouse OWNER TO postgres;

--
-- Name: warehousestock_ext; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.warehousestock_ext AS
 SELECT m_product.regid AS itemid,
    m_product.partno,
    m_product.partname,
    COALESCE(sum(scwarehouse.inmat), (0)::double precision) AS "in",
    COALESCE(sum(scwarehouse.outmat), (0)::double precision) AS "out",
    m_product.pcsperday,
    COALESCE(m_product.stockfg, (0)::double precision) AS stockfg,
    m_product.isactive,
    m_detailstatus.detail AS detailstatus,
    m_product.stdpack,
    m_project.projectname,
    m_product.idcust,
    m_partner.partnercode AS code,
    m_partner.partnername AS custname
   FROM ((((dbo.m_detailstatus
     JOIN dbo.m_product ON ((m_detailstatus.regid = m_product.isactive)))
     LEFT JOIN dbo.m_partner ON ((m_product.idcust = m_partner.sysid)))
     LEFT JOIN dbo.m_project ON ((m_product.idproject = m_project.regid)))
     LEFT JOIN dbo.scwarehouse ON ((m_product.regid = scwarehouse.itemid)))
  WHERE ((m_product.isactive = 1) AND (m_product.isdelivery = 1))
  GROUP BY m_product.regid, m_product.partno, m_product.partname, m_product.pcsperday, m_product.stockfg, m_product.isactive, m_detailstatus.detail, m_product.stdpack, m_project.projectname, m_product.idcust, m_partner.partnercode, m_partner.partnername;


ALTER TABLE dbo.warehousestock_ext OWNER TO postgres;

--
-- Name: warehousestock; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.warehousestock AS
 SELECT warehousestock_ext.itemid,
    warehousestock_ext.partno,
    warehousestock_ext.partname,
    warehousestock_ext.idcust,
    warehousestock_ext.code,
    warehousestock_ext."in",
    warehousestock_ext."out",
    ((warehousestock_ext."in" - warehousestock_ext."out") + warehousestock_ext.stockfg) AS stock,
    warehousestock_ext.pcsperday,
    warehousestock_ext.stockfg,
    warehousestock_ext.isactive,
    warehousestock_ext.detailstatus,
    warehousestock_ext.stdpack,
    warehousestock_ext.projectname
   FROM dbo.warehousestock_ext
  GROUP BY warehousestock_ext.itemid, warehousestock_ext.partno, warehousestock_ext.partname, warehousestock_ext.idcust, warehousestock_ext."in", warehousestock_ext."out", warehousestock_ext.code, ((warehousestock_ext."in" - warehousestock_ext."out") + warehousestock_ext.stockfg), warehousestock_ext.pcsperday, warehousestock_ext.stockfg, warehousestock_ext.isactive, warehousestock_ext.detailstatus, warehousestock_ext.stdpack, warehousestock_ext.projectname
  ORDER BY warehousestock_ext.code;


ALTER TABLE dbo.warehousestock OWNER TO postgres;

--
-- Name: monitoringfg; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.monitoringfg AS
 SELECT warehousestock.itemid,
    warehousestock.partno,
    warehousestock.partname,
    warehousestock.idcust,
    warehousestock.code,
    warehousestock."in",
    warehousestock."out",
    warehousestock.stock,
    warehousestock.pcsperday,
    warehousestock.stockfg,
    warehousestock.isactive,
    warehousestock.detailstatus,
    warehousestock.stdpack,
    COALESCE((warehousestock.stockfg / COALESCE(warehousestock.pcsperday, (0)::double precision)), (0)::double precision) AS hari
   FROM dbo.warehousestock;


ALTER TABLE dbo.monitoringfg OWNER TO postgres;

--
-- Name: monitoringfglistcust; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.monitoringfglistcust AS
 SELECT row_number() OVER (ORDER BY m_customer.code) AS nomor,
    m_customer.regid,
    m_customer.code,
    m_customer.custname
   FROM (dbo.monitoringfg
     JOIN dbo.m_customer ON ((monitoringfg.idcust = m_customer.regid)))
  GROUP BY m_customer.regid, m_customer.code, m_customer.custname;


ALTER TABLE dbo.monitoringfglistcust OWNER TO postgres;

--
-- Name: scmaterial_in; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.scmaterial_in AS
 SELECT qtd_transaction.docnum,
    qtd_transaction.detaildocnum,
    qtd_transaction.docdate,
    qtd_transaction.itemid,
    qtd_transaction.partno,
    qtd_transaction.partname,
    qtd_transaction.qty_1 AS inmat,
    COALESCE(qtd_transaction.qty_5, (0)::double precision) AS outmat,
    qtd_transaction.idcust,
    qtd_transaction.code,
    qtd_transaction.custname,
    qtd_transaction.spec1,
    qtd_transaction.spec2,
    qtd_transaction.pcspersheet,
    qtd_transaction.pcsperkg,
    qtd_transaction.detailtime AS doctime,
    qtd_transaction.qty_3 AS balmat,
    qtd_transaction.qty_4 AS balpcs,
    qtd_transaction.regid,
    qtd_transaction.trctypeid,
    qtd_transaction.monthid,
    qtd_transaction.trcid,
    qtd_transaction.lineid
   FROM dbo.qtd_transaction
  WHERE ((qtd_transaction.trctypeid = 110) OR (qtd_transaction.trctypeid = 125) OR (qtd_transaction.trctypeid = 300))
  ORDER BY qtd_transaction.docdate;


ALTER TABLE dbo.scmaterial_in OWNER TO postgres;

--
-- Name: rmstock; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.rmstock AS
 SELECT m_product.regid AS itemid,
    m_product.partno,
    m_product.partname,
    m_product.spec1,
    m_product.spec2,
    m_product.pcspersheet,
    m_product.pcsperkg,
    m_product.idcust,
    m_product.idproject,
    m_product.idcategory,
    m_product.ismaterial,
    m_product.isstoreroom,
    m_product.isactive,
    m_product.price,
    m_product.pcsperday,
    m_product.min,
    m_product.max,
    COALESCE(sum(scmaterial_in.balmat), (0)::double precision) AS balmat,
    COALESCE(sum(scmaterial_in.balpcs), (0)::double precision) AS balpcs,
    m_partner.partnercode AS code,
    m_partner.partnername AS custname,
    m_product.isdelete
   FROM ((dbo.m_product
     LEFT JOIN dbo.m_partner ON ((m_product.idcust = m_partner.sysid)))
     LEFT JOIN dbo.scmaterial_in ON ((m_product.regid = scmaterial_in.itemid)))
  GROUP BY m_product.regid, m_product.partno, m_product.partname, m_product.spec1, m_product.spec2, m_product.pcspersheet, m_product.pcsperkg, m_product.idcust, m_product.idproject, m_product.idcategory, m_product.ismaterial, m_product.isstoreroom, m_product.isactive, m_product.price, m_product.pcsperday, m_product.min, m_product.max, m_partner.partnercode, m_partner.partnername, m_product.isdelete
 HAVING ((m_product.isactive = 1) AND (m_product.ismaterial = 1) AND ((m_product.isdelete)::text = 'X'::text));


ALTER TABLE dbo.rmstock OWNER TO postgres;

--
-- Name: monitoringrm_ext; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.monitoringrm_ext AS
 SELECT rmstock.itemid,
    rmstock.partno,
    rmstock.partname,
    rmstock.spec1,
    rmstock.spec2,
    rmstock.pcspersheet,
    rmstock.pcsperkg,
    rmstock.idcust,
    rmstock.idproject,
    rmstock.ismaterial,
    rmstock.isactive,
    rmstock.pcsperday,
    rmstock.min,
    rmstock.max,
    rmstock.code,
    rmstock.custname,
    m_product.materialtype,
    rmstock.balmat,
        CASE
            WHEN (m_product.materialtype = 1) THEN (rmstock.balmat / rmstock.pcsperkg)
            ELSE (rmstock.balmat * rmstock.pcspersheet)
        END AS balpcs
   FROM (dbo.rmstock
     LEFT JOIN dbo.m_product ON ((rmstock.itemid = m_product.regid)));


ALTER TABLE dbo.monitoringrm_ext OWNER TO postgres;

--
-- Name: monitoringrm; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.monitoringrm AS
 SELECT monitoringrm_ext.itemid,
    monitoringrm_ext.partno,
    monitoringrm_ext.partname,
    monitoringrm_ext.spec1,
    monitoringrm_ext.spec2,
    monitoringrm_ext.pcspersheet,
    monitoringrm_ext.pcsperkg,
    monitoringrm_ext.idcust,
    monitoringrm_ext.idproject,
    monitoringrm_ext.ismaterial,
    monitoringrm_ext.isactive,
    monitoringrm_ext.pcsperday,
    monitoringrm_ext.min,
    monitoringrm_ext.max,
    monitoringrm_ext.code,
    monitoringrm_ext.custname,
    monitoringrm_ext.balmat,
    monitoringrm_ext.balpcs,
    COALESCE((monitoringrm_ext.balpcs / COALESCE(monitoringrm_ext.pcsperday, (0)::double precision)), (0)::double precision) AS hari,
    monitoringrm_ext.materialtype
   FROM dbo.monitoringrm_ext;


ALTER TABLE dbo.monitoringrm OWNER TO postgres;

--
-- Name: monitoringrmlistcust; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.monitoringrmlistcust AS
 SELECT row_number() OVER (ORDER BY m_customer.code) AS nomor,
    m_customer.regid,
    m_customer.code,
    m_customer.custname
   FROM (dbo.monitoringrm
     JOIN dbo.m_customer ON ((monitoringrm.idcust = m_customer.regid)))
  GROUP BY m_customer.regid, m_customer.code, m_customer.custname;


ALTER TABLE dbo.monitoringrmlistcust OWNER TO postgres;

--
-- Name: mytable; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.mytable (
    logins integer,
    logins22 integer,
    logins221 integer
);


ALTER TABLE dbo.mytable OWNER TO postgres;

--
-- Name: pr_doctype; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.pr_doctype (
    sysid smallint,
    doctype character varying(10),
    descr character varying(50),
    trctypeid smallint,
    deptid smallint,
    approval character varying(20),
    legalized character varying(20)
);


ALTER TABLE dbo.pr_doctype OWNER TO postgres;

--
-- Name: t066_itemgroup; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t066_itemgroup (
    sysid smallint,
    itemgroup character varying(60)
);


ALTER TABLE dbo.t066_itemgroup OWNER TO postgres;

--
-- Name: t_77_mledger; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t_77_mledger (
    sysid smallint,
    code character varying(50),
    descr character varying(100),
    seqidx smallint,
    macctlevel smallint,
    typeml smallint,
    cf_rpttype smallint,
    cf_group character varying(10),
    bs_rpttype smallint,
    pl_rpttype smallint,
    tb_group smallint,
    spasi character varying(10),
    isdetail boolean,
    isneraca boolean,
    parentid smallint,
    lft smallint,
    rgt smallint,
    partopid integer,
    kascnt boolean,
    kasbankcnt boolean
);


ALTER TABLE dbo.t_77_mledger OWNER TO postgres;

--
-- Name: q077_postcategory; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.q077_postcategory AS
 SELECT t077_postcategory.sysid,
    t077_postcategory.doctypeid,
    pr_doctype.doctype,
    t077_postcategory.postcategory,
    t077_postcategory.mledgerid,
    t_77_mledger.code AS accnum,
    t_77_mledger.descr AS accname,
    t077_postcategory.trctypeid,
    t077_postcategory.itemgroupid,
    t066_itemgroup.itemgroup
   FROM (((dbo.t077_postcategory
     LEFT JOIN dbo.t066_itemgroup ON ((t077_postcategory.itemgroupid = t066_itemgroup.sysid)))
     LEFT JOIN dbo.t_77_mledger ON ((t077_postcategory.mledgerid = t_77_mledger.sysid)))
     LEFT JOIN dbo.pr_doctype ON ((t077_postcategory.doctypeid = pr_doctype.sysid)));


ALTER TABLE dbo.q077_postcategory OWNER TO postgres;

--
-- Name: t094_costcenterdetail; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t094_costcenterdetail (
    sysid integer,
    costcenterid smallint,
    itemgroupid smallint,
    descr character varying(50),
    nominal double precision
);


ALTER TABLE dbo.t094_costcenterdetail OWNER TO postgres;

--
-- Name: q094_costcenterdetail_sum; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.q094_costcenterdetail_sum AS
 SELECT t094_costcenterdetail.costcenterid,
    sum(t094_costcenterdetail.nominal) AS sumamount
   FROM dbo.t094_costcenterdetail
  GROUP BY t094_costcenterdetail.costcenterid;


ALTER TABLE dbo.q094_costcenterdetail_sum OWNER TO postgres;

--
-- Name: t680_trc; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t680_trc (
    c010_trctypeid smallint,
    c011_month smallint,
    c012_trcid smallint,
    c050_rev smallint,
    c000_sysid smallint,
    yearidx smallint,
    monthidx smallint,
    c015_datepost timestamp without time zone,
    c016_timepost timestamp with time zone,
    c045_username character varying(25),
    c050_docnum character varying(25),
    c050_docdate timestamp without time zone,
    actmgrobjtitle character varying(25),
    description character varying(200),
    costcenterid smallint,
    itemgroupid smallint,
    amounttrc double precision
);


ALTER TABLE dbo.t680_trc OWNER TO postgres;

--
-- Name: q680_summarybudget; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.q680_summarybudget AS
 SELECT t680_trc.yearidx,
    t680_trc.costcenterid AS deptid,
    sum(t680_trc.amounttrc) AS amount
   FROM dbo.t680_trc
  GROUP BY t680_trc.yearidx, t680_trc.costcenterid;


ALTER TABLE dbo.q680_summarybudget OWNER TO postgres;

--
-- Name: t015_department; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t015_department (
    sysid smallint,
    department character varying(50),
    deptgroup character varying(20)
);


ALTER TABLE dbo.t015_department OWNER TO postgres;

--
-- Name: t093_costcenter; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t093_costcenter (
    sysid smallint,
    yearidx smallint,
    deptid smallint,
    budget double precision
);


ALTER TABLE dbo.t093_costcenter OWNER TO postgres;

--
-- Name: q093_costcenter; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.q093_costcenter AS
 SELECT t093_costcenter.sysid,
    t093_costcenter.yearidx,
    t093_costcenter.deptid,
    t093_costcenter.budget,
    COALESCE(q094_costcenterdetail_sum.sumamount, (0)::double precision) AS sumdetail,
    COALESCE(q680_summarybudget.amount, (0)::double precision) AS amountusage,
    (t093_costcenter.budget - COALESCE(q680_summarybudget.amount, (0)::double precision)) AS amountavail,
    2 AS "decimal",
    1 AS titikkoma,
    t015_department.department
   FROM (((dbo.t093_costcenter
     LEFT JOIN dbo.t015_department ON ((t093_costcenter.deptid = t015_department.sysid)))
     LEFT JOIN dbo.q094_costcenterdetail_sum ON ((t093_costcenter.sysid = q094_costcenterdetail_sum.costcenterid)))
     LEFT JOIN dbo.q680_summarybudget ON (((t093_costcenter.deptid = q680_summarybudget.deptid) AND (t093_costcenter.yearidx = q680_summarybudget.yearidx))));


ALTER TABLE dbo.q093_costcenter OWNER TO postgres;

--
-- Name: q094_costcenterdetail; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.q094_costcenterdetail AS
 SELECT t094_costcenterdetail.costcenterid,
    sum(t094_costcenterdetail.nominal) AS sumamount
   FROM dbo.t094_costcenterdetail
  GROUP BY t094_costcenterdetail.costcenterid;


ALTER TABLE dbo.q094_costcenterdetail OWNER TO postgres;

--
-- Name: t100_fixedasset; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t100_fixedasset (
    sysid integer,
    code character varying(50),
    descr character varying(200),
    groupassetid smallint,
    activity_activeid smallint,
    activate boolean
);


ALTER TABLE dbo.t100_fixedasset OWNER TO postgres;

--
-- Name: t101_groupasset; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t101_groupasset (
    sysid smallint,
    code character varying(20),
    descr character varying(50),
    mledgerid_d smallint,
    mledgerid_k smallint
);


ALTER TABLE dbo.t101_groupasset OWNER TO postgres;

--
-- Name: t105_activitycategory; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t105_activitycategory (
    sysid smallint,
    code character varying(20),
    descr character varying(50)
);


ALTER TABLE dbo.t105_activitycategory OWNER TO postgres;

--
-- Name: t106_fa_activity; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t106_fa_activity (
    sysid integer,
    fixedassetid integer,
    activitycategoryid smallint,
    dtcreate timestamp without time zone,
    dtacc timestamp without time zone,
    userid smallint,
    ownerid smallint,
    user_ue smallint,
    statprogress smallint
);


ALTER TABLE dbo.t106_fa_activity OWNER TO postgres;

--
-- Name: q106_fa_activity_inprogress; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.q106_fa_activity_inprogress AS
 SELECT t106_fa_activity.sysid,
    t105_activitycategory.descr AS activity,
    t100_fixedasset.code,
    t100_fixedasset.descr,
    t101_groupasset.descr AS groupasset,
    t106_fa_activity.dtcreate,
    t015_department.department,
    t015_department.sysid AS deptid
   FROM ((((dbo.t106_fa_activity
     JOIN dbo.t100_fixedasset ON ((t106_fa_activity.fixedassetid = t100_fixedasset.sysid)))
     JOIN dbo.t101_groupasset ON ((t100_fixedasset.groupassetid = t101_groupasset.sysid)))
     LEFT JOIN dbo.t105_activitycategory ON ((t106_fa_activity.activitycategoryid = t105_activitycategory.sysid)))
     LEFT JOIN dbo.t015_department ON ((t106_fa_activity.ownerid = t015_department.sysid)))
  WHERE (t106_fa_activity.statprogress = 1);


ALTER TABLE dbo.q106_fa_activity_inprogress OWNER TO postgres;

--
-- Name: t610_trc; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t610_trc (
    c010_trctypeid smallint,
    c011_month smallint,
    c012_trcid smallint,
    c050_rev smallint,
    c000_sysid smallint,
    c014_monthpostidx integer,
    c013_mapperid smallint,
    yearidx smallint,
    monthidx smallint,
    c015_datepost timestamp without time zone,
    c016_timepost timestamp with time zone,
    c045_username character varying(25),
    c050_docnum character varying(25),
    c050_docdate timestamp without time zone,
    c050_accountdate timestamp without time zone,
    actmgrobjtitle character varying(25),
    description character varying(370),
    sledgerid smallint,
    mledgerid smallint,
    subledger1id smallint,
    subledger2id smallint,
    minplus smallint,
    amounttrc double precision,
    amountintrc double precision,
    amountouttrc double precision,
    currency character varying(5),
    rate double precision,
    amountlocal double precision,
    amountinlocal double precision,
    amountoutlocal double precision,
    docref1 character varying(100),
    docref2 character varying(100),
    description1 character varying(150),
    costcenterid smallint
);


ALTER TABLE dbo.t610_trc OWNER TO postgres;

--
-- Name: t_76_sledger; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t_76_sledger (
    sysid smallint,
    code character varying(10)
);


ALTER TABLE dbo.t_76_sledger OWNER TO postgres;

--
-- Name: t_77_mledger_sub1; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t_77_mledger_sub1 (
    sysid smallint,
    mledgerid smallint,
    code character varying(50),
    descr character varying(100)
);


ALTER TABLE dbo.t_77_mledger_sub1 OWNER TO postgres;

--
-- Name: t_77_mledger_sub2; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t_77_mledger_sub2 (
    sysid smallint,
    mledgerid smallint,
    subledgerid smallint,
    code character varying(20),
    descr character varying(50)
);


ALTER TABLE dbo.t_77_mledger_sub2 OWNER TO postgres;

--
-- Name: q610_jurnal; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.q610_jurnal AS
 SELECT t610_trc.c012_trcid AS postingidx,
    3 AS c013_draftreadyapprcancel,
    t610_trc.c050_accountdate AS trcdate,
    t610_trc.c050_docnum AS refdocnum,
    t610_trc.description AS actmgrobjtitle,
    t_77_mledger.code,
    t_77_mledger.descr AS account,
    t_77_mledger_sub1.code AS subacc1,
    t_77_mledger_sub2.code AS subacc2,
    t610_trc.yearidx,
    t610_trc.monthidx,
    t610_trc.amountintrc AS debet,
    t610_trc.amountouttrc AS credit,
    t610_trc.currency,
    t610_trc.rate,
    t610_trc.amountinlocal AS debet_idr,
    t610_trc.amountoutlocal AS credit_idr,
    2 AS currdecimal,
    1 AS titikkoma,
    t610_trc.c014_monthpostidx AS idx,
    t610_trc.c010_trctypeid,
    t610_trc.c012_trcid AS c000_sysid,
    t610_trc.c011_month,
    t610_trc.c050_rev,
    t610_trc.c045_username AS username,
    t_76_sledger.code AS sledger,
    t610_trc.c015_datepost AS c045_dtime,
    t610_trc.minplus,
    t610_trc.docref1 AS docref,
    t610_trc.mledgerid,
    t610_trc.subledger1id,
    t610_trc.description1,
    t610_trc.c000_sysid AS c000_sysidx
   FROM ((((dbo.t610_trc
     LEFT JOIN dbo.t_77_mledger_sub2 ON (((t610_trc.subledger2id = t_77_mledger_sub2.sysid) AND (t610_trc.subledger1id = t_77_mledger_sub2.subledgerid) AND (t610_trc.mledgerid = t_77_mledger_sub2.mledgerid))))
     LEFT JOIN dbo.t_77_mledger_sub1 ON (((t610_trc.subledger1id = t_77_mledger_sub1.sysid) AND (t610_trc.mledgerid = t_77_mledger_sub1.mledgerid))))
     LEFT JOIN dbo.t_77_mledger ON ((t610_trc.mledgerid = t_77_mledger.sysid)))
     LEFT JOIN dbo.t_76_sledger ON ((t610_trc.sledgerid = t_76_sledger.sysid)));


ALTER TABLE dbo.q610_jurnal OWNER TO postgres;

--
-- Name: q_77_mledger_cashbank; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.q_77_mledger_cashbank AS
 SELECT t_77_mledger.sysid,
    t_77_mledger.code,
    t_77_mledger.descr
   FROM dbo.t_77_mledger
  WHERE ((t_77_mledger.parentid = 40) OR (t_77_mledger.parentid = 70));


ALTER TABLE dbo.q_77_mledger_cashbank OWNER TO postgres;

--
-- Name: q_77_mledger_detail; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.q_77_mledger_detail AS
 SELECT t_77_mledger.sysid,
    t_77_mledger.code,
    t_77_mledger.descr
   FROM dbo.t_77_mledger
  WHERE ((t_77_mledger.isdetail)::integer = 1);


ALTER TABLE dbo.q_77_mledger_detail OWNER TO postgres;

--
-- Name: t064_prcategory; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t064_prcategory (
    sysid smallint,
    trctypeid smallint,
    sub1 character varying(50),
    sub2 character varying(50)
);


ALTER TABLE dbo.t064_prcategory OWNER TO postgres;

--
-- Name: t500_proc; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t500_proc (
    c010_trctypeid integer,
    c011_month smallint,
    c000_sysid integer,
    c050_rev smallint,
    c013_trctypesrcid smallint,
    c013_draftreadyapprcancel smallint,
    c014_actmgrid smallint,
    c017_usergrpflowid_from smallint,
    c017_usergrpflowid_to smallint,
    c017_usergrpflowfrom character varying(25),
    c017_usergrpflowto character varying(25),
    c018_flowtypeid smallint,
    c018_kanbanpostid smallint,
    c045_userid integer,
    c045_username character varying(25),
    c045_dtime timestamp with time zone,
    c045_usernameupdate character varying(25),
    c045_dtimelasupdate timestamp with time zone,
    c050_docnum character varying(25),
    c050_docdate timestamp without time zone,
    c050_accountdate timestamp without time zone,
    c050_extdocnum character varying(50),
    c050_extdocdate timestamp without time zone,
    c050_extdocnum1 character varying(25),
    c050_extdocdate1 timestamp without time zone,
    c051_ponum character varying(30),
    c051_fakturnum character varying(100),
    c051_fakturdatetax timestamp without time zone,
    c051_duedate timestamp without time zone,
    c052_termofpayment smallint,
    c059_remark character varying(1000),
    c060_partnerid smallint,
    c061_picname character varying(50),
    c062_actfixedassetid integer,
    c070_currencyid smallint,
    c071_rate double precision,
    c072_ratetax double precision,
    c073_amount double precision,
    c073_amountbruto double precision,
    c074_amountdiscount double precision,
    c074_expense double precision,
    c075_amountppn double precision,
    c075_amountpph double precision,
    c076_amountfinal double precision,
    c077_amountbalance double precision,
    c078_amountprepaid double precision,
    c079_amountgrnotinv double precision,
    c080_prcategoryid smallint,
    c085_isppn boolean,
    c090_estdlvdate timestamp without time zone,
    c113_prtype smallint,
    sledgerid smallint,
    mledgerid smallint,
    subledger1id smallint,
    subledger2id smallint,
    postcategoryid smallint,
    remark_pr character varying(1000),
    yearidx smallint,
    deptid smallint
);


ALTER TABLE dbo.t500_proc OWNER TO postgres;

--
-- Name: q_g1_proc; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.q_g1_proc AS
 SELECT t500_proc.c010_trctypeid,
    t500_proc.c011_month,
    t500_proc.c000_sysid,
    t500_proc.c050_rev,
    t500_proc.c013_trctypesrcid,
    t500_proc.c013_draftreadyapprcancel,
    t500_proc.c014_actmgrid,
    t500_proc.c017_usergrpflowid_from,
    t500_proc.c017_usergrpflowid_to,
    t500_proc.c017_usergrpflowfrom,
    t500_proc.c017_usergrpflowto,
    t500_proc.c018_flowtypeid,
    t500_proc.c018_kanbanpostid,
    t500_proc.c045_userid,
    t500_proc.c045_username,
    t500_proc.c045_dtime,
    t500_proc.c045_dtimelasupdate,
    t500_proc.c045_usernameupdate,
    t500_proc.c050_docnum,
    t500_proc.c050_docdate,
    t500_proc.c050_accountdate,
    t500_proc.c050_extdocnum,
    t500_proc.c050_extdocdate,
    t500_proc.c050_extdocnum1,
    t500_proc.c050_extdocdate1,
    t500_proc.c051_ponum,
    t500_proc.c051_fakturnum,
    t500_proc.c051_fakturdatetax,
    t500_proc.c051_duedate,
    t500_proc.c052_termofpayment,
    t500_proc.c059_remark,
    t500_proc.c060_partnerid,
    t500_proc.c061_picname,
    t500_proc.c062_actfixedassetid,
    t100_fixedasset.descr AS actfixedasset,
    m_partner.partnercode,
    m_partner.partnercode AS partnerref,
    m_partner.partnername,
    m_partner.address,
    t500_proc.c070_currencyid,
    m_currency.code AS currency,
    m_currency.desimal,
    m_currency.desimal2,
    m_currency.titikkoma,
    t500_proc.c071_rate,
    t500_proc.c072_ratetax,
    m_currency.rate AS ratemaster,
    t500_proc.c073_amount,
    t500_proc.c073_amountbruto,
    t500_proc.c074_amountdiscount,
    (t500_proc.c073_amount - t500_proc.c074_amountdiscount) AS netamount,
    t500_proc.c074_expense,
    t500_proc.c075_amountppn,
    t500_proc.c075_amountpph,
    t500_proc.c076_amountfinal,
    t500_proc.c077_amountbalance,
    t500_proc.c051_ponum AS poref,
    t500_proc.c080_prcategoryid,
    t064_prcategory.sub1 AS cat1,
    t064_prcategory.sub2 AS cat2,
    t500_proc.c085_isppn,
    t077_postcategory.postcategory,
    t500_proc.c090_estdlvdate,
    t500_proc.c113_prtype,
    t500_proc.sledgerid,
    t500_proc.mledgerid,
    t500_proc.subledger1id,
    t500_proc.subledger2id,
    t500_proc.postcategoryid,
    t_77_mledger.descr AS cashbank,
    t_77_mledger_sub1.descr AS account,
    ((COALESCE(((m_partner.partnercode)::text || (', '::bpchar)::text), (''::bpchar)::text) || COALESCE(((t500_proc.c051_fakturnum)::text || (', '::bpchar)::text), (''::bpchar)::text)) || (COALESCE(t500_proc.c050_extdocnum, (''::bpchar)::character varying))::text) AS postdescr,
    ((COALESCE(("left"((m_partner.partnername)::text, 93) || (', '::bpchar)::text), (''::bpchar)::text) || (COALESCE(t500_proc.c050_extdocnum, (''::bpchar)::character varying))::text) || COALESCE("left"((t500_proc.remark_pr)::text, 220), (''::bpchar)::text)) AS gr_descr,
    ((('('::text || (m_partner.partnername)::text) || ') Payment '::text) || (COALESCE(t500_proc.c050_extdocnum, (''::bpchar)::character varying))::text) AS payment_descr,
    t_77_mledger.descr AS accountref,
    t500_proc.remark_pr,
    t_77_mledger.descr AS ap_account,
    t500_proc.c050_extdocnum1 AS financeref,
    t500_proc.yearidx,
    t500_proc.deptid,
    q093_costcenter.budget,
    q093_costcenter.amountusage AS amtbudgetusage,
    q093_costcenter.amountavail,
    m_partner.telp,
    m_partner.fax
   FROM ((dbo.m_partner
     RIGHT JOIN (dbo.t077_postcategory
     RIGHT JOIN ((((((dbo.q093_costcenter
     RIGHT JOIN dbo.t500_proc ON (((q093_costcenter.deptid = t500_proc.deptid) AND (q093_costcenter.yearidx = t500_proc.yearidx))))
     LEFT JOIN dbo.q680_summarybudget ON (((t500_proc.deptid = q680_summarybudget.deptid) AND (t500_proc.yearidx = q680_summarybudget.yearidx))))
     LEFT JOIN dbo.t_77_mledger ON ((t500_proc.mledgerid = t_77_mledger.sysid)))
     LEFT JOIN (dbo.t100_fixedasset
     RIGHT JOIN dbo.t106_fa_activity ON ((t100_fixedasset.sysid = t106_fa_activity.fixedassetid))) ON ((t500_proc.c062_actfixedassetid = t106_fa_activity.sysid)))
     LEFT JOIN dbo.t_77_mledger_sub1 ON (((t500_proc.subledger1id = t_77_mledger_sub1.sysid) AND (t500_proc.mledgerid = t_77_mledger_sub1.mledgerid))))
     LEFT JOIN dbo.t064_prcategory ON ((t500_proc.c080_prcategoryid = t064_prcategory.sysid))) ON ((t077_postcategory.sysid = t500_proc.postcategoryid))) ON ((m_partner.sysid = t500_proc.c060_partnerid)))
     LEFT JOIN dbo.m_currency ON ((t500_proc.c070_currencyid = m_currency.sysid)));


ALTER TABLE dbo.q_g1_proc OWNER TO postgres;

--
-- Name: t510_proc; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t510_proc (
    c010_trctypeid integer,
    c011_month smallint,
    c012_trcid integer,
    c050_rev smallint,
    c000_sysid integer,
    c000_linesrc integer,
    c063_dtdelivery timestamp without time zone,
    c100_itemintid integer,
    c100_itemextid integer,
    c100_itemnameuser character varying(200),
    c105_note character varying(50),
    c102_priceint double precision,
    c110_qty double precision,
    c110_qty2 double precision,
    c111_qtybal double precision,
    c125_amountint double precision,
    c126_valdiscount double precision,
    c127_amountdiscount double precision,
    c130_mledgerid smallint,
    c131_subledger1id smallint,
    c132_subledger2id smallint,
    c135_rate double precision,
    c140_kategoryid smallint,
    c150_unitconvertion double precision,
    c160_prtype smallint,
    postcategoryid smallint,
    c128_netamount double precision,
    costcenterid smallint
);


ALTER TABLE dbo.t510_proc OWNER TO postgres;

--
-- Name: q_g2_proc; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.q_g2_proc AS
 SELECT t510_proc.c010_trctypeid,
    t510_proc.c011_month,
    t510_proc.c012_trcid,
    t510_proc.c050_rev,
    t510_proc.c000_sysid,
    t510_proc.c000_linesrc,
    t510_proc.c063_dtdelivery,
    t510_proc.c100_itemintid,
    q01_mproduct.jobnum AS jobnum_out,
    q01_mproduct.partno AS itemnum_out,
    q01_mproduct.partno AS subnum_out,
    q01_mproduct.partname AS itemname_out,
    q01_mproduct.idunit AS unitid_out,
    q01_mproduct.codeunit AS unit_out,
    q01_mproduct.currencyid AS currencyid_out,
    q01_mproduct.currency AS currency_out,
    t510_proc.c100_itemextid,
    q01_mproduct.jobnum AS jobnum_req,
    q01_mproduct.partno AS itemnum_req,
    q01_mproduct.partno AS subnum_req,
    q01_mproduct.partname AS itemname_req,
    q01_mproduct.jobnum AS itemkanbanid_req,
    q01_mproduct.idunit_buy AS unitid_req,
    q01_mproduct.code_buy AS unit_req,
    q01_mproduct.currencyid AS currencyid_req,
    q01_mproduct.currency AS currency_req,
    t510_proc.c100_itemnameuser,
    t510_proc.c105_note,
    t510_proc.c102_priceint,
    t510_proc.c110_qty,
    t510_proc.c110_qty2,
    t510_proc.c111_qtybal,
    t510_proc.c125_amountint,
    q01_mproduct.desimal,
    q01_mproduct.titikkoma,
    NULL::unknown AS partnerid,
    t510_proc.c126_valdiscount,
    t510_proc.c127_amountdiscount,
    t510_proc.c130_mledgerid,
    t510_proc.c131_subledger1id,
    t510_proc.c132_subledger2id,
    t510_proc.c140_kategoryid,
    t510_proc.c150_unitconvertion,
    t510_proc.c160_prtype,
    q01_mproduct.convertion AS qtyreqtoout,
    q01_mproduct.convertion AS qtyouttoreq,
    q01_mproduct.spec1,
    q01_mproduct.spec2
   FROM (dbo.t510_proc
     LEFT JOIN dbo.q01_mproduct ON ((t510_proc.c100_itemintid = q01_mproduct.regid)));


ALTER TABLE dbo.q_g2_proc OWNER TO postgres;

--
-- Name: q_g2_proc_other; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.q_g2_proc_other AS
 SELECT t510_proc.c010_trctypeid,
    t510_proc.c011_month,
    t510_proc.c012_trcid,
    t510_proc.c050_rev,
    t510_proc.c000_sysid,
    t510_proc.c000_linesrc,
    t510_proc.c063_dtdelivery,
    t510_proc.c100_itemintid,
    m_product.partno AS itemnum,
    m_product.partname AS itemname,
    m_product.jobnum,
    t510_proc.c100_itemnameuser,
    m_unit.code AS unit,
    m_unit.code AS unitref,
    m_unit_1.code AS buyunit,
    m_unit_1.code AS buyunitref,
    m_currency.code AS currency,
    t510_proc.c102_priceint,
    t510_proc.c110_qty,
    t510_proc.c110_qty2,
    t510_proc.c111_qtybal,
    t510_proc.c125_amountint,
    t510_proc.c126_valdiscount,
    t510_proc.c127_amountdiscount,
    t510_proc.c128_netamount,
    t510_proc.c130_mledgerid,
    t510_proc.c135_rate,
    m_currency.desimal,
    m_currency.titikkoma,
    t510_proc.c150_unitconvertion,
    t510_proc.c105_note,
    m_product.description,
    t510_proc.postcategoryid,
    t077_postcategory.postcategory,
    t510_proc.c160_prtype,
    t510_proc.c140_kategoryid,
    t064_prcategory.sub1,
    t064_prcategory.sub2,
    t510_proc.costcenterid,
    t094_costcenterdetail.descr AS costcenter,
    t077_postcategory.itemgroupid
   FROM ((((dbo.t094_costcenterdetail
     RIGHT JOIN dbo.t510_proc ON ((t094_costcenterdetail.sysid = t510_proc.costcenterid)))
     LEFT JOIN dbo.t064_prcategory ON ((t510_proc.c140_kategoryid = t064_prcategory.sysid)))
     LEFT JOIN dbo.t077_postcategory ON ((t510_proc.postcategoryid = t077_postcategory.sysid)))
     LEFT JOIN (((dbo.m_unit m_unit_1
     RIGHT JOIN dbo.m_product ON ((m_unit_1.id = m_product.idunit_buy)))
     LEFT JOIN dbo.m_currency ON ((m_product.currencyid = m_currency.sysid)))
     LEFT JOIN dbo.m_unit ON ((m_product.idunit = m_unit.id))) ON ((t510_proc.c100_itemintid = m_product.regid)))
  WHERE (t510_proc.c010_trctypeid >= 1010);


ALTER TABLE dbo.q_g2_proc_other OWNER TO postgres;

--
-- Name: qcmproduct_bom; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.qcmproduct_bom AS
 SELECT cmproduct_bom.sysid,
    cmproduct_bom.itemid_product,
    cmproduct_bom.itemid_bom,
    master_bom.sysid2,
    master_bom.partno,
    master_bom.partname,
    master_bom.idcust,
    master_bom.idproject,
    master_bom.custname,
    master_bom.parttypeid,
    master_bom.projectname,
    master_bom.code,
    master_bom.linkid
   FROM (dbo.cmproduct_bom
     JOIN dbo.master_bom ON (((cmproduct_bom.itemid_bom)::text = (master_bom.sysid2)::text)));


ALTER TABLE dbo.qcmproduct_bom OWNER TO postgres;

--
-- Name: qcmproduct_bom1; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.qcmproduct_bom1 AS
 SELECT cmproduct_bom.sysid,
    cmproduct_bom.itemid_product,
    cmproduct_bom.itemid_bom,
    bom1.partno,
    bom1.partname,
    bom1.parttypeid,
    m_project.projectname,
    bom1.idcust,
    m_partner.partnercode AS code,
    m_partner.partnername AS custname
   FROM (((dbo.cmproduct_bom
     JOIN dbo.bom1 ON ((((cmproduct_bom.itemid_bom)::text = (bom1.sysid)::text) AND ("left"((cmproduct_bom.itemid_bom)::text, 3) = 'SAI'::text))))
     JOIN dbo.m_project ON ((m_project.regid = bom1.idproject)))
     JOIN dbo.m_partner ON ((bom1.idcust = m_partner.sysid)));


ALTER TABLE dbo.qcmproduct_bom1 OWNER TO postgres;

--
-- Name: qcmproduct_bom2; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.qcmproduct_bom2 AS
 SELECT cmproduct_bom.sysid,
    cmproduct_bom.itemid_product,
    cmproduct_bom.itemid_bom,
    bom2.partno,
    bom2.partname,
    bom2.parttype,
    bom2.linkid,
    bom2.specorder1,
    bom2.specorder2,
    bom1.idcust,
    m_partner.partnercode AS code,
    m_project.projectname
   FROM ((((dbo.bom1
     LEFT JOIN dbo.m_project ON ((bom1.idproject = m_project.regid)))
     LEFT JOIN dbo.m_partner ON ((bom1.idcust = m_partner.sysid)))
     RIGHT JOIN dbo.bom2 ON (((bom1.sysid)::text = (bom2.linkid)::text)))
     RIGHT JOIN dbo.cmproduct_bom ON (((bom2.sysid)::text = (cmproduct_bom.itemid_bom)::text)));


ALTER TABLE dbo.qcmproduct_bom2 OWNER TO postgres;

--
-- Name: qlist_qustomer; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.qlist_qustomer AS
 SELECT count(m_product.idcust) AS count,
    m_partner.partnercode,
    m_partner.partnername,
    m_partner.address,
    m_partner.sysid
   FROM (dbo.m_product
     JOIN dbo.m_partner ON ((m_product.idcust = m_partner.sysid)))
  WHERE (((m_partner.iscustomer)::integer = 1) AND ((m_product.isactive)::integer = 1))
  GROUP BY m_partner.partnercode, m_partner.partnername, m_partner.address, m_partner.sysid;


ALTER TABLE dbo.qlist_qustomer OWNER TO postgres;

--
-- Name: qm_childpart_conecting; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.qm_childpart_conecting AS
 SELECT m_childpart_conecting.sysid,
    m_childpart_conecting.itemid,
    m_childpart_conecting.childpartid,
    q01_mproduct.partno,
    q01_mproduct.partname,
    q01_mproduct.projectname,
    q01_mproduct.code
   FROM (dbo.m_childpart_conecting
     JOIN dbo.q01_mproduct ON (((m_childpart_conecting.childpartid)::bigint = q01_mproduct.regid)));


ALTER TABLE dbo.qm_childpart_conecting OWNER TO postgres;

--
-- Name: qm_childpart_conecting2; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.qm_childpart_conecting2 AS
 SELECT cmproduct_bom.sysid,
    cmproduct_bom.itemid_product AS itemid,
    cmproduct_bom.itemid_product,
    cmproduct_bom.itemid_bom,
    bom2.sysid AS expr1,
    bom2.partno,
    bom2.partname,
    bom2.parttype,
    bom2.linkid,
    bom2.specorder1,
    bom2.specorder2
   FROM (dbo.cmproduct_bom
     JOIN dbo.bom2 ON ((((cmproduct_bom.itemid_bom)::bigint = bom2.itemid) AND ("left"((cmproduct_bom.itemid_bom)::text, 3) <> 'SAI'::text))));


ALTER TABLE dbo.qm_childpart_conecting2 OWNER TO postgres;

--
-- Name: t_30_actmgr; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t_30_actmgr (
    sysid integer NOT NULL,
    objtitle character varying(50),
    codename character varying(50)
);


ALTER TABLE dbo.t_30_actmgr OWNER TO postgres;

--
-- Name: t_30_usergrpflow; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t_30_usergrpflow (
    sysid smallint,
    bprocid smallint,
    descr character varying(50)
);


ALTER TABLE dbo.t_30_usergrpflow OWNER TO postgres;

--
-- Name: qm_userrole; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.qm_userrole AS
 SELECT qm_userg5.sysid,
    m_userrole.numof,
    qm_userg5.regid,
    qm_userg5.username,
    m_userrole.activityid,
    t_30_actmgr.objtitle,
    t_30_actmgr.codename,
    m_userrole.deldata,
    m_userrole.updata,
    m_userrole.retdata,
    m_userrole.viewjurnal,
    m_userrole.usergroupflow AS usergroupflowid,
    t_30_usergrpflow.descr AS usergroupflow,
    m_userrole.userid
   FROM (((dbo.qm_userg5
     JOIN dbo.m_userrole ON ((qm_userg5.sysid = m_userrole.userid)))
     LEFT JOIN dbo.t_30_usergrpflow ON ((m_userrole.usergroupflow = t_30_usergrpflow.sysid)))
     LEFT JOIN dbo.t_30_actmgr ON ((m_userrole.activityid = t_30_actmgr.sysid)));


ALTER TABLE dbo.qm_userrole OWNER TO postgres;

--
-- Name: qmaster_asset; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.qmaster_asset AS
 SELECT m_asset.sysid,
    m_asset.itemid,
    m_asset.itemno,
    m_asset.itemname,
    m_asset.remark,
    m_asset.categoryid,
    m_asset.locationid,
    m_asset.userid,
    m_asset.datepur,
    m_asset.lastupdate,
    m_asset.qty,
    m_asset.qtybal,
    m_asset.jurnalid,
    m_asset.isactive,
    m_detailstatus.detail AS detailstatus,
    m_location.location,
    m_category.category_name AS categoryname,
    m_asset.spec,
    m_asset.unitid,
    m_unit.unit,
    m_asset.image,
    m_asset.purchasedate,
    m_department.dept_code,
    m_department.dept_name,
    m_asset.price,
    m_asset.amount,
    m_assetict.ram,
    m_detailict_1.code AS coderam,
    m_assetict.hdd,
    m_detailict_4.code AS codehdd,
    m_assetict.netcard,
    m_detailict_3.code AS codenetcard,
    m_assetict.vgacard,
    m_detailict_2.code AS codevgacard,
    m_assetict.processor,
    m_detailict_6.code AS codeprocessor,
    m_assetict.os,
    m_detailict_8.code AS codeos,
    m_assetict.office,
    m_detailict_9.code AS codeoffice,
    m_assetict.autocad,
    m_detailict_10.code AS codeautocad,
    m_assetict.nx,
    m_detailict_7.code AS codenx,
    m_assetict.sw,
    m_detailict_5.code AS codesw,
    m_assetict.catia,
    m_detailict_12.code AS codecatia,
    m_assetict.fb,
    m_detailict_11.code AS codefb,
    m_assetict.db,
    m_detailict_13.code AS codedb,
    m_assetict.hardware,
    m_detailict_16.code AS codehardware,
    m_assetict.remark AS remarkdetail,
    m_asset.vendorid,
    m_partner.partnercode,
    m_assetict.printertype,
    m_detailict.code AS codeprintertype,
    m_assetict.colortype,
    m_detailict_15.code AS codecolortype,
    m_assetict.sizepaper,
    m_detailict_14.code AS codesizepaper,
    m_partner.partnername,
    m_partner.address,
    m_userg5.deptid,
    m_userg5.username
   FROM (dbo.m_detailict m_detailict_1
     RIGHT JOIN ((dbo.m_detailict m_detailict_3
     RIGHT JOIN (((((dbo.m_detailict m_detailict_10
     LEFT JOIN (dbo.m_detailict m_detailict_7
     RIGHT JOIN ((((((((dbo.m_unit
     RIGHT JOIN ((dbo.m_partner
     RIGHT JOIN (dbo.m_department
     RIGHT JOIN (dbo.m_asset
     LEFT JOIN dbo.m_userg5 ON ((m_asset.userid = m_userg5.regid))) ON ((m_department.id = m_userg5.deptid))) ON ((m_partner.sysid = m_asset.vendorid)))
     LEFT JOIN ((dbo.m_detailict
     RIGHT JOIN (dbo.m_detailict m_detailict_15
     RIGHT JOIN (dbo.m_detailict m_detailict_14
     RIGHT JOIN dbo.m_assetict ON ((m_detailict_14.sysid = m_assetict.sizepaper))) ON ((m_detailict_15.sysid = m_assetict.colortype))) ON ((m_detailict.sysid = m_assetict.printertype)))
     LEFT JOIN dbo.m_detailict m_detailict_16 ON ((m_assetict.hardware = m_detailict_16.sysid))) ON (((m_asset.itemid)::text = (m_assetict.sysid)::text))) ON ((m_unit.id = m_asset.unitid)))
     RIGHT JOIN dbo.m_location ON ((m_asset.locationid = m_location.sysid)))
     LEFT JOIN dbo.m_detailstatus ON (((m_asset.isactive)::integer = m_detailstatus.regid)))
     LEFT JOIN dbo.m_category ON ((m_asset.categoryid = m_category.id)))
     LEFT JOIN dbo.m_detailict m_detailict_13 ON ((m_assetict.db = m_detailict_13.sysid)))
     LEFT JOIN dbo.m_detailict m_detailict_11 ON ((m_assetict.fb = m_detailict_11.sysid)))
     LEFT JOIN dbo.m_detailict m_detailict_12 ON ((m_assetict.catia = m_detailict_12.sysid)))
     LEFT JOIN dbo.m_detailict m_detailict_5 ON ((m_assetict.sw = m_detailict_5.sysid))) ON ((m_detailict_7.sysid = m_assetict.nx))) ON ((m_detailict_10.sysid = m_assetict.autocad)))
     LEFT JOIN dbo.m_detailict m_detailict_9 ON ((m_assetict.office = m_detailict_9.sysid)))
     RIGHT JOIN dbo.m_detailict m_detailict_8 ON ((m_assetict.os = m_detailict_8.sysid)))
     LEFT JOIN dbo.m_detailict m_detailict_6 ON ((m_assetict.processor = m_detailict_6.sysid)))
     LEFT JOIN dbo.m_detailict m_detailict_2 ON ((m_assetict.vgacard = m_detailict_2.sysid))) ON ((m_detailict_3.sysid = m_assetict.netcard)))
     LEFT JOIN dbo.m_detailict m_detailict_4 ON ((m_assetict.hdd = m_detailict_4.sysid))) ON ((m_detailict_1.sysid = m_assetict.ram)));


ALTER TABLE dbo.qmaster_asset OWNER TO postgres;

--
-- Name: qproduction_detailtrc; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.qproduction_detailtrc AS
 SELECT qcmproduct_bom.sysid,
    qcmproduct_bom.itemid_bom,
    qcmproduct_bom.itemid_product,
    qtd_transaction.docnum,
    qtd_transaction.detaildocnum AS docnumdetail,
    qtd_transaction.itemid,
    qtd_transaction.qty_1 AS qty,
    qtd_transaction.qty_4 AS ng,
    qtd_transaction.processd AS prosesd,
    qtd_transaction.processh AS prosesh,
    qtd_transaction.docdate,
    qtd_transaction.detaildate AS createdate,
    qtd_transaction.detailtime AS createtime,
    qtd_transaction.partno,
    qtd_transaction.partname,
    qtd_transaction.custname,
    qtd_transaction.remarkd AS remark,
    qtd_transaction.statusid AS status,
    qtd_transaction.idproject,
    qtd_transaction.projectname,
    qtd_transaction.code AS customer,
    qtd_transaction.duration AS durasi,
    qtd_transaction.lotno,
    qtd_transaction.vanno,
    qtd_transaction.isdelete,
    qtd_transaction.createby,
    qcmproduct_bom.sysid2,
    qcmproduct_bom.linkid
   FROM (dbo.qcmproduct_bom
     JOIN dbo.qtd_transaction ON ((qcmproduct_bom.itemid_product = qtd_transaction.itemid)));


ALTER TABLE dbo.qproduction_detailtrc OWNER TO postgres;

--
-- Name: qrm_detailtrc; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.qrm_detailtrc AS
 SELECT qcmproduct_bom.sysid,
    qcmproduct_bom.itemid_bom,
    qtd_transaction.detaildocnum,
    qtd_transaction.docdate,
    qtd_transaction.detaildate AS createdate,
    qtd_transaction.detailtime AS doctime,
    qtd_transaction.qty_1,
    qtd_transaction.itemid,
    qtd_transaction.partno,
    qtd_transaction.partname,
    qtd_transaction.spec1,
    qtd_transaction.spec2,
    qtd_transaction.idcust,
    qtd_transaction.custname,
    qtd_transaction.materialtype,
    qtd_transaction.sjnum,
    qtd_transaction.sjdate,
    qcmproduct_bom.itemid_product,
    qtd_transaction.docnum,
    qtd_transaction.code,
    qtd_transaction.createby,
    qtd_transaction.trctypeid,
    qtd_transaction.projectname,
    qcmproduct_bom.linkid
   FROM (dbo.qcmproduct_bom
     JOIN dbo.qtd_transaction ON ((qcmproduct_bom.itemid_product = qtd_transaction.itemid)));


ALTER TABLE dbo.qrm_detailtrc OWNER TO postgres;

--
-- Name: qtd_transaction1; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.qtd_transaction1 AS
 SELECT td_transaction.regid,
    td_transaction.trctypeid,
    td_transaction.monthid,
    td_transaction.trcid,
    td_transaction.lineid,
    td_transaction.itemid,
    td_transaction.qty_1,
    td_transaction.qty_2,
    td_transaction.qty_3,
    td_transaction.qty_4,
    td_transaction.qty_5,
    td_transaction.convertion_1,
    td_transaction.convertion_2,
    td_transaction.typeid,
    td_transaction.detaildate,
    td_transaction.detailtime,
    td_transaction.addressid,
    td_transaction.detaildocnum,
    td_transaction.starttime,
    td_transaction.endtime,
    td_transaction.duration,
    td_transaction.processd,
    td_transaction.processh,
    td_transaction.processid,
    td_transaction.addressdetail,
    td_transaction.remarkd,
    td_transaction.lotno,
    td_transaction.vanno,
    td_transaction.achievement,
    td_transaction.totaldt,
    td_transaction.totalps,
    td_transaction.gsph,
    td_transaction.createby,
    td_transaction.sjnum,
    td_transaction.sjdate,
    td_transaction.reffnum,
    td_transaction.matnum,
    td_transaction.isdelete,
    th_transaction.docnum,
    m_product.partno,
    m_product.partname,
    m_product.spec1,
    m_product.spec2,
    m_product.pcspersheet,
    m_product.pcsperkg,
    m_product.idcust,
    m_product.idproject,
    m_product.idcategory,
    m_department.dept_name,
    m_category.code AS category,
    m_category.category_name,
    m_userg5_1.username AS usercreate,
    m_project.projectname,
    m_materialtype.materialname,
    COALESCE(m_product.materialtype, (1)::bigint) AS materialtype,
    m_product.stockwip,
    COALESCE(m_product.stockfg, (0)::double precision) AS stockfg,
    m_product.idunit,
    m_unit.code AS codeunit,
    floor((td_transaction.qty_1 - td_transaction.qty_3)) AS canedit,
    th_transaction.docdate,
    th_transaction.docnum_2,
    th_transaction.partnerid,
    td_transaction_1.qty_3 AS balmatsource,
    td_transaction_1.qty_4 AS balpcssource,
    td_transaction_1.trctypeid AS trctypeid_from,
    td_transaction_1.monthid AS monthid_from,
    td_transaction_1.trcid AS trcid_from,
    td_transaction_1.lineid AS lineid_from,
    td_transaction_1.itemid AS itemidext,
    th_transaction.remarkh,
    th_transaction.statusid,
    th_transaction.userid,
    th_transaction.docnum_3,
    th_transaction.docdate_3,
    th_transaction.docdate_2,
    q01_mproduct.partno AS partno_from,
    q01_mproduct.partname AS partname_from,
    q01_mproduct.spec1 AS spec1_from,
    q01_mproduct.spec2 AS spec2_from,
    td_transaction.trctypeid_ext,
    td_transaction.monthid_ext,
    td_transaction.trcid_ext,
    td_transaction.lineid_ext,
    th_transaction.docdate_ext,
    td_transaction_1.convertion_1 AS convertion_1_from,
    td_transaction_1.convertion_2 AS convertion_2_from,
    td_transaction.amount,
    td_transaction.balamount,
    td_transaction.price,
    td_transaction_1.amount AS amountsource,
    td_transaction.partnerid AS partneriddetail,
    m_partner_1.partnercode AS partnercodedetail,
    m_partner_1.partnername AS partnernamedetail,
    m_partner_1.address AS partneraddressdetail,
    td_transaction_1.balamount AS balamountsource,
    td_transaction.op1,
    td_transaction.op2,
    m_userg5.fullname AS fullnametr,
    m_userg5.deptid AS deptidtr,
    td_transaction.picname,
    m_department_1.dept_name AS dept_nametr,
    m_partner_2.partnercode,
    m_partner_2.partnername,
    m_partner_2.address,
    m_partner.partnercode AS code,
    m_partner.partnername AS custname
   FROM ((((((((((dbo.m_partner
     RIGHT JOIN (dbo.m_product
     JOIN (dbo.td_transaction
     JOIN dbo.th_transaction ON (((th_transaction.trcid = td_transaction.trcid) AND (th_transaction.trctypeid = td_transaction.trctypeid) AND ((th_transaction.monthid)::bigint = td_transaction.monthid)))) ON ((m_product.regid = td_transaction.itemid))) ON ((m_partner.sysid = m_product.idcust)))
     LEFT JOIN dbo.m_partner m_partner_2 ON ((th_transaction.partnerid = m_partner_2.sysid)))
     LEFT JOIN dbo.m_partner m_partner_1 ON ((td_transaction.partnerid = m_partner_1.sysid)))
     RIGHT JOIN (dbo.m_userg5
     JOIN dbo.m_department m_department_1 ON ((m_userg5.deptid = m_department_1.id))) ON ((td_transaction.picname = m_userg5.sysid)))
     LEFT JOIN (dbo.m_department
     RIGHT JOIN dbo.m_userg5 m_userg5_1 ON ((m_department.id = m_userg5_1.deptid))) ON ((th_transaction.userid = m_userg5_1.sysid)))
     LEFT JOIN ((dbo.td_transaction td_transaction_1
     LEFT JOIN dbo.q01_mproduct ON ((td_transaction_1.itemid = q01_mproduct.regid)))
     RIGHT JOIN dbo.t_connecting ON (((td_transaction_1.trctypeid = t_connecting.trctypeid) AND (td_transaction_1.monthid = t_connecting.monthid) AND (td_transaction_1.trcid = t_connecting.trcid) AND (td_transaction_1.lineid = t_connecting.lineid)))) ON (((td_transaction.trctypeid = t_connecting.trctypeid_to) AND (td_transaction.monthid = t_connecting.monthid_to) AND (td_transaction.trcid = t_connecting.trcid_to) AND (td_transaction.lineid = t_connecting.lineid_to))))
     LEFT JOIN dbo.m_project ON ((m_project.regid = m_product.idproject)))
     LEFT JOIN dbo.m_materialtype ON ((m_materialtype.regid = m_product.materialtype)))
     LEFT JOIN dbo.m_unit ON ((m_unit.id = m_product.idunit)))
     LEFT JOIN dbo.m_category ON ((m_product.idcategory = m_category.id)))
  WHERE ((td_transaction.isdelete)::integer <> 1)
  ORDER BY td_transaction.regid DESC;


ALTER TABLE dbo.qtd_transaction1 OWNER TO postgres;

--
-- Name: qth_transaction; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.qth_transaction AS
 SELECT th.regid,
    th.docnum,
    th.docdate,
    th.createdate,
    m_userg5.username,
    th.trctypeid,
    th.monthid,
    th.trcid,
    th.userid,
    count(td.regid) AS totaldetail,
    th.partnerid,
    th.docnum_2,
    th.docdate_2,
    th.docnum_3,
    th.statusid,
    partner.address,
    th.remarkh,
    sum(td.qty_1) AS totalqty,
    th.doctime,
    partner.partnercode,
    partner.partnername,
    th.shiftid,
    th.op1,
    th.op2,
    th.fromareaid,
    th.lineid,
    th.picname,
    th.docdate_ext
   FROM (((dbo.th_transaction th
     LEFT JOIN dbo.m_partner partner ON ((th.partnerid = partner.sysid)))
     LEFT JOIN dbo.td_transaction td ON (((td.trcid = th.trcid) AND (td.trctypeid = th.trctypeid) AND (td.monthid = (th.monthid)::bigint))))
     LEFT JOIN dbo.m_userg5 m_userg5 ON ((m_userg5.sysid = th.userid)))
  WHERE ((td.isdelete)::integer <> 1)
  GROUP BY th.regid, th.docnum, th.docdate, th.createdate, m_userg5.username, th.trcid, th.userid, th.trctypeid, th.partnerid, th.docnum_2, th.docdate_2, th.docnum_3, th.monthid, th.statusid, partner.address, th.remarkh, th.doctime, partner.partnercode, partner.partnername, th.shiftid, th.op1, th.op2, th.fromareaid, th.lineid, th.picname, th.docdate_ext
 HAVING (count(td.regid) > 0);


ALTER TABLE dbo.qth_transaction OWNER TO postgres;

--
-- Name: t500_500; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t500_500 (
    c010_trctypeid smallint,
    c011_month smallint,
    c000_sysid smallint,
    c050_rev smallint,
    c013_trctypesrcid smallint,
    c018_flowtypeid smallint,
    c034_trctypeid_to smallint,
    c035_month_to smallint,
    c036_trcid_to smallint,
    c050_rev_to smallint,
    c016_contentflowid smallint
);


ALTER TABLE dbo.t500_500 OWNER TO postgres;

--
-- Name: qtrace_docnum; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.qtrace_docnum AS
 SELECT t500_proc.c050_docnum AS docnum,
    t500_proc.c050_docdate AS docdate,
    t500_proc.c045_username AS username,
    t500_proc_1.c050_docnum AS docnum2,
    t500_proc_1.c050_docdate AS docdate2,
    t500_proc_1.c045_username AS username2,
    t500_500.c010_trctypeid,
    t500_500.c011_month,
    t500_500.c000_sysid,
    t500_500.c050_rev,
    t500_500.c034_trctypeid_to,
    t500_500.c035_month_to,
    t500_500.c036_trcid_to,
    t500_500.c050_rev_to,
    t500_proc.c013_draftreadyapprcancel,
    t500_proc_1.c060_partnerid
   FROM ((dbo.t500_proc
     JOIN dbo.t500_500 ON (((t500_proc.c010_trctypeid = t500_500.c010_trctypeid) AND (t500_proc.c011_month = t500_500.c011_month) AND (t500_proc.c000_sysid = t500_500.c000_sysid) AND (t500_proc.c050_rev = t500_500.c050_rev))))
     JOIN dbo.t500_proc t500_proc_1 ON (((t500_500.c034_trctypeid_to = t500_proc_1.c010_trctypeid) AND (t500_500.c035_month_to = t500_proc_1.c011_month) AND (t500_500.c036_trcid_to = t500_proc_1.c000_sysid) AND (t500_500.c050_rev_to = t500_proc_1.c050_rev))));


ALTER TABLE dbo.qtrace_docnum OWNER TO postgres;

--
-- Name: scga_in; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.scga_in AS
 SELECT qtd_transaction.docnum,
    qtd_transaction.detaildocnum,
    qtd_transaction.docdate,
    qtd_transaction.itemid,
    qtd_transaction.partno,
    qtd_transaction.partname,
    qtd_transaction.qty_1 AS inmat,
    COALESCE(qtd_transaction.qty_5, (0)::double precision) AS outmat,
    qtd_transaction.idcust,
    qtd_transaction.code,
    qtd_transaction.custname,
    qtd_transaction.spec1,
    qtd_transaction.spec2,
    qtd_transaction.pcspersheet,
    qtd_transaction.pcsperkg,
    qtd_transaction.detailtime AS doctime,
    qtd_transaction.qty_3 AS balmat,
    qtd_transaction.qty_4 AS balpcs,
    qtd_transaction.regid,
    qtd_transaction.trctypeid,
    qtd_transaction.monthid,
    qtd_transaction.trcid,
    qtd_transaction.lineid,
    qtd_transaction.amount,
    qtd_transaction.balamount
   FROM dbo.qtd_transaction
  WHERE (qtd_transaction.trctypeid = 600)
  ORDER BY qtd_transaction.docdate;


ALTER TABLE dbo.scga_in OWNER TO postgres;

--
-- Name: scga_out; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.scga_out AS
 SELECT qtd_transaction.docnum,
    qtd_transaction.detaildocnum,
    qtd_transaction.docdate,
    qtd_transaction.itemid,
    qtd_transaction.partno,
    qtd_transaction.partname,
    qtd_transaction.qty_1 AS outmat,
    COALESCE(qtd_transaction.qty_5, (0)::double precision) AS inmat,
    qtd_transaction.idcust,
    qtd_transaction.code,
    qtd_transaction.custname,
    qtd_transaction.spec1,
    qtd_transaction.spec2,
    qtd_transaction.pcspersheet,
    qtd_transaction.pcsperkg,
    qtd_transaction.detailtime AS doctime,
    qtd_transaction.qty_3 AS balmat,
    qtd_transaction.qty_4 AS balpcs,
    qtd_transaction.regid,
    qtd_transaction.trctypeid,
    qtd_transaction.monthid,
    qtd_transaction.trcid,
    qtd_transaction.lineid,
    qtd_transaction.amount,
    qtd_transaction.balamount
   FROM dbo.qtd_transaction
  WHERE (qtd_transaction.trctypeid = 700)
  ORDER BY qtd_transaction.docdate;


ALTER TABLE dbo.scga_out OWNER TO postgres;

--
-- Name: scga_ext; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.scga_ext AS
 SELECT scga_in.docnum,
    scga_in.detaildocnum,
    scga_in.docdate,
    scga_in.itemid,
    scga_in.partno,
    scga_in.partname,
    scga_in.inmat,
    scga_in.outmat,
    scga_in.idcust,
    scga_in.code,
    scga_in.custname,
    scga_in.spec1,
    scga_in.spec2,
    scga_in.pcspersheet,
    scga_in.pcsperkg,
    scga_in.doctime,
    scga_in.trctypeid,
    scga_in.monthid,
    scga_in.trcid,
    scga_in.lineid,
    scga_in.amount,
    scga_in.balamount
   FROM dbo.scga_in
UNION
 SELECT scga_out.docnum,
    scga_out.detaildocnum,
    scga_out.docdate,
    scga_out.itemid,
    scga_out.partno,
    scga_out.partname,
    scga_out.inmat,
    scga_out.outmat,
    scga_out.idcust,
    scga_out.code,
    scga_out.custname,
    scga_out.spec1,
    scga_out.spec2,
    scga_out.pcspersheet,
    scga_out.pcsperkg,
    scga_out.doctime,
    scga_out.trctypeid,
    scga_out.monthid,
    scga_out.trcid,
    scga_out.lineid,
    scga_out.amount,
    scga_out.balamount
   FROM dbo.scga_out;


ALTER TABLE dbo.scga_ext OWNER TO postgres;

--
-- Name: scga; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.scga AS
 SELECT scga_ext.docnum,
    scga_ext.detaildocnum,
    scga_ext.docdate,
    scga_ext.doctime,
    scga_ext.itemid,
    scga_ext.partno,
    scga_ext.partname,
    scga_ext.inmat,
    scga_ext.outmat,
    scga_ext.idcust,
    scga_ext.code,
    scga_ext.custname,
    scga_ext.spec1,
    scga_ext.spec2,
    scga_ext.pcspersheet,
    scga_ext.pcsperkg,
    scga_ext.trctypeid,
    scga_ext.monthid,
    scga_ext.trcid,
    scga_ext.lineid,
    scga_ext.amount,
    scga_ext.balamount,
    m_category.category_name AS category
   FROM ((dbo.m_category
     RIGHT JOIN dbo.m_product ON ((m_category.id = m_product.idcategory)))
     RIGHT JOIN dbo.scga_ext ON ((m_product.regid = scga_ext.itemid)))
  ORDER BY scga_ext.docdate, scga_ext.doctime;


ALTER TABLE dbo.scga OWNER TO postgres;

--
-- Name: scict_in; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.scict_in AS
 SELECT qtd_transaction.docnum,
    qtd_transaction.detaildocnum,
    qtd_transaction.docdate,
    qtd_transaction.itemid,
    qtd_transaction.partno,
    qtd_transaction.partname,
    qtd_transaction.qty_1 AS inmat,
    COALESCE(qtd_transaction.qty_5, (0)::double precision) AS outmat,
    qtd_transaction.idcust,
    qtd_transaction.code,
    qtd_transaction.custname,
    qtd_transaction.spec1,
    qtd_transaction.spec2,
    qtd_transaction.pcspersheet,
    qtd_transaction.pcsperkg,
    qtd_transaction.detailtime AS doctime,
    qtd_transaction.qty_3 AS balmat,
    qtd_transaction.qty_4 AS balpcs,
    qtd_transaction.regid,
    qtd_transaction.trctypeid,
    qtd_transaction.monthid,
    qtd_transaction.trcid,
    qtd_transaction.lineid,
    qtd_transaction.amount,
    qtd_transaction.balamount
   FROM dbo.qtd_transaction
  WHERE (qtd_transaction.trctypeid = 800)
  ORDER BY qtd_transaction.docdate;


ALTER TABLE dbo.scict_in OWNER TO postgres;

--
-- Name: scict_out; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.scict_out AS
 SELECT qtd_transaction.docnum,
    qtd_transaction.detaildocnum,
    qtd_transaction.docdate,
    qtd_transaction.itemid,
    qtd_transaction.partno,
    qtd_transaction.partname,
    qtd_transaction.qty_1 AS outmat,
    COALESCE(qtd_transaction.qty_5, (0)::double precision) AS inmat,
    qtd_transaction.idcust,
    qtd_transaction.code,
    qtd_transaction.custname,
    qtd_transaction.spec1,
    qtd_transaction.spec2,
    qtd_transaction.pcspersheet,
    qtd_transaction.pcsperkg,
    qtd_transaction.detailtime AS doctime,
    qtd_transaction.qty_3 AS balmat,
    qtd_transaction.qty_4 AS balpcs,
    qtd_transaction.regid,
    qtd_transaction.trctypeid,
    qtd_transaction.monthid,
    qtd_transaction.trcid,
    qtd_transaction.lineid,
    qtd_transaction.amount,
    qtd_transaction.balamount
   FROM dbo.qtd_transaction
  WHERE (qtd_transaction.trctypeid = 900)
  ORDER BY qtd_transaction.docdate;


ALTER TABLE dbo.scict_out OWNER TO postgres;

--
-- Name: scict_ext; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.scict_ext AS
 SELECT scict_in.docnum,
    scict_in.detaildocnum,
    scict_in.docdate,
    scict_in.itemid,
    scict_in.partno,
    scict_in.partname,
    scict_in.inmat,
    scict_in.outmat,
    scict_in.idcust,
    scict_in.code,
    scict_in.custname,
    scict_in.spec1,
    scict_in.spec2,
    scict_in.pcspersheet,
    scict_in.pcsperkg,
    scict_in.doctime,
    scict_in.trctypeid,
    scict_in.monthid,
    scict_in.trcid,
    scict_in.lineid,
    scict_in.amount,
    scict_in.balamount
   FROM dbo.scict_in
UNION
 SELECT scict_out.docnum,
    scict_out.detaildocnum,
    scict_out.docdate,
    scict_out.itemid,
    scict_out.partno,
    scict_out.partname,
    scict_out.inmat,
    scict_out.outmat,
    scict_out.idcust,
    scict_out.code,
    scict_out.custname,
    scict_out.spec1,
    scict_out.spec2,
    scict_out.pcspersheet,
    scict_out.pcsperkg,
    scict_out.doctime,
    scict_out.trctypeid,
    scict_out.monthid,
    scict_out.trcid,
    scict_out.lineid,
    scict_out.amount,
    scict_out.balamount
   FROM dbo.scict_out;


ALTER TABLE dbo.scict_ext OWNER TO postgres;

--
-- Name: scict; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.scict AS
 SELECT scict_ext.docnum,
    scict_ext.detaildocnum,
    scict_ext.docdate,
    scict_ext.doctime,
    scict_ext.itemid,
    scict_ext.partno,
    scict_ext.partname,
    scict_ext.inmat,
    scict_ext.outmat,
    scict_ext.idcust,
    scict_ext.code,
    scict_ext.custname,
    scict_ext.spec1,
    scict_ext.spec2,
    scict_ext.pcspersheet,
    scict_ext.pcsperkg,
    scict_ext.trctypeid,
    scict_ext.monthid,
    scict_ext.trcid,
    scict_ext.lineid,
    scict_ext.amount,
    scict_ext.balamount,
    m_category.category_name AS category
   FROM ((dbo.m_category
     RIGHT JOIN dbo.m_product ON ((m_category.id = m_product.idcategory)))
     RIGHT JOIN dbo.scict_ext ON ((m_product.regid = scict_ext.itemid)))
  ORDER BY scict_ext.docdate, scict_ext.doctime;


ALTER TABLE dbo.scict OWNER TO postgres;

--
-- Name: scmaterial_out; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.scmaterial_out AS
 SELECT qtd_transaction.docnum,
    qtd_transaction.detaildocnum,
    qtd_transaction.docdate,
    qtd_transaction.itemid,
    qtd_transaction.partno,
    qtd_transaction.partname,
    qtd_transaction.qty_1 AS outmat,
    COALESCE(qtd_transaction.qty_5, (0)::double precision) AS inmat,
    qtd_transaction.idcust,
    qtd_transaction.code,
    qtd_transaction.custname,
    qtd_transaction.spec1,
    qtd_transaction.spec2,
    qtd_transaction.pcspersheet,
    qtd_transaction.pcsperkg,
    qtd_transaction.detailtime AS doctime,
    qtd_transaction.qty_3 AS balmat,
    qtd_transaction.qty_4 AS balpcs,
    qtd_transaction.regid,
    qtd_transaction.trctypeid,
    qtd_transaction.monthid,
    qtd_transaction.trcid,
    qtd_transaction.lineid
   FROM dbo.qtd_transaction
  WHERE ((qtd_transaction.trctypeid = 200) OR (qtd_transaction.trctypeid = 210) OR (qtd_transaction.trctypeid = 215) OR (qtd_transaction.trctypeid = 220) OR (qtd_transaction.trctypeid = 225))
  ORDER BY qtd_transaction.docdate;


ALTER TABLE dbo.scmaterial_out OWNER TO postgres;

--
-- Name: scrawmaterial_ext; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.scrawmaterial_ext AS
 SELECT scmaterial_in.docnum,
    scmaterial_in.detaildocnum,
    scmaterial_in.docdate,
    scmaterial_in.itemid,
    scmaterial_in.partno,
    scmaterial_in.partname,
    scmaterial_in.inmat,
    scmaterial_in.outmat,
    scmaterial_in.idcust,
    scmaterial_in.code,
    scmaterial_in.custname,
    scmaterial_in.spec1,
    scmaterial_in.spec2,
    scmaterial_in.pcspersheet,
    scmaterial_in.pcsperkg,
    scmaterial_in.doctime,
    scmaterial_in.trctypeid,
    scmaterial_in.monthid,
    scmaterial_in.trcid,
    scmaterial_in.lineid
   FROM dbo.scmaterial_in
UNION
 SELECT scmaterial_out.docnum,
    scmaterial_out.detaildocnum,
    scmaterial_out.docdate,
    scmaterial_out.itemid,
    scmaterial_out.partno,
    scmaterial_out.partname,
    scmaterial_out.inmat,
    scmaterial_out.outmat,
    scmaterial_out.idcust,
    scmaterial_out.code,
    scmaterial_out.custname,
    scmaterial_out.spec1,
    scmaterial_out.spec2,
    scmaterial_out.pcspersheet,
    scmaterial_out.pcsperkg,
    scmaterial_out.doctime,
    scmaterial_out.trctypeid,
    scmaterial_out.monthid,
    scmaterial_out.trcid,
    scmaterial_out.lineid
   FROM dbo.scmaterial_out;


ALTER TABLE dbo.scrawmaterial_ext OWNER TO postgres;

--
-- Name: scrawmaterial; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.scrawmaterial AS
 SELECT scrawmaterial_ext.docnum,
    scrawmaterial_ext.detaildocnum,
    scrawmaterial_ext.docdate,
    scrawmaterial_ext.doctime,
    scrawmaterial_ext.itemid,
    scrawmaterial_ext.partno,
    scrawmaterial_ext.partname,
    scrawmaterial_ext.inmat,
    scrawmaterial_ext.outmat,
    scrawmaterial_ext.idcust,
    scrawmaterial_ext.code,
    scrawmaterial_ext.custname,
    scrawmaterial_ext.spec1,
    scrawmaterial_ext.spec2,
    scrawmaterial_ext.pcspersheet,
    scrawmaterial_ext.pcsperkg,
    scrawmaterial_ext.trctypeid,
    scrawmaterial_ext.monthid,
    scrawmaterial_ext.trcid,
    scrawmaterial_ext.lineid
   FROM dbo.scrawmaterial_ext
  ORDER BY scrawmaterial_ext.docdate, scrawmaterial_ext.doctime;


ALTER TABLE dbo.scrawmaterial OWNER TO postgres;

--
-- Name: sctoolroom_in; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.sctoolroom_in AS
 SELECT qtd_transaction.docnum,
    qtd_transaction.detaildocnum,
    qtd_transaction.docdate,
    qtd_transaction.itemid,
    qtd_transaction.partno,
    qtd_transaction.partname,
    qtd_transaction.qty_1 AS inmat,
    COALESCE(qtd_transaction.qty_5, (0)::double precision) AS outmat,
    qtd_transaction.idcust,
    qtd_transaction.code,
    qtd_transaction.custname,
    qtd_transaction.spec1,
    qtd_transaction.spec2,
    qtd_transaction.pcspersheet,
    qtd_transaction.pcsperkg,
    qtd_transaction.detailtime AS doctime,
    qtd_transaction.qty_3 AS balmat,
    qtd_transaction.qty_4 AS balpcs,
    qtd_transaction.regid,
    qtd_transaction.trctypeid,
    qtd_transaction.monthid,
    qtd_transaction.trcid,
    qtd_transaction.lineid,
    qtd_transaction.amount,
    qtd_transaction.balamount
   FROM dbo.qtd_transaction
  WHERE (qtd_transaction.trctypeid = 400)
  ORDER BY qtd_transaction.docdate;


ALTER TABLE dbo.sctoolroom_in OWNER TO postgres;

--
-- Name: sctoolroom_out; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.sctoolroom_out AS
 SELECT qtd_transaction.docnum,
    qtd_transaction.detaildocnum,
    qtd_transaction.docdate,
    qtd_transaction.itemid,
    qtd_transaction.partno,
    qtd_transaction.partname,
    qtd_transaction.qty_1 AS outmat,
    COALESCE(qtd_transaction.qty_5, (0)::double precision) AS inmat,
    qtd_transaction.idcust,
    qtd_transaction.code,
    qtd_transaction.custname,
    qtd_transaction.spec1,
    qtd_transaction.spec2,
    qtd_transaction.pcspersheet,
    qtd_transaction.pcsperkg,
    qtd_transaction.detailtime AS doctime,
    qtd_transaction.qty_3 AS balmat,
    qtd_transaction.qty_4 AS balpcs,
    qtd_transaction.regid,
    qtd_transaction.trctypeid,
    qtd_transaction.monthid,
    qtd_transaction.trcid,
    qtd_transaction.lineid,
    qtd_transaction.amount,
    qtd_transaction.balamount
   FROM dbo.qtd_transaction
  WHERE (qtd_transaction.trctypeid = 500)
  ORDER BY qtd_transaction.docdate;


ALTER TABLE dbo.sctoolroom_out OWNER TO postgres;

--
-- Name: sctoolroom_ext; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.sctoolroom_ext AS
 SELECT sctoolroom_in.docnum,
    sctoolroom_in.detaildocnum,
    sctoolroom_in.docdate,
    sctoolroom_in.itemid,
    sctoolroom_in.partno,
    sctoolroom_in.partname,
    sctoolroom_in.inmat,
    sctoolroom_in.outmat,
    sctoolroom_in.idcust,
    sctoolroom_in.code,
    sctoolroom_in.custname,
    sctoolroom_in.spec1,
    sctoolroom_in.spec2,
    sctoolroom_in.pcspersheet,
    sctoolroom_in.pcsperkg,
    sctoolroom_in.doctime,
    sctoolroom_in.trctypeid,
    sctoolroom_in.monthid,
    sctoolroom_in.trcid,
    sctoolroom_in.lineid,
    sctoolroom_in.amount,
    sctoolroom_in.balamount
   FROM dbo.sctoolroom_in
UNION
 SELECT sctoolroom_out.docnum,
    sctoolroom_out.detaildocnum,
    sctoolroom_out.docdate,
    sctoolroom_out.itemid,
    sctoolroom_out.partno,
    sctoolroom_out.partname,
    sctoolroom_out.inmat,
    sctoolroom_out.outmat,
    sctoolroom_out.idcust,
    sctoolroom_out.code,
    sctoolroom_out.custname,
    sctoolroom_out.spec1,
    sctoolroom_out.spec2,
    sctoolroom_out.pcspersheet,
    sctoolroom_out.pcsperkg,
    sctoolroom_out.doctime,
    sctoolroom_out.trctypeid,
    sctoolroom_out.monthid,
    sctoolroom_out.trcid,
    sctoolroom_out.lineid,
    sctoolroom_out.amount,
    sctoolroom_out.balamount
   FROM dbo.sctoolroom_out;


ALTER TABLE dbo.sctoolroom_ext OWNER TO postgres;

--
-- Name: sctoolroom; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.sctoolroom AS
 SELECT sctoolroom_ext.docnum,
    sctoolroom_ext.detaildocnum,
    sctoolroom_ext.docdate,
    sctoolroom_ext.doctime,
    sctoolroom_ext.itemid,
    sctoolroom_ext.partno,
    sctoolroom_ext.partname,
    sctoolroom_ext.inmat,
    sctoolroom_ext.outmat,
    sctoolroom_ext.idcust,
    sctoolroom_ext.code,
    sctoolroom_ext.custname,
    sctoolroom_ext.spec1,
    sctoolroom_ext.spec2,
    sctoolroom_ext.pcspersheet,
    sctoolroom_ext.pcsperkg,
    sctoolroom_ext.trctypeid,
    sctoolroom_ext.monthid,
    sctoolroom_ext.trcid,
    sctoolroom_ext.lineid,
    sctoolroom_ext.amount,
    sctoolroom_ext.balamount,
    m_category.category_name AS category
   FROM ((dbo.m_category
     RIGHT JOIN dbo.m_product ON ((m_category.id = m_product.idcategory)))
     RIGHT JOIN dbo.sctoolroom_ext ON ((m_product.regid = sctoolroom_ext.itemid)))
  ORDER BY sctoolroom_ext.docdate, sctoolroom_ext.doctime;


ALTER TABLE dbo.sctoolroom OWNER TO postgres;

--
-- Name: scwip_in; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.scwip_in AS
 SELECT qtd_transaction.docnum,
    qtd_transaction.detaildocnum,
    qtd_transaction.docdate,
    qtd_transaction.itemid,
    qtd_transaction.partno,
    qtd_transaction.partname,
    qtd_transaction.qty_1 AS inmat,
    0 AS outmat,
    qtd_transaction.idcust,
    qtd_transaction.code,
    qtd_transaction.custname,
    qtd_transaction.spec1,
    qtd_transaction.spec2,
    qtd_transaction.pcspersheet,
    qtd_transaction.pcsperkg,
    qtd_transaction.detailtime AS doctime,
    qtd_transaction.qty_3 AS balmat,
    qtd_transaction.qty_4 AS balpcs,
    qtd_transaction.regid,
    qtd_transaction.trctypeid,
    qtd_transaction.monthid,
    qtd_transaction.trcid,
    qtd_transaction.lineid
   FROM dbo.qtd_transaction
  WHERE (qtd_transaction.trctypeid = 1200)
  ORDER BY qtd_transaction.docdate;


ALTER TABLE dbo.scwip_in OWNER TO postgres;

--
-- Name: scwip_out; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.scwip_out AS
 SELECT qtd_transaction.docnum,
    qtd_transaction.detaildocnum,
    qtd_transaction.docdate,
    qtd_transaction.itemid,
    qtd_transaction.partno,
    qtd_transaction.partname,
    qtd_transaction.qty_1 AS outmat,
    0 AS inmat,
    qtd_transaction.idcust,
    qtd_transaction.code,
    qtd_transaction.custname,
    qtd_transaction.spec1,
    qtd_transaction.spec2,
    qtd_transaction.pcspersheet,
    qtd_transaction.pcsperkg,
    qtd_transaction.detailtime AS doctime,
    qtd_transaction.qty_3 AS balmat,
    qtd_transaction.qty_4 AS balpcs,
    qtd_transaction.regid,
    qtd_transaction.trctypeid,
    qtd_transaction.monthid,
    qtd_transaction.trcid,
    qtd_transaction.lineid
   FROM dbo.qtd_transaction
  WHERE (qtd_transaction.trctypeid = 1300)
  ORDER BY qtd_transaction.docdate;


ALTER TABLE dbo.scwip_out OWNER TO postgres;

--
-- Name: scwip_ext; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.scwip_ext AS
 SELECT scwip_in.docnum,
    scwip_in.detaildocnum,
    scwip_in.docdate,
    scwip_in.itemid,
    scwip_in.partno,
    scwip_in.partname,
    scwip_in.inmat,
    scwip_in.outmat,
    scwip_in.idcust,
    scwip_in.code,
    scwip_in.custname,
    scwip_in.spec1,
    scwip_in.spec2,
    scwip_in.pcspersheet,
    scwip_in.pcsperkg,
    scwip_in.doctime,
    scwip_in.trctypeid,
    scwip_in.monthid,
    scwip_in.trcid,
    scwip_in.lineid
   FROM dbo.scwip_in
UNION
 SELECT scwip_out.docnum,
    scwip_out.detaildocnum,
    scwip_out.docdate,
    scwip_out.itemid,
    scwip_out.partno,
    scwip_out.partname,
    scwip_out.inmat,
    scwip_out.outmat,
    scwip_out.idcust,
    scwip_out.code,
    scwip_out.custname,
    scwip_out.spec1,
    scwip_out.spec2,
    scwip_out.pcspersheet,
    scwip_out.pcsperkg,
    scwip_out.doctime,
    scwip_out.trctypeid,
    scwip_out.monthid,
    scwip_out.trcid,
    scwip_out.lineid
   FROM dbo.scwip_out;


ALTER TABLE dbo.scwip_ext OWNER TO postgres;

--
-- Name: scwip; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.scwip AS
 SELECT scwip_ext.docnum,
    scwip_ext.detaildocnum,
    scwip_ext.docdate,
    scwip_ext.doctime,
    scwip_ext.itemid,
    scwip_ext.partno,
    scwip_ext.partname,
    scwip_ext.inmat,
    scwip_ext.outmat,
    scwip_ext.idcust,
    scwip_ext.code,
    scwip_ext.custname,
    scwip_ext.spec1,
    scwip_ext.spec2,
    scwip_ext.pcspersheet,
    scwip_ext.pcsperkg,
    scwip_ext.trctypeid,
    scwip_ext.monthid,
    scwip_ext.trcid,
    scwip_ext.lineid
   FROM dbo.scwip_ext
  ORDER BY scwip_ext.docdate, scwip_ext.doctime;


ALTER TABLE dbo.scwip OWNER TO postgres;

--
-- Name: stockga; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.stockga AS
 SELECT m_product.regid AS itemid,
    m_product.partno,
    m_product.partname,
    m_product.spec1,
    m_product.spec2,
    m_product.pcspersheet,
    m_product.pcsperkg,
    m_product.idcust,
    m_product.idproject,
    m_product.idcategory,
    m_product.isga,
    m_product.isactive,
    m_product.price,
    m_product.pcsperday,
    m_product.min,
    m_product.max,
    m_customer.code,
    m_customer.custname,
    COALESCE(sum(scga_in.balmat), (0)::double precision) AS balmat,
    COALESCE(sum(scga_in.balpcs), (0)::double precision) AS balpcs,
    sum(scga_in.amount) AS amount,
    sum(scga_in.balamount) AS balamount,
    m_category.category_name AS category
   FROM (((dbo.m_product
     LEFT JOIN dbo.m_category ON ((m_product.idcategory = m_category.id)))
     LEFT JOIN dbo.scga_in ON ((m_product.regid = scga_in.itemid)))
     LEFT JOIN dbo.m_customer ON ((m_product.idcust = m_customer.regid)))
  GROUP BY m_product.regid, m_product.partno, m_product.partname, m_product.spec1, m_product.spec2, m_product.pcspersheet, m_product.pcsperkg, m_product.idcust, m_product.idproject, m_product.idcategory, m_product.isga, m_product.isstoreroom, m_product.isactive, m_product.price, m_product.pcsperday, m_product.min, m_product.max, m_customer.code, m_customer.custname, m_category.category_name
 HAVING ((m_product.isactive = 1) AND (m_product.isga = 1));


ALTER TABLE dbo.stockga OWNER TO postgres;

--
-- Name: stockict; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.stockict AS
 SELECT m_product.regid AS itemid,
    m_product.partno,
    m_product.partname,
    m_product.spec1,
    m_product.spec2,
    m_product.pcspersheet,
    m_product.pcsperkg,
    m_product.idcust,
    m_product.idproject,
    m_product.idcategory,
    m_product.isict,
    m_product.isactive,
    m_product.price,
    m_product.pcsperday,
    m_product.min,
    m_product.max,
    m_customer.code,
    m_customer.custname,
    COALESCE(sum(scict_in.balmat), (0)::double precision) AS balmat,
    COALESCE(sum(scict_in.balpcs), (0)::double precision) AS balpcs,
    sum(scict_in.amount) AS amount,
    sum(scict_in.balamount) AS balamount,
    m_category.category_name AS category
   FROM (((dbo.m_product
     LEFT JOIN dbo.m_category ON ((m_product.idcategory = m_category.id)))
     LEFT JOIN dbo.scict_in ON ((m_product.regid = scict_in.itemid)))
     LEFT JOIN dbo.m_customer ON ((m_product.idcust = m_customer.regid)))
  GROUP BY m_product.regid, m_product.partno, m_product.partname, m_product.spec1, m_product.spec2, m_product.pcspersheet, m_product.pcsperkg, m_product.idcust, m_product.idproject, m_product.idcategory, m_product.isict, m_product.isstoreroom, m_product.isactive, m_product.price, m_product.pcsperday, m_product.min, m_product.max, m_customer.code, m_customer.custname, m_category.category_name
 HAVING ((m_product.isactive = 1) AND (m_product.isict = 1));


ALTER TABLE dbo.stockict OWNER TO postgres;

--
-- Name: stocktr; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.stocktr AS
 SELECT m_product.regid AS itemid,
    m_product.partno,
    m_product.partname,
    m_product.spec1,
    m_product.spec2,
    m_product.pcspersheet,
    m_product.pcsperkg,
    m_product.idcust,
    m_product.idproject,
    m_product.idcategory,
    m_product.isstoreroom,
    m_product.isactive,
    m_product.price,
    m_product.pcsperday,
    m_product.min,
    m_product.max,
    m_customer.code,
    m_customer.custname,
    COALESCE(sum(sctoolroom_in.balmat), (0)::double precision) AS balmat,
    COALESCE(sum(sctoolroom_in.balpcs), (0)::double precision) AS balpcs,
    sum(sctoolroom_in.amount) AS amount,
    sum(sctoolroom_in.balamount) AS balamount,
    m_category.category_name AS category
   FROM (((dbo.m_product
     LEFT JOIN dbo.m_category ON ((m_product.idcategory = m_category.id)))
     LEFT JOIN dbo.sctoolroom_in ON ((m_product.regid = sctoolroom_in.itemid)))
     LEFT JOIN dbo.m_customer ON ((m_product.idcust = m_customer.regid)))
  GROUP BY m_product.regid, m_product.partno, m_product.partname, m_product.spec1, m_product.spec2, m_product.pcspersheet, m_product.pcsperkg, m_product.idcust, m_product.idproject, m_product.idcategory, m_product.isstoreroom, m_product.isactive, m_product.price, m_product.pcsperday, m_product.min, m_product.max, m_customer.code, m_customer.custname, m_category.category_name
 HAVING ((m_product.isactive = 1) AND (m_product.isstoreroom = 1));


ALTER TABLE dbo.stocktr OWNER TO postgres;

--
-- Name: sumrm; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.sumrm AS
 SELECT qtd_transaction.itemid,
    qtd_transaction.qty_1 AS qtymat,
    qtd_transaction.docdate,
    qtd_transaction.trctypeid
   FROM dbo.qtd_transaction;


ALTER TABLE dbo.sumrm OWNER TO postgres;

--
-- Name: t040_addressdlv; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t040_addressdlv (
    sysid integer,
    partnerid integer,
    titleaddres character varying(20),
    address character varying(200),
    city character varying(50),
    postcode character varying(50),
    country character varying(50),
    currencyid integer,
    priceperiodactiveid integer,
    isbilling boolean,
    isoffice boolean,
    isdelivery boolean,
    phone character varying(50),
    fax character varying(50)
);


ALTER TABLE dbo.t040_addressdlv OWNER TO postgres;

--
-- Name: t064_prtype; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t064_prtype (
    trctypeid smallint,
    prtype character varying(50)
);


ALTER TABLE dbo.t064_prtype OWNER TO postgres;

--
-- Name: t500_assource; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t500_assource (
    c010_trctypeid smallint,
    c011_month smallint,
    c000_sysid integer,
    c050_rev smallint,
    c012_trcopenclose smallint,
    c012_dtlocked timestamp with time zone,
    c012_lockuser integer,
    c012_responded smallint,
    c013_trctypesrcid smallint,
    c014_actmgrid smallint,
    c016_contentflowid smallint,
    c017_usergrpflowid smallint,
    c018_flowtypeid smallint,
    c019_actmgrdestid smallint,
    c045_userid integer,
    c045_dtime timestamp with time zone,
    c050_docnum character varying(25),
    c050_docdate timestamp without time zone,
    c060_partnerid smallint,
    usermarkingid integer
);


ALTER TABLE dbo.t500_assource OWNER TO postgres;

--
-- Name: t500_lastact; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t500_lastact (
    c010_trctypeid integer,
    c011_month smallint,
    c000_sysid integer,
    c050_rev smallint,
    c045_userid integer
);


ALTER TABLE dbo.t500_lastact OWNER TO postgres;

--
-- Name: t500_node; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t500_node (
    c010_trctypeid integer,
    c011_month smallint,
    c000_sysid integer,
    c050_rev smallint,
    c013_trctypesrcid smallint,
    c013_draftreadyapprcancel smallint,
    c014_actmgrid smallint,
    c017_usergrpflowid_from smallint,
    c017_usergrpflowid_to smallint,
    c017_usergrpflowfrom character varying(25),
    c017_usergrpflowto character varying(25),
    c018_flowtypeid smallint,
    c018_kanbanpostid smallint,
    c020_nodehistoryid_active smallint,
    c045_userid integer,
    c045_username character varying(25),
    c045_dtime timestamp with time zone,
    c045_usernameupdate character varying(25),
    c045_dtimelasupdate timestamp with time zone,
    c050_docnum character varying(25),
    c050_docdate timestamp without time zone,
    c050_accountdate timestamp without time zone,
    c050_extdocnum character varying(50),
    c050_extdocdate timestamp without time zone,
    c060_partnerid smallint
);


ALTER TABLE dbo.t500_node OWNER TO postgres;

--
-- Name: t500_temp; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t500_temp (
    c010_trctypeid integer,
    c011_month smallint,
    c000_sysid integer,
    c050_rev smallint,
    c013_trctypesrcid smallint,
    c013_draftreadyapprcancel smallint,
    c014_actmgrid smallint,
    c017_usergrpflowid_from smallint,
    c017_usergrpflowid_to smallint,
    c017_usergrpflowfrom character varying(25),
    c017_usergrpflowto character varying(25),
    c018_flowtypeid smallint,
    c018_kanbanpostid smallint,
    c045_userid integer,
    c045_username character varying(25),
    c045_dtime timestamp with time zone,
    c045_usernameupdate character varying(25),
    c045_dtimelasupdate timestamp with time zone,
    c050_docnum character varying(25),
    c050_docdate timestamp without time zone,
    c050_accountdate timestamp without time zone,
    c050_extdocnum character varying(50),
    c050_extdocdate timestamp without time zone,
    c050_extdocnum1 character varying(25),
    c050_extdocdate1 timestamp without time zone,
    c051_ponum character varying(30),
    c051_fakturnum character varying(100),
    c051_fakturdatetax timestamp without time zone,
    c051_duedate timestamp without time zone,
    c052_termofpayment smallint,
    c059_remark character varying(1000),
    c060_partnerid smallint,
    c061_picname character varying(50),
    c062_actfixedassetid integer,
    c070_currencyid smallint,
    c071_rate double precision,
    c072_ratetax double precision,
    c073_amount double precision,
    c073_amountbruto double precision,
    c074_amountdiscount double precision,
    c074_expense double precision,
    c075_amountppn double precision,
    c075_amountpph double precision,
    c076_amountfinal double precision,
    c077_amountbalance double precision,
    c078_amountprepaid double precision,
    c079_amountgrnotinv double precision,
    c080_prcategoryid smallint,
    c085_isppn boolean,
    c090_estdlvdate timestamp without time zone,
    c113_prtype smallint,
    sledgerid smallint,
    mledgerid smallint,
    subledger1id smallint,
    subledger2id smallint,
    postcategoryid smallint,
    remark_pr character varying(1000),
    yearidx smallint,
    deptid smallint
);


ALTER TABLE dbo.t500_temp OWNER TO postgres;

--
-- Name: t510_temp; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t510_temp (
    c010_trctypeid integer,
    c011_month smallint,
    c012_trcid integer,
    c050_rev smallint,
    c000_sysid integer,
    c000_linesrc integer,
    c063_dtdelivery timestamp without time zone,
    c100_itemintid integer,
    c100_itemextid integer,
    c100_itemnameuser character varying(200),
    c105_note character varying(50),
    c102_priceint double precision,
    c110_qty double precision,
    c110_qty2 double precision,
    c111_qtybal double precision,
    c125_amountint double precision,
    c126_valdiscount double precision,
    c127_amountdiscount double precision,
    c130_mledgerid smallint,
    c131_subledger1id smallint,
    c132_subledger2id smallint,
    c135_rate double precision,
    c140_kategoryid smallint,
    c150_unitconvertion double precision,
    c160_prtype smallint,
    postcategoryid smallint,
    c128_netamount double precision,
    costcenterid smallint
);


ALTER TABLE dbo.t510_temp OWNER TO postgres;

--
-- Name: t640_trc; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t640_trc (
    c010_trctypeid bigint,
    c011_month bigint,
    c012_trcid bigint,
    c050_rev bigint,
    c000_sysid bigint,
    c014_monthpostidx bigint,
    c013_mapperid bigint,
    yearidx bigint,
    monthidx bigint,
    c015_datepost timestamp without time zone,
    c016_timepost timestamp with time zone,
    c045_username character varying(25),
    c050_docnum character varying(25),
    c050_docdate timestamp without time zone,
    actmgrobjtitle character varying(25),
    description character varying(200),
    fa_actid bigint,
    amounttrc double precision,
    currency character varying(5),
    rate double precision,
    amountlocal double precision,
    docref1 character varying(50),
    docref2 character varying(50)
);


ALTER TABLE dbo.t640_trc OWNER TO postgres;

--
-- Name: t_30_actmgr_sysid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.t_30_actmgr_sysid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.t_30_actmgr_sysid_seq OWNER TO postgres;

--
-- Name: t_30_actmgr_sysid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.t_30_actmgr_sysid_seq OWNED BY dbo.t_30_actmgr.sysid;


--
-- Name: t_500_historyims; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t_500_historyims (
    sysid integer NOT NULL,
    c010_trctypeid integer,
    c011_month smallint,
    c000_sysid integer,
    c050_rev smallint,
    c013_trctypesrcid smallint,
    c013_draftreadyapprcancel smallint,
    c014_actmgrid smallint,
    c017_usergrpflowid_from smallint,
    c017_usergrpflowid_to smallint,
    c017_usergrpflowfrom character varying(25),
    c017_usergrpflowto character varying(25),
    c018_flowtypeid smallint,
    c018_kanbanpostid smallint,
    c045_userid integer,
    c045_username character varying(25),
    c045_dtime timestamp with time zone,
    c045_usernameupdate character varying(25),
    c045_dtimelasupdate timestamp with time zone,
    c050_docnum character varying(25),
    c050_docdate timestamp without time zone,
    c050_accountdate timestamp without time zone,
    c050_extdocnum character varying(50),
    c050_extdocdate timestamp without time zone,
    c050_extdocnum1 character varying(25),
    c050_extdocdate1 timestamp without time zone,
    c051_ponum character varying(30),
    c051_fakturnum character varying(100),
    c051_fakturdatetax timestamp without time zone,
    c051_duedate timestamp without time zone,
    c052_termofpayment smallint,
    c059_remark character varying(1000),
    c060_partnerid smallint,
    c061_picname character varying(50),
    c062_actfixedassetid integer,
    c070_currencyid smallint,
    c071_rate double precision,
    c072_ratetax double precision,
    c073_amount double precision,
    c073_amountbruto double precision,
    c074_amountdiscount double precision,
    c074_expense double precision,
    c075_amountppn double precision,
    c075_amountpph double precision,
    c076_amountfinal double precision,
    c077_amountbalance double precision,
    c078_amountprepaid double precision,
    c079_amountgrnotinv double precision,
    c080_prcategoryid smallint,
    c085_isppn boolean,
    c090_estdlvdate timestamp without time zone,
    c113_prtype smallint,
    sledgerid smallint,
    mledgerid smallint,
    subledger1id smallint,
    subledger2id smallint,
    postcategoryid smallint,
    remark_pr character varying(1000),
    yearidx smallint,
    deptid smallint
);


ALTER TABLE dbo.t_500_historyims OWNER TO postgres;

--
-- Name: t_500_historyims_sysid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.t_500_historyims_sysid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.t_500_historyims_sysid_seq OWNER TO postgres;

--
-- Name: t_500_historyims_sysid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.t_500_historyims_sysid_seq OWNED BY dbo.t_500_historyims.sysid;


--
-- Name: t_510_historyims; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.t_510_historyims (
    sysid integer NOT NULL,
    c010_trctypeid integer,
    c011_month smallint,
    c012_trcid integer,
    c050_rev smallint,
    c000_sysid integer,
    c000_linesrc integer,
    c063_dtdelivery timestamp without time zone,
    c100_itemintid integer,
    c100_itemextid integer,
    c100_itemnameuser character varying(200),
    c105_note character varying(50),
    c102_priceint double precision,
    c110_qty double precision,
    c110_qty2 double precision,
    c111_qtybal double precision,
    c125_amountint double precision,
    c126_valdiscount double precision,
    c127_amountdiscount double precision,
    c130_mledgerid smallint,
    c131_subledger1id smallint,
    c132_subledger2id smallint,
    c135_rate double precision,
    c140_kategoryid smallint,
    c150_unitconvertion double precision,
    c160_prtype smallint,
    postcategoryid smallint,
    c128_netamount double precision,
    costcenterid smallint
);


ALTER TABLE dbo.t_510_historyims OWNER TO postgres;

--
-- Name: t_510_historyims_sysid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.t_510_historyims_sysid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.t_510_historyims_sysid_seq OWNER TO postgres;

--
-- Name: t_510_historyims_sysid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.t_510_historyims_sysid_seq OWNED BY dbo.t_510_historyims.sysid;


--
-- Name: td_order; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.td_order (
    regid integer NOT NULL,
    trctypeid bigint,
    monthid bigint,
    trcid bigint,
    lineid bigint,
    docdate date,
    vendorid bigint,
    recievingarea character varying(15),
    deliverydate date,
    deliverytime time without time zone,
    classification character varying(15),
    ponum character varying(50),
    item double precision,
    itemid bigint,
    qty double precision,
    userid bigint,
    userupdateid bigint,
    updatetime timestamp with time zone,
    remarkd character varying(225),
    isdelete integer,
    shift character varying(15),
    cycle integer,
    partnerid bigint
);


ALTER TABLE dbo.td_order OWNER TO postgres;

--
-- Name: td_order_regid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.td_order_regid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.td_order_regid_seq OWNER TO postgres;

--
-- Name: td_order_regid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.td_order_regid_seq OWNED BY dbo.td_order.regid;


--
-- Name: td_transaction_delete; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.td_transaction_delete (
    regid integer NOT NULL,
    trctypeid bigint,
    monthid bigint,
    trcid bigint,
    lineid bigint,
    itemid bigint,
    qty_1 double precision,
    qty_2 double precision,
    qty_3 double precision,
    qty_4 double precision,
    qty_5 double precision,
    convertion_1 double precision,
    convertion_2 double precision,
    typeid bigint,
    detaildate date,
    detailtime time without time zone,
    addressid bigint,
    detaildocnum character varying(25),
    starttime timestamp with time zone,
    endtime timestamp with time zone,
    duration double precision,
    processd bigint,
    processh bigint,
    processid bigint,
    addressdetail bigint,
    remarkd character varying(225),
    lotno bigint,
    vanno bigint,
    achievement double precision,
    totaldt double precision,
    totalps double precision,
    gsph double precision,
    createby bigint,
    partnerid bigint,
    sjnum character varying(50),
    sjdate date,
    reffnum character varying(50),
    matnum character varying(50),
    isdelete boolean DEFAULT false,
    trctypeid_ext bigint,
    monthid_ext bigint,
    trcid_ext bigint,
    lineid_ext bigint,
    price double precision,
    amount double precision,
    balamount double precision,
    op1 text,
    op2 text,
    picname bigint,
    updatedate date,
    updatetime time without time zone,
    updateid bigint
);


ALTER TABLE dbo.td_transaction_delete OWNER TO postgres;

--
-- Name: td_transaction_delete_regid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.td_transaction_delete_regid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.td_transaction_delete_regid_seq OWNER TO postgres;

--
-- Name: td_transaction_delete_regid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.td_transaction_delete_regid_seq OWNED BY dbo.td_transaction_delete.regid;


--
-- Name: td_transaction_regid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.td_transaction_regid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.td_transaction_regid_seq OWNER TO postgres;

--
-- Name: td_transaction_regid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.td_transaction_regid_seq OWNED BY dbo.td_transaction.regid;


--
-- Name: th_order; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.th_order (
    regid integer NOT NULL,
    trctypeid bigint,
    monthid bigint,
    trcid bigint,
    docnum character varying(25),
    docdate date,
    doctime time without time zone,
    userid bigint,
    userupdateid bigint,
    updatetime timestamp with time zone,
    remarkh character varying(225),
    isdelete integer
);


ALTER TABLE dbo.th_order OWNER TO postgres;

--
-- Name: th_order_regid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.th_order_regid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.th_order_regid_seq OWNER TO postgres;

--
-- Name: th_order_regid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.th_order_regid_seq OWNED BY dbo.th_order.regid;


--
-- Name: th_transaction_regid_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.th_transaction_regid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.th_transaction_regid_seq OWNER TO postgres;

--
-- Name: th_transaction_regid_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.th_transaction_regid_seq OWNED BY dbo.th_transaction.regid;


--
-- Name: wipstock; Type: VIEW; Schema: dbo; Owner: postgres
--

CREATE VIEW dbo.wipstock AS
 SELECT m_product.regid AS itemid,
    m_product.partno,
    m_product.partname,
    m_product.idcust,
    m_partner.partnercode AS code,
    m_partner.partnername AS custname,
    COALESCE(sum(scwip.inmat), (0)::double precision) AS "in",
    COALESCE(sum(scwip.outmat), (0)::double precision) AS "out",
    m_product.pcsperday,
    m_product.isactive,
    m_product.stdpack,
    m_product.stockwip,
    m_project.projectname
   FROM (((dbo.m_product
     LEFT JOIN dbo.m_partner ON ((m_product.idcust = m_partner.sysid)))
     LEFT JOIN dbo.m_project ON ((m_product.idproject = m_project.regid)))
     LEFT JOIN dbo.scwip ON ((m_product.regid = scwip.itemid)))
  WHERE ((m_product.isactive = 1) AND (m_product.iswip = 1))
  GROUP BY m_product.regid, m_product.partno, m_product.partname, m_product.pcsperday, m_product.stockwip, m_product.isactive, m_product.stdpack, m_project.projectname, m_partner.partnercode, m_partner.partnername, m_product.idcust;


ALTER TABLE dbo.wipstock OWNER TO postgres;

--
-- Name: bombuild sysid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.bombuild ALTER COLUMN sysid SET DEFAULT nextval('dbo.bombuild_sysid_seq'::regclass);


--
-- Name: bomchild sysid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.bomchild ALTER COLUMN sysid SET DEFAULT nextval('dbo.bomchild_sysid_seq'::regclass);


--
-- Name: bomrm sysid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.bomrm ALTER COLUMN sysid SET DEFAULT nextval('dbo.bomrm_sysid_seq'::regclass);


--
-- Name: cmproduct_bom sysid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.cmproduct_bom ALTER COLUMN sysid SET DEFAULT nextval('dbo.cmproduct_bom_sysid_seq'::regclass);


--
-- Name: d_comment idcoment; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.d_comment ALTER COLUMN idcoment SET DEFAULT nextval('dbo.d_comment_idcoment_seq'::regclass);


--
-- Name: g_docnummat regid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.g_docnummat ALTER COLUMN regid SET DEFAULT nextval('dbo.g_docnummat_regid_seq'::regclass);


--
-- Name: loguser sysid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.loguser ALTER COLUMN sysid SET DEFAULT nextval('dbo.loguser_sysid_seq'::regclass);


--
-- Name: m_addressdlv sysid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.m_addressdlv ALTER COLUMN sysid SET DEFAULT nextval('dbo.m_addressdlv_sysid_seq'::regclass);


--
-- Name: m_category id; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.m_category ALTER COLUMN id SET DEFAULT nextval('dbo.m_category_id_seq'::regclass);


--
-- Name: m_childpart_conecting sysid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.m_childpart_conecting ALTER COLUMN sysid SET DEFAULT nextval('dbo.m_childpart_conecting_sysid_seq'::regclass);


--
-- Name: m_customer regid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.m_customer ALTER COLUMN regid SET DEFAULT nextval('dbo.m_customer_regid_seq'::regclass);


--
-- Name: m_department id; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.m_department ALTER COLUMN id SET DEFAULT nextval('dbo.m_department_id_seq'::regclass);


--
-- Name: m_detailict sysid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.m_detailict ALTER COLUMN sysid SET DEFAULT nextval('dbo.m_detailict_sysid_seq'::regclass);


--
-- Name: m_detailstatus regid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.m_detailstatus ALTER COLUMN regid SET DEFAULT nextval('dbo.m_detailstatus_regid_seq'::regclass);


--
-- Name: m_jabatan regid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.m_jabatan ALTER COLUMN regid SET DEFAULT nextval('dbo.m_jabatan_regid_seq'::regclass);


--
-- Name: m_level id_level; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.m_level ALTER COLUMN id_level SET DEFAULT nextval('dbo.m_level_id_level_seq'::regclass);


--
-- Name: m_line idline; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.m_line ALTER COLUMN idline SET DEFAULT nextval('dbo.m_line_idline_seq'::regclass);


--
-- Name: m_location sysid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.m_location ALTER COLUMN sysid SET DEFAULT nextval('dbo.m_location_sysid_seq'::regclass);


--
-- Name: m_machine regid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.m_machine ALTER COLUMN regid SET DEFAULT nextval('dbo.m_machine_regid_seq'::regclass);


--
-- Name: m_masterby regid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.m_masterby ALTER COLUMN regid SET DEFAULT nextval('dbo.m_masterby_regid_seq'::regclass);


--
-- Name: m_materialtype regid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.m_materialtype ALTER COLUMN regid SET DEFAULT nextval('dbo.m_materialtype_regid_seq'::regclass);


--
-- Name: m_partner sysid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.m_partner ALTER COLUMN sysid SET DEFAULT nextval('dbo.m_partner_sysid_seq'::regclass);


--
-- Name: m_partner2 id; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.m_partner2 ALTER COLUMN id SET DEFAULT nextval('dbo.m_partner2_id_seq'::regclass);


--
-- Name: m_product regid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.m_product ALTER COLUMN regid SET DEFAULT nextval('dbo.m_product_regid_seq'::regclass);


--
-- Name: m_productionprocess sysid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.m_productionprocess ALTER COLUMN sysid SET DEFAULT nextval('dbo.m_productionprocess_sysid_seq'::regclass);


--
-- Name: m_project regid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.m_project ALTER COLUMN regid SET DEFAULT nextval('dbo.m_project_regid_seq'::regclass);


--
-- Name: m_qccheck sysid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.m_qccheck ALTER COLUMN sysid SET DEFAULT nextval('dbo.m_qccheck_sysid_seq'::regclass);


--
-- Name: m_shift2 sysid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.m_shift2 ALTER COLUMN sysid SET DEFAULT nextval('dbo.m_shift2_sysid_seq'::regclass);


--
-- Name: m_user regid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.m_user ALTER COLUMN regid SET DEFAULT nextval('dbo.m_user_regid_seq'::regclass);


--
-- Name: m_userg5 sysid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.m_userg5 ALTER COLUMN sysid SET DEFAULT nextval('dbo.m_userg5_sysid_seq'::regclass);


--
-- Name: m_userrole sysid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.m_userrole ALTER COLUMN sysid SET DEFAULT nextval('dbo.m_userrole_sysid_seq'::regclass);


--
-- Name: m_vendor regid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.m_vendor ALTER COLUMN regid SET DEFAULT nextval('dbo.m_vendor_regid_seq'::regclass);


--
-- Name: t_30_actmgr sysid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.t_30_actmgr ALTER COLUMN sysid SET DEFAULT nextval('dbo.t_30_actmgr_sysid_seq'::regclass);


--
-- Name: t_500_historyims sysid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.t_500_historyims ALTER COLUMN sysid SET DEFAULT nextval('dbo.t_500_historyims_sysid_seq'::regclass);


--
-- Name: t_510_historyims sysid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.t_510_historyims ALTER COLUMN sysid SET DEFAULT nextval('dbo.t_510_historyims_sysid_seq'::regclass);


--
-- Name: td_order regid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.td_order ALTER COLUMN regid SET DEFAULT nextval('dbo.td_order_regid_seq'::regclass);


--
-- Name: td_transaction regid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.td_transaction ALTER COLUMN regid SET DEFAULT nextval('dbo.td_transaction_regid_seq'::regclass);


--
-- Name: td_transaction_delete regid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.td_transaction_delete ALTER COLUMN regid SET DEFAULT nextval('dbo.td_transaction_delete_regid_seq'::regclass);


--
-- Name: th_order regid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.th_order ALTER COLUMN regid SET DEFAULT nextval('dbo.th_order_regid_seq'::regclass);


--
-- Name: th_transaction regid; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.th_transaction ALTER COLUMN regid SET DEFAULT nextval('dbo.th_transaction_regid_seq'::regclass);


--
-- Data for Name: actionbutton; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.actionbutton (sysid, description, docdate, status, countx) FROM stdin;
\.
COPY dbo.actionbutton (sysid, description, docdate, status, countx) FROM '$$PATH$$/2985.dat';

--
-- Data for Name: bom1; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.bom1 (sysid, itemno, partno, partname, idcust, image, idproject, packingtype, parttypeid, stdpack, fglocation, qtypercar, supplierid, createby, isactive, isdelete, nametype) FROM stdin;
\.
COPY dbo.bom1 (sysid, itemno, partno, partname, idcust, image, idproject, packingtype, parttypeid, stdpack, fglocation, qtypercar, supplierid, createby, isactive, isdelete, nametype) FROM '$$PATH$$/2986.dat';

--
-- Data for Name: bom2; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.bom2 (sysid, itemno, itemnosub, nourut, linkid, partno, partname, levelpart, parttype, qtypercar, supplierid, spec, thick, width, length, pcspersheet, kgpersheet, partweight, pcsperday, materialtype, fglocation, packingtype, stdpack, isactivedetail, isdeletedetail, specorder1, specorder2, qtypart, ratio, iscommon, partno_ext, partname_ext, iscommongroup, groupcommonid, nametype, itemid, partno2, isrhlh, images) FROM stdin;
\.
COPY dbo.bom2 (sysid, itemno, itemnosub, nourut, linkid, partno, partname, levelpart, parttype, qtypercar, supplierid, spec, thick, width, length, pcspersheet, kgpersheet, partweight, pcsperday, materialtype, fglocation, packingtype, stdpack, isactivedetail, isdeletedetail, specorder1, specorder2, qtypart, ratio, iscommon, partno_ext, partname_ext, iscommongroup, groupcommonid, nametype, itemid, partno2, isrhlh, images) FROM '$$PATH$$/2987.dat';

--
-- Data for Name: bom3; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.bom3 (sysid, linkid, op5m, op10m, op20m, op30m, op40m, op50m, op60m, op70m, itemid, onprocess) FROM stdin;
\.
COPY dbo.bom3 (sysid, linkid, op5m, op10m, op20m, op30m, op40m, op50m, op60m, op70m, itemid, onprocess) FROM '$$PATH$$/2988.dat';

--
-- Data for Name: bom4; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.bom4 (sysid, linkid, op5, op10, op20, op30, op40, op50, op60, op70, category, itemid) FROM stdin;
\.
COPY dbo.bom4 (sysid, linkid, op5, op10, op20, op30, op40, op50, op60, op70, category, itemid) FROM '$$PATH$$/2989.dat';

--
-- Data for Name: bom5; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.bom5 (sysid, linkid, processassy, lineassy, itemid) FROM stdin;
\.
COPY dbo.bom5 (sysid, linkid, processassy, lineassy, itemid) FROM '$$PATH$$/2990.dat';

--
-- Data for Name: bom6; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.bom6 (sysid, parttype, remark) FROM stdin;
\.
COPY dbo.bom6 (sysid, parttype, remark) FROM '$$PATH$$/2991.dat';

--
-- Data for Name: bombuild; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.bombuild (sysid, linkid, itemid, createby, createdate, createtime, isdelete) FROM stdin;
\.
COPY dbo.bombuild (sysid, linkid, itemid, createby, createdate, createtime, isdelete) FROM '$$PATH$$/2993.dat';

--
-- Name: bombuild_sysid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.bombuild_sysid_seq', 1, false);


--
-- Data for Name: bomchild; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.bomchild (sysid, itemid, itemchild) FROM stdin;
\.
COPY dbo.bomchild (sysid, itemid, itemchild) FROM '$$PATH$$/2995.dat';

--
-- Name: bomchild_sysid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.bomchild_sysid_seq', 1, false);


--
-- Data for Name: bomrm; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.bomrm (sysid, itemid, itemrm) FROM stdin;
\.
COPY dbo.bomrm (sysid, itemid, itemrm) FROM '$$PATH$$/2997.dat';

--
-- Name: bomrm_sysid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.bomrm_sysid_seq', 1, false);


--
-- Data for Name: cmproduct_bom; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.cmproduct_bom (sysid, itemid_product, itemid_bom, parttypeid) FROM stdin;
\.
COPY dbo.cmproduct_bom (sysid, itemid_product, itemid_bom, parttypeid) FROM '$$PATH$$/2999.dat';

--
-- Name: cmproduct_bom_sysid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.cmproduct_bom_sysid_seq', 1, false);


--
-- Data for Name: d_comment; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.d_comment (idcoment, idcoment_detail, kode_com, topic, coment, tgl_in, username, id_dept, foto, foto2, jam, likecom, qtycoment, fitureid) FROM stdin;
\.
COPY dbo.d_comment (idcoment, idcoment_detail, kode_com, topic, coment, tgl_in, username, id_dept, foto, foto2, jam, likecom, qtycoment, fitureid) FROM '$$PATH$$/3001.dat';

--
-- Name: d_comment_idcoment_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.d_comment_idcoment_seq', 1, false);


--
-- Data for Name: g_docnummat; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.g_docnummat (regid, docnum, createby, createdate, docdate, hideh, itemid, prosesh, shiftid, gtstroke, gtstrokeplan, trctypeid, trcid, monthid) FROM stdin;
\.
COPY dbo.g_docnummat (regid, docnum, createby, createdate, docdate, hideh, itemid, prosesh, shiftid, gtstroke, gtstrokeplan, trctypeid, trcid, monthid) FROM '$$PATH$$/3003.dat';

--
-- Name: g_docnummat_regid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.g_docnummat_regid_seq', 1, false);


--
-- Data for Name: lastact; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.lastact (sysid, url, headmenuactive, menuactive, iconactive, ip_address, status) FROM stdin;
\.
COPY dbo.lastact (sysid, url, headmenuactive, menuactive, iconactive, ip_address, status) FROM '$$PATH$$/3004.dat';

--
-- Data for Name: loguser; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.loguser (sysid, username, docdate, doctime, query, ip_address, status) FROM stdin;
\.
COPY dbo.loguser (sysid, username, docdate, doctime, query, ip_address, status) FROM '$$PATH$$/3006.dat';

--
-- Name: loguser_sysid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.loguser_sysid_seq', 1, false);


--
-- Data for Name: m_addressdlv; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_addressdlv (sysid, partnerid, titleaddres, address, city, postcode, country, currencyid, priceperiodactiveid, isbilling, isoffice, isdelivery, phone, fax) FROM stdin;
\.
COPY dbo.m_addressdlv (sysid, partnerid, titleaddres, address, city, postcode, country, currencyid, priceperiodactiveid, isbilling, isoffice, isdelivery, phone, fax) FROM '$$PATH$$/3008.dat';

--
-- Name: m_addressdlv_sysid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.m_addressdlv_sysid_seq', 1, false);


--
-- Data for Name: m_asset; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_asset (sysid, itemid, itemno, itemname, spec, categoryid, remark, locationid, userid, datepur, lastupdate, purchasedate, vendorid, qty, qtybal, jurnalid, unitid, image, imagerev, isactive, price, amount) FROM stdin;
\.
COPY dbo.m_asset (sysid, itemid, itemno, itemname, spec, categoryid, remark, locationid, userid, datepur, lastupdate, purchasedate, vendorid, qty, qtybal, jurnalid, unitid, image, imagerev, isactive, price, amount) FROM '$$PATH$$/3009.dat';

--
-- Data for Name: m_assetict; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_assetict (sysid, ram, hdd, netcard, vgacard, processor, os, office, autocad, nx, sw, catia, fb, db, hardware, printertype, colortype, sizepaper, remark) FROM stdin;
\.
COPY dbo.m_assetict (sysid, ram, hdd, netcard, vgacard, processor, os, office, autocad, nx, sw, catia, fb, db, hardware, printertype, colortype, sizepaper, remark) FROM '$$PATH$$/3010.dat';

--
-- Data for Name: m_bank; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_bank (sysid, code, bankname) FROM stdin;
\.
COPY dbo.m_bank (sysid, code, bankname) FROM '$$PATH$$/3011.dat';

--
-- Data for Name: m_category; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_category (id, code, category_name, descr, groupby, isdelete) FROM stdin;
\.
COPY dbo.m_category (id, code, category_name, descr, groupby, isdelete) FROM '$$PATH$$/3013.dat';

--
-- Name: m_category_id_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.m_category_id_seq', 1, false);


--
-- Data for Name: m_childpart_conecting; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_childpart_conecting (sysid, itemid, childpartid, parttypeid) FROM stdin;
\.
COPY dbo.m_childpart_conecting (sysid, itemid, childpartid, parttypeid) FROM '$$PATH$$/3015.dat';

--
-- Name: m_childpart_conecting_sysid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.m_childpart_conecting_sysid_seq', 1, false);


--
-- Data for Name: m_currency; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_currency (sysid, code, descr, desimal, desimal2, titikkoma, rate) FROM stdin;
\.
COPY dbo.m_currency (sysid, code, descr, desimal, desimal2, titikkoma, rate) FROM '$$PATH$$/3016.dat';

--
-- Data for Name: m_customer; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_customer (regid, code, custname, isdelete) FROM stdin;
\.
COPY dbo.m_customer (regid, code, custname, isdelete) FROM '$$PATH$$/3018.dat';

--
-- Name: m_customer_regid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.m_customer_regid_seq', 1, false);


--
-- Data for Name: m_department; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_department (id, dept_code, dept_name, descr, deptsysid) FROM stdin;
\.
COPY dbo.m_department (id, dept_code, dept_name, descr, deptsysid) FROM '$$PATH$$/3020.dat';

--
-- Name: m_department_id_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.m_department_id_seq', 1, false);


--
-- Data for Name: m_detailict; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_detailict (sysid, code, description, category, remark, isdelete) FROM stdin;
\.
COPY dbo.m_detailict (sysid, code, description, category, remark, isdelete) FROM '$$PATH$$/3022.dat';

--
-- Name: m_detailict_sysid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.m_detailict_sysid_seq', 1, false);


--
-- Data for Name: m_detailstatus; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_detailstatus (regid, detail) FROM stdin;
\.
COPY dbo.m_detailstatus (regid, detail) FROM '$$PATH$$/3024.dat';

--
-- Name: m_detailstatus_regid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.m_detailstatus_regid_seq', 1, false);


--
-- Data for Name: m_jabatan; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_jabatan (regid, levelname) FROM stdin;
\.
COPY dbo.m_jabatan (regid, levelname) FROM '$$PATH$$/3026.dat';

--
-- Name: m_jabatan_regid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.m_jabatan_regid_seq', 1, false);


--
-- Data for Name: m_level; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_level (id_level, level) FROM stdin;
\.
COPY dbo.m_level (id_level, level) FROM '$$PATH$$/3028.dat';

--
-- Name: m_level_id_level_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.m_level_id_level_seq', 1, false);


--
-- Data for Name: m_line; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_line (idline, line, category, factory) FROM stdin;
\.
COPY dbo.m_line (idline, line, category, factory) FROM '$$PATH$$/3030.dat';

--
-- Name: m_line_idline_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.m_line_idline_seq', 1, false);


--
-- Data for Name: m_location; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_location (sysid, location, remark, category, isactive) FROM stdin;
\.
COPY dbo.m_location (sysid, location, remark, category, isactive) FROM '$$PATH$$/3032.dat';

--
-- Name: m_location_sysid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.m_location_sysid_seq', 1, false);


--
-- Data for Name: m_machine; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_machine (regid, code, mcname, tonage, idline, detailline, isactive) FROM stdin;
\.
COPY dbo.m_machine (regid, code, mcname, tonage, idline, detailline, isactive) FROM '$$PATH$$/3034.dat';

--
-- Name: m_machine_regid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.m_machine_regid_seq', 1, false);


--
-- Data for Name: m_masterby; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_masterby (regid, masterby) FROM stdin;
\.
COPY dbo.m_masterby (regid, masterby) FROM '$$PATH$$/3036.dat';

--
-- Name: m_masterby_regid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.m_masterby_regid_seq', 1, false);


--
-- Data for Name: m_materialtype; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_materialtype (regid, materialname) FROM stdin;
\.
COPY dbo.m_materialtype (regid, materialname) FROM '$$PATH$$/3038.dat';

--
-- Name: m_materialtype_regid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.m_materialtype_regid_seq', 1, false);


--
-- Data for Name: m_partner; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_partner (sysid, partnercode, partnername, address, termofpayment, isppn, npwp, emailaddress, iscustomer, isvendor, issubcont, currencyid, priceperiodactiveid, telp, fax, picname, mayprintinv, repeatprint, creditlimit, creditlimitactive, norek, banknameid, cabang, atasnama, isdelete) FROM stdin;
\.
COPY dbo.m_partner (sysid, partnercode, partnername, address, termofpayment, isppn, npwp, emailaddress, iscustomer, isvendor, issubcont, currencyid, priceperiodactiveid, telp, fax, picname, mayprintinv, repeatprint, creditlimit, creditlimitactive, norek, banknameid, cabang, atasnama, isdelete) FROM '$$PATH$$/3040.dat';

--
-- Data for Name: m_partner2; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_partner2 (id, partner_code, partner_name, address, dlvaddress, telp, isdelete, category) FROM stdin;
\.
COPY dbo.m_partner2 (id, partner_code, partner_name, address, dlvaddress, telp, isdelete, category) FROM '$$PATH$$/3042.dat';

--
-- Name: m_partner2_id_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.m_partner2_id_seq', 1, false);


--
-- Name: m_partner_sysid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.m_partner_sysid_seq', 1, false);


--
-- Data for Name: m_product; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_product (regid, partno, partname, spec1, spec2, pcspersheet, pcsperkg, idcust, idproject, idcategory, ismaterial, isstamping, iswelding, isdelivery, isstoreroom, isactive, price, pcsperday, min, max, docdate, updateby, materialtype, stockfg, image, stockwip, masterby, idunit, idunit_buy, isict, isga, stockwip2, iswip, sparating, stdpack, issubcon, isdelete, convertion, currencyid, jobnum, description, isg5, postcategoryid) FROM stdin;
\.
COPY dbo.m_product (regid, partno, partname, spec1, spec2, pcspersheet, pcsperkg, idcust, idproject, idcategory, ismaterial, isstamping, iswelding, isdelivery, isstoreroom, isactive, price, pcsperday, min, max, docdate, updateby, materialtype, stockfg, image, stockwip, masterby, idunit, idunit_buy, isict, isga, stockwip2, iswip, sparating, stdpack, issubcon, isdelete, convertion, currencyid, jobnum, description, isg5, postcategoryid) FROM '$$PATH$$/3044.dat';

--
-- Name: m_product_regid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.m_product_regid_seq', 1, false);


--
-- Data for Name: m_productionprocess; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_productionprocess (sysid, code, description, category, isdelete) FROM stdin;
\.
COPY dbo.m_productionprocess (sysid, code, description, category, isdelete) FROM '$$PATH$$/3046.dat';

--
-- Name: m_productionprocess_sysid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.m_productionprocess_sysid_seq', 1, false);


--
-- Data for Name: m_project; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_project (regid, idcust, projectname) FROM stdin;
\.
COPY dbo.m_project (regid, idcust, projectname) FROM '$$PATH$$/3048.dat';

--
-- Name: m_project_regid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.m_project_regid_seq', 1, false);


--
-- Data for Name: m_qccheck; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_qccheck (sysid, qccheck, category) FROM stdin;
\.
COPY dbo.m_qccheck (sysid, qccheck, category) FROM '$$PATH$$/3050.dat';

--
-- Name: m_qccheck_sysid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.m_qccheck_sysid_seq', 1, false);


--
-- Data for Name: m_shift2; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_shift2 (sysid, codeshift, shift) FROM stdin;
\.
COPY dbo.m_shift2 (sysid, codeshift, shift) FROM '$$PATH$$/3052.dat';

--
-- Name: m_shift2_sysid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.m_shift2_sysid_seq', 1, false);


--
-- Data for Name: m_shipper; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_shipper (sysid, shipper) FROM stdin;
\.
COPY dbo.m_shipper (sysid, shipper) FROM '$$PATH$$/3053.dat';

--
-- Data for Name: m_unit; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_unit (id, code, unit, descr, isdelete) FROM stdin;
\.
COPY dbo.m_unit (id, code, unit, descr, isdelete) FROM '$$PATH$$/3054.dat';

--
-- Data for Name: m_user; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_user (regid, code, username, id_user, password, nama_lengkap, level, blokir, foto, id_dept, password2, isstoreroom, musertr, muser, mprodmaterial, mprodstamping, mprodwelding, mproddelivery, mprodstoreroom, mpartner, mcategory, munit, mcust, trcmaterial, trcstamping, trcwelding, trcwh, trcstoreroom, trcga, trcmtc, trcict, caneditmaster, caneditdoc, caneditmanuser, mprodict, mprodmtnt, mprodmtnm, mprodga, trcmtnm, trcmtnt, trcasset, caneditdocadmin, mproduct, mutility, muserims, trcwip, isdelete, email, activationid, activation, masset, mbom, trcsony, trcproduction, dailygap, trcbpfg, area) FROM stdin;
\.
COPY dbo.m_user (regid, code, username, id_user, password, nama_lengkap, level, blokir, foto, id_dept, password2, isstoreroom, musertr, muser, mprodmaterial, mprodstamping, mprodwelding, mproddelivery, mprodstoreroom, mpartner, mcategory, munit, mcust, trcmaterial, trcstamping, trcwelding, trcwh, trcstoreroom, trcga, trcmtc, trcict, caneditmaster, caneditdoc, caneditmanuser, mprodict, mprodmtnt, mprodmtnm, mprodga, trcmtnm, trcmtnt, trcasset, caneditdocadmin, mproduct, mutility, muserims, trcwip, isdelete, email, activationid, activation, masset, mbom, trcsony, trcproduction, dailygap, trcbpfg, area) FROM '$$PATH$$/3056.dat';

--
-- Name: m_user_regid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.m_user_regid_seq', 1, false);


--
-- Data for Name: m_userg5; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_userg5 (sysid, regid, username, fullname, deptid, password, passwordx, image, email, isactive, isstoreroom, activationid, activation, area, pin, signature, jabatanid) FROM stdin;
\.
COPY dbo.m_userg5 (sysid, regid, username, fullname, deptid, password, passwordx, image, email, isactive, isstoreroom, activationid, activation, area, pin, signature, jabatanid) FROM '$$PATH$$/3058.dat';

--
-- Name: m_userg5_sysid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.m_userg5_sysid_seq', 1, false);


--
-- Data for Name: m_userrole; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_userrole (sysid, userid, numof, activityid, activity, activitycode, deldata, updata, retdata, viewjurnal, usergroupflow) FROM stdin;
\.
COPY dbo.m_userrole (sysid, userid, numof, activityid, activity, activitycode, deldata, updata, retdata, viewjurnal, usergroupflow) FROM '$$PATH$$/3060.dat';

--
-- Name: m_userrole_sysid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.m_userrole_sysid_seq', 1, false);


--
-- Data for Name: m_vendor; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.m_vendor (regid, vendorcode, vendorname) FROM stdin;
\.
COPY dbo.m_vendor (regid, vendorcode, vendorname) FROM '$$PATH$$/3062.dat';

--
-- Name: m_vendor_regid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.m_vendor_regid_seq', 1, false);


--
-- Data for Name: mytable; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.mytable (logins, logins22, logins221) FROM stdin;
\.
COPY dbo.mytable (logins, logins22, logins221) FROM '$$PATH$$/3063.dat';

--
-- Data for Name: pr_doctype; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.pr_doctype (sysid, doctype, descr, trctypeid, deptid, approval, legalized) FROM stdin;
\.
COPY dbo.pr_doctype (sysid, doctype, descr, trctypeid, deptid, approval, legalized) FROM '$$PATH$$/3064.dat';

--
-- Data for Name: t015_department; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t015_department (sysid, department, deptgroup) FROM stdin;
\.
COPY dbo.t015_department (sysid, department, deptgroup) FROM '$$PATH$$/3077.dat';

--
-- Data for Name: t040_addressdlv; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t040_addressdlv (sysid, partnerid, titleaddres, address, city, postcode, country, currencyid, priceperiodactiveid, isbilling, isoffice, isdelivery, phone, fax) FROM stdin;
\.
COPY dbo.t040_addressdlv (sysid, partnerid, titleaddres, address, city, postcode, country, currencyid, priceperiodactiveid, isbilling, isoffice, isdelivery, phone, fax) FROM '$$PATH$$/3078.dat';

--
-- Data for Name: t064_prcategory; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t064_prcategory (sysid, trctypeid, sub1, sub2) FROM stdin;
\.
COPY dbo.t064_prcategory (sysid, trctypeid, sub1, sub2) FROM '$$PATH$$/3079.dat';

--
-- Data for Name: t064_prtype; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t064_prtype (trctypeid, prtype) FROM stdin;
\.
COPY dbo.t064_prtype (trctypeid, prtype) FROM '$$PATH$$/3080.dat';

--
-- Data for Name: t066_itemgroup; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t066_itemgroup (sysid, itemgroup) FROM stdin;
\.
COPY dbo.t066_itemgroup (sysid, itemgroup) FROM '$$PATH$$/3081.dat';

--
-- Data for Name: t077_postcategory; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t077_postcategory (sysid, doctypeid, postcategory, mledgerid, trctypeid, itemgroupid) FROM stdin;
\.
COPY dbo.t077_postcategory (sysid, doctypeid, postcategory, mledgerid, trctypeid, itemgroupid) FROM '$$PATH$$/3082.dat';

--
-- Data for Name: t093_costcenter; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t093_costcenter (sysid, yearidx, deptid, budget) FROM stdin;
\.
COPY dbo.t093_costcenter (sysid, yearidx, deptid, budget) FROM '$$PATH$$/3083.dat';

--
-- Data for Name: t094_costcenterdetail; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t094_costcenterdetail (sysid, costcenterid, itemgroupid, descr, nominal) FROM stdin;
\.
COPY dbo.t094_costcenterdetail (sysid, costcenterid, itemgroupid, descr, nominal) FROM '$$PATH$$/3084.dat';

--
-- Data for Name: t100_fixedasset; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t100_fixedasset (sysid, code, descr, groupassetid, activity_activeid, activate) FROM stdin;
\.
COPY dbo.t100_fixedasset (sysid, code, descr, groupassetid, activity_activeid, activate) FROM '$$PATH$$/3085.dat';

--
-- Data for Name: t101_groupasset; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t101_groupasset (sysid, code, descr, mledgerid_d, mledgerid_k) FROM stdin;
\.
COPY dbo.t101_groupasset (sysid, code, descr, mledgerid_d, mledgerid_k) FROM '$$PATH$$/3086.dat';

--
-- Data for Name: t105_activitycategory; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t105_activitycategory (sysid, code, descr) FROM stdin;
\.
COPY dbo.t105_activitycategory (sysid, code, descr) FROM '$$PATH$$/3087.dat';

--
-- Data for Name: t106_fa_activity; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t106_fa_activity (sysid, fixedassetid, activitycategoryid, dtcreate, dtacc, userid, ownerid, user_ue, statprogress) FROM stdin;
\.
COPY dbo.t106_fa_activity (sysid, fixedassetid, activitycategoryid, dtcreate, dtacc, userid, ownerid, user_ue, statprogress) FROM '$$PATH$$/3088.dat';

--
-- Data for Name: t500_500; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t500_500 (c010_trctypeid, c011_month, c000_sysid, c050_rev, c013_trctypesrcid, c018_flowtypeid, c034_trctypeid_to, c035_month_to, c036_trcid_to, c050_rev_to, c016_contentflowid) FROM stdin;
\.
COPY dbo.t500_500 (c010_trctypeid, c011_month, c000_sysid, c050_rev, c013_trctypesrcid, c018_flowtypeid, c034_trctypeid_to, c035_month_to, c036_trcid_to, c050_rev_to, c016_contentflowid) FROM '$$PATH$$/3089.dat';

--
-- Data for Name: t500_assource; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t500_assource (c010_trctypeid, c011_month, c000_sysid, c050_rev, c012_trcopenclose, c012_dtlocked, c012_lockuser, c012_responded, c013_trctypesrcid, c014_actmgrid, c016_contentflowid, c017_usergrpflowid, c018_flowtypeid, c019_actmgrdestid, c045_userid, c045_dtime, c050_docnum, c050_docdate, c060_partnerid, usermarkingid) FROM stdin;
\.
COPY dbo.t500_assource (c010_trctypeid, c011_month, c000_sysid, c050_rev, c012_trcopenclose, c012_dtlocked, c012_lockuser, c012_responded, c013_trctypesrcid, c014_actmgrid, c016_contentflowid, c017_usergrpflowid, c018_flowtypeid, c019_actmgrdestid, c045_userid, c045_dtime, c050_docnum, c050_docdate, c060_partnerid, usermarkingid) FROM '$$PATH$$/3090.dat';

--
-- Data for Name: t500_lastact; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t500_lastact (c010_trctypeid, c011_month, c000_sysid, c050_rev, c045_userid) FROM stdin;
\.
COPY dbo.t500_lastact (c010_trctypeid, c011_month, c000_sysid, c050_rev, c045_userid) FROM '$$PATH$$/3091.dat';

--
-- Data for Name: t500_node; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t500_node (c010_trctypeid, c011_month, c000_sysid, c050_rev, c013_trctypesrcid, c013_draftreadyapprcancel, c014_actmgrid, c017_usergrpflowid_from, c017_usergrpflowid_to, c017_usergrpflowfrom, c017_usergrpflowto, c018_flowtypeid, c018_kanbanpostid, c020_nodehistoryid_active, c045_userid, c045_username, c045_dtime, c045_usernameupdate, c045_dtimelasupdate, c050_docnum, c050_docdate, c050_accountdate, c050_extdocnum, c050_extdocdate, c060_partnerid) FROM stdin;
\.
COPY dbo.t500_node (c010_trctypeid, c011_month, c000_sysid, c050_rev, c013_trctypesrcid, c013_draftreadyapprcancel, c014_actmgrid, c017_usergrpflowid_from, c017_usergrpflowid_to, c017_usergrpflowfrom, c017_usergrpflowto, c018_flowtypeid, c018_kanbanpostid, c020_nodehistoryid_active, c045_userid, c045_username, c045_dtime, c045_usernameupdate, c045_dtimelasupdate, c050_docnum, c050_docdate, c050_accountdate, c050_extdocnum, c050_extdocdate, c060_partnerid) FROM '$$PATH$$/3092.dat';

--
-- Data for Name: t500_proc; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t500_proc (c010_trctypeid, c011_month, c000_sysid, c050_rev, c013_trctypesrcid, c013_draftreadyapprcancel, c014_actmgrid, c017_usergrpflowid_from, c017_usergrpflowid_to, c017_usergrpflowfrom, c017_usergrpflowto, c018_flowtypeid, c018_kanbanpostid, c045_userid, c045_username, c045_dtime, c045_usernameupdate, c045_dtimelasupdate, c050_docnum, c050_docdate, c050_accountdate, c050_extdocnum, c050_extdocdate, c050_extdocnum1, c050_extdocdate1, c051_ponum, c051_fakturnum, c051_fakturdatetax, c051_duedate, c052_termofpayment, c059_remark, c060_partnerid, c061_picname, c062_actfixedassetid, c070_currencyid, c071_rate, c072_ratetax, c073_amount, c073_amountbruto, c074_amountdiscount, c074_expense, c075_amountppn, c075_amountpph, c076_amountfinal, c077_amountbalance, c078_amountprepaid, c079_amountgrnotinv, c080_prcategoryid, c085_isppn, c090_estdlvdate, c113_prtype, sledgerid, mledgerid, subledger1id, subledger2id, postcategoryid, remark_pr, yearidx, deptid) FROM stdin;
\.
COPY dbo.t500_proc (c010_trctypeid, c011_month, c000_sysid, c050_rev, c013_trctypesrcid, c013_draftreadyapprcancel, c014_actmgrid, c017_usergrpflowid_from, c017_usergrpflowid_to, c017_usergrpflowfrom, c017_usergrpflowto, c018_flowtypeid, c018_kanbanpostid, c045_userid, c045_username, c045_dtime, c045_usernameupdate, c045_dtimelasupdate, c050_docnum, c050_docdate, c050_accountdate, c050_extdocnum, c050_extdocdate, c050_extdocnum1, c050_extdocdate1, c051_ponum, c051_fakturnum, c051_fakturdatetax, c051_duedate, c052_termofpayment, c059_remark, c060_partnerid, c061_picname, c062_actfixedassetid, c070_currencyid, c071_rate, c072_ratetax, c073_amount, c073_amountbruto, c074_amountdiscount, c074_expense, c075_amountppn, c075_amountpph, c076_amountfinal, c077_amountbalance, c078_amountprepaid, c079_amountgrnotinv, c080_prcategoryid, c085_isppn, c090_estdlvdate, c113_prtype, sledgerid, mledgerid, subledger1id, subledger2id, postcategoryid, remark_pr, yearidx, deptid) FROM '$$PATH$$/3093.dat';

--
-- Data for Name: t500_temp; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t500_temp (c010_trctypeid, c011_month, c000_sysid, c050_rev, c013_trctypesrcid, c013_draftreadyapprcancel, c014_actmgrid, c017_usergrpflowid_from, c017_usergrpflowid_to, c017_usergrpflowfrom, c017_usergrpflowto, c018_flowtypeid, c018_kanbanpostid, c045_userid, c045_username, c045_dtime, c045_usernameupdate, c045_dtimelasupdate, c050_docnum, c050_docdate, c050_accountdate, c050_extdocnum, c050_extdocdate, c050_extdocnum1, c050_extdocdate1, c051_ponum, c051_fakturnum, c051_fakturdatetax, c051_duedate, c052_termofpayment, c059_remark, c060_partnerid, c061_picname, c062_actfixedassetid, c070_currencyid, c071_rate, c072_ratetax, c073_amount, c073_amountbruto, c074_amountdiscount, c074_expense, c075_amountppn, c075_amountpph, c076_amountfinal, c077_amountbalance, c078_amountprepaid, c079_amountgrnotinv, c080_prcategoryid, c085_isppn, c090_estdlvdate, c113_prtype, sledgerid, mledgerid, subledger1id, subledger2id, postcategoryid, remark_pr, yearidx, deptid) FROM stdin;
\.
COPY dbo.t500_temp (c010_trctypeid, c011_month, c000_sysid, c050_rev, c013_trctypesrcid, c013_draftreadyapprcancel, c014_actmgrid, c017_usergrpflowid_from, c017_usergrpflowid_to, c017_usergrpflowfrom, c017_usergrpflowto, c018_flowtypeid, c018_kanbanpostid, c045_userid, c045_username, c045_dtime, c045_usernameupdate, c045_dtimelasupdate, c050_docnum, c050_docdate, c050_accountdate, c050_extdocnum, c050_extdocdate, c050_extdocnum1, c050_extdocdate1, c051_ponum, c051_fakturnum, c051_fakturdatetax, c051_duedate, c052_termofpayment, c059_remark, c060_partnerid, c061_picname, c062_actfixedassetid, c070_currencyid, c071_rate, c072_ratetax, c073_amount, c073_amountbruto, c074_amountdiscount, c074_expense, c075_amountppn, c075_amountpph, c076_amountfinal, c077_amountbalance, c078_amountprepaid, c079_amountgrnotinv, c080_prcategoryid, c085_isppn, c090_estdlvdate, c113_prtype, sledgerid, mledgerid, subledger1id, subledger2id, postcategoryid, remark_pr, yearidx, deptid) FROM '$$PATH$$/3094.dat';

--
-- Data for Name: t510_proc; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t510_proc (c010_trctypeid, c011_month, c012_trcid, c050_rev, c000_sysid, c000_linesrc, c063_dtdelivery, c100_itemintid, c100_itemextid, c100_itemnameuser, c105_note, c102_priceint, c110_qty, c110_qty2, c111_qtybal, c125_amountint, c126_valdiscount, c127_amountdiscount, c130_mledgerid, c131_subledger1id, c132_subledger2id, c135_rate, c140_kategoryid, c150_unitconvertion, c160_prtype, postcategoryid, c128_netamount, costcenterid) FROM stdin;
\.
COPY dbo.t510_proc (c010_trctypeid, c011_month, c012_trcid, c050_rev, c000_sysid, c000_linesrc, c063_dtdelivery, c100_itemintid, c100_itemextid, c100_itemnameuser, c105_note, c102_priceint, c110_qty, c110_qty2, c111_qtybal, c125_amountint, c126_valdiscount, c127_amountdiscount, c130_mledgerid, c131_subledger1id, c132_subledger2id, c135_rate, c140_kategoryid, c150_unitconvertion, c160_prtype, postcategoryid, c128_netamount, costcenterid) FROM '$$PATH$$/3095.dat';

--
-- Data for Name: t510_temp; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t510_temp (c010_trctypeid, c011_month, c012_trcid, c050_rev, c000_sysid, c000_linesrc, c063_dtdelivery, c100_itemintid, c100_itemextid, c100_itemnameuser, c105_note, c102_priceint, c110_qty, c110_qty2, c111_qtybal, c125_amountint, c126_valdiscount, c127_amountdiscount, c130_mledgerid, c131_subledger1id, c132_subledger2id, c135_rate, c140_kategoryid, c150_unitconvertion, c160_prtype, postcategoryid, c128_netamount, costcenterid) FROM stdin;
\.
COPY dbo.t510_temp (c010_trctypeid, c011_month, c012_trcid, c050_rev, c000_sysid, c000_linesrc, c063_dtdelivery, c100_itemintid, c100_itemextid, c100_itemnameuser, c105_note, c102_priceint, c110_qty, c110_qty2, c111_qtybal, c125_amountint, c126_valdiscount, c127_amountdiscount, c130_mledgerid, c131_subledger1id, c132_subledger2id, c135_rate, c140_kategoryid, c150_unitconvertion, c160_prtype, postcategoryid, c128_netamount, costcenterid) FROM '$$PATH$$/3096.dat';

--
-- Data for Name: t610_trc; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t610_trc (c010_trctypeid, c011_month, c012_trcid, c050_rev, c000_sysid, c014_monthpostidx, c013_mapperid, yearidx, monthidx, c015_datepost, c016_timepost, c045_username, c050_docnum, c050_docdate, c050_accountdate, actmgrobjtitle, description, sledgerid, mledgerid, subledger1id, subledger2id, minplus, amounttrc, amountintrc, amountouttrc, currency, rate, amountlocal, amountinlocal, amountoutlocal, docref1, docref2, description1, costcenterid) FROM stdin;
\.
COPY dbo.t610_trc (c010_trctypeid, c011_month, c012_trcid, c050_rev, c000_sysid, c014_monthpostidx, c013_mapperid, yearidx, monthidx, c015_datepost, c016_timepost, c045_username, c050_docnum, c050_docdate, c050_accountdate, actmgrobjtitle, description, sledgerid, mledgerid, subledger1id, subledger2id, minplus, amounttrc, amountintrc, amountouttrc, currency, rate, amountlocal, amountinlocal, amountoutlocal, docref1, docref2, description1, costcenterid) FROM '$$PATH$$/3097.dat';

--
-- Data for Name: t640_trc; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t640_trc (c010_trctypeid, c011_month, c012_trcid, c050_rev, c000_sysid, c014_monthpostidx, c013_mapperid, yearidx, monthidx, c015_datepost, c016_timepost, c045_username, c050_docnum, c050_docdate, actmgrobjtitle, description, fa_actid, amounttrc, currency, rate, amountlocal, docref1, docref2) FROM stdin;
\.
COPY dbo.t640_trc (c010_trctypeid, c011_month, c012_trcid, c050_rev, c000_sysid, c014_monthpostidx, c013_mapperid, yearidx, monthidx, c015_datepost, c016_timepost, c045_username, c050_docnum, c050_docdate, actmgrobjtitle, description, fa_actid, amounttrc, currency, rate, amountlocal, docref1, docref2) FROM '$$PATH$$/3098.dat';

--
-- Data for Name: t680_trc; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t680_trc (c010_trctypeid, c011_month, c012_trcid, c050_rev, c000_sysid, yearidx, monthidx, c015_datepost, c016_timepost, c045_username, c050_docnum, c050_docdate, actmgrobjtitle, description, costcenterid, itemgroupid, amounttrc) FROM stdin;
\.
COPY dbo.t680_trc (c010_trctypeid, c011_month, c012_trcid, c050_rev, c000_sysid, yearidx, monthidx, c015_datepost, c016_timepost, c045_username, c050_docnum, c050_docdate, actmgrobjtitle, description, costcenterid, itemgroupid, amounttrc) FROM '$$PATH$$/3099.dat';

--
-- Data for Name: t_30_actmgr; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t_30_actmgr (sysid, objtitle, codename) FROM stdin;
\.
COPY dbo.t_30_actmgr (sysid, objtitle, codename) FROM '$$PATH$$/3066.dat';

--
-- Name: t_30_actmgr_sysid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.t_30_actmgr_sysid_seq', 1, false);


--
-- Data for Name: t_30_usergrpflow; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t_30_usergrpflow (sysid, bprocid, descr) FROM stdin;
\.
COPY dbo.t_30_usergrpflow (sysid, bprocid, descr) FROM '$$PATH$$/3067.dat';

--
-- Data for Name: t_500_historyims; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t_500_historyims (sysid, c010_trctypeid, c011_month, c000_sysid, c050_rev, c013_trctypesrcid, c013_draftreadyapprcancel, c014_actmgrid, c017_usergrpflowid_from, c017_usergrpflowid_to, c017_usergrpflowfrom, c017_usergrpflowto, c018_flowtypeid, c018_kanbanpostid, c045_userid, c045_username, c045_dtime, c045_usernameupdate, c045_dtimelasupdate, c050_docnum, c050_docdate, c050_accountdate, c050_extdocnum, c050_extdocdate, c050_extdocnum1, c050_extdocdate1, c051_ponum, c051_fakturnum, c051_fakturdatetax, c051_duedate, c052_termofpayment, c059_remark, c060_partnerid, c061_picname, c062_actfixedassetid, c070_currencyid, c071_rate, c072_ratetax, c073_amount, c073_amountbruto, c074_amountdiscount, c074_expense, c075_amountppn, c075_amountpph, c076_amountfinal, c077_amountbalance, c078_amountprepaid, c079_amountgrnotinv, c080_prcategoryid, c085_isppn, c090_estdlvdate, c113_prtype, sledgerid, mledgerid, subledger1id, subledger2id, postcategoryid, remark_pr, yearidx, deptid) FROM stdin;
\.
COPY dbo.t_500_historyims (sysid, c010_trctypeid, c011_month, c000_sysid, c050_rev, c013_trctypesrcid, c013_draftreadyapprcancel, c014_actmgrid, c017_usergrpflowid_from, c017_usergrpflowid_to, c017_usergrpflowfrom, c017_usergrpflowto, c018_flowtypeid, c018_kanbanpostid, c045_userid, c045_username, c045_dtime, c045_usernameupdate, c045_dtimelasupdate, c050_docnum, c050_docdate, c050_accountdate, c050_extdocnum, c050_extdocdate, c050_extdocnum1, c050_extdocdate1, c051_ponum, c051_fakturnum, c051_fakturdatetax, c051_duedate, c052_termofpayment, c059_remark, c060_partnerid, c061_picname, c062_actfixedassetid, c070_currencyid, c071_rate, c072_ratetax, c073_amount, c073_amountbruto, c074_amountdiscount, c074_expense, c075_amountppn, c075_amountpph, c076_amountfinal, c077_amountbalance, c078_amountprepaid, c079_amountgrnotinv, c080_prcategoryid, c085_isppn, c090_estdlvdate, c113_prtype, sledgerid, mledgerid, subledger1id, subledger2id, postcategoryid, remark_pr, yearidx, deptid) FROM '$$PATH$$/3069.dat';

--
-- Name: t_500_historyims_sysid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.t_500_historyims_sysid_seq', 1, false);


--
-- Data for Name: t_510_historyims; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t_510_historyims (sysid, c010_trctypeid, c011_month, c012_trcid, c050_rev, c000_sysid, c000_linesrc, c063_dtdelivery, c100_itemintid, c100_itemextid, c100_itemnameuser, c105_note, c102_priceint, c110_qty, c110_qty2, c111_qtybal, c125_amountint, c126_valdiscount, c127_amountdiscount, c130_mledgerid, c131_subledger1id, c132_subledger2id, c135_rate, c140_kategoryid, c150_unitconvertion, c160_prtype, postcategoryid, c128_netamount, costcenterid) FROM stdin;
\.
COPY dbo.t_510_historyims (sysid, c010_trctypeid, c011_month, c012_trcid, c050_rev, c000_sysid, c000_linesrc, c063_dtdelivery, c100_itemintid, c100_itemextid, c100_itemnameuser, c105_note, c102_priceint, c110_qty, c110_qty2, c111_qtybal, c125_amountint, c126_valdiscount, c127_amountdiscount, c130_mledgerid, c131_subledger1id, c132_subledger2id, c135_rate, c140_kategoryid, c150_unitconvertion, c160_prtype, postcategoryid, c128_netamount, costcenterid) FROM '$$PATH$$/3071.dat';

--
-- Name: t_510_historyims_sysid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.t_510_historyims_sysid_seq', 1, false);


--
-- Data for Name: t_76_sledger; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t_76_sledger (sysid, code) FROM stdin;
\.
COPY dbo.t_76_sledger (sysid, code) FROM '$$PATH$$/3072.dat';

--
-- Data for Name: t_77_mledger; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t_77_mledger (sysid, code, descr, seqidx, macctlevel, typeml, cf_rpttype, cf_group, bs_rpttype, pl_rpttype, tb_group, spasi, isdetail, isneraca, parentid, lft, rgt, partopid, kascnt, kasbankcnt) FROM stdin;
\.
COPY dbo.t_77_mledger (sysid, code, descr, seqidx, macctlevel, typeml, cf_rpttype, cf_group, bs_rpttype, pl_rpttype, tb_group, spasi, isdetail, isneraca, parentid, lft, rgt, partopid, kascnt, kasbankcnt) FROM '$$PATH$$/3073.dat';

--
-- Data for Name: t_77_mledger_sub1; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t_77_mledger_sub1 (sysid, mledgerid, code, descr) FROM stdin;
\.
COPY dbo.t_77_mledger_sub1 (sysid, mledgerid, code, descr) FROM '$$PATH$$/3074.dat';

--
-- Data for Name: t_77_mledger_sub2; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t_77_mledger_sub2 (sysid, mledgerid, subledgerid, code, descr) FROM stdin;
\.
COPY dbo.t_77_mledger_sub2 (sysid, mledgerid, subledgerid, code, descr) FROM '$$PATH$$/3075.dat';

--
-- Data for Name: t_connecting; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.t_connecting (trctypeid, monthid, trcid, lineid, trctypeid_to, monthid_to, trcid_to, lineid_to) FROM stdin;
\.
COPY dbo.t_connecting (trctypeid, monthid, trcid, lineid, trctypeid_to, monthid_to, trcid_to, lineid_to) FROM '$$PATH$$/3076.dat';

--
-- Data for Name: td_order; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.td_order (regid, trctypeid, monthid, trcid, lineid, docdate, vendorid, recievingarea, deliverydate, deliverytime, classification, ponum, item, itemid, qty, userid, userupdateid, updatetime, remarkd, isdelete, shift, cycle, partnerid) FROM stdin;
\.
COPY dbo.td_order (regid, trctypeid, monthid, trcid, lineid, docdate, vendorid, recievingarea, deliverydate, deliverytime, classification, ponum, item, itemid, qty, userid, userupdateid, updatetime, remarkd, isdelete, shift, cycle, partnerid) FROM '$$PATH$$/3101.dat';

--
-- Name: td_order_regid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.td_order_regid_seq', 1, false);


--
-- Data for Name: td_transaction; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.td_transaction (regid, trctypeid, monthid, trcid, lineid, itemid, qty_1, qty_2, qty_3, qty_4, qty_5, convertion_1, convertion_2, typeid, detaildate, detailtime, addressid, detaildocnum, starttime, endtime, duration, processd, processh, processid, addressdetail, remarkd, lotno, vanno, achievement, totaldt, totalps, gsph, createby, partnerid, sjnum, sjdate, reffnum, matnum, isdelete, trctypeid_ext, monthid_ext, trcid_ext, lineid_ext, price, amount, balamount, op1, op2, picname) FROM stdin;
\.
COPY dbo.td_transaction (regid, trctypeid, monthid, trcid, lineid, itemid, qty_1, qty_2, qty_3, qty_4, qty_5, convertion_1, convertion_2, typeid, detaildate, detailtime, addressid, detaildocnum, starttime, endtime, duration, processd, processh, processid, addressdetail, remarkd, lotno, vanno, achievement, totaldt, totalps, gsph, createby, partnerid, sjnum, sjdate, reffnum, matnum, isdelete, trctypeid_ext, monthid_ext, trcid_ext, lineid_ext, price, amount, balamount, op1, op2, picname) FROM '$$PATH$$/3103.dat';

--
-- Data for Name: td_transaction_delete; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.td_transaction_delete (regid, trctypeid, monthid, trcid, lineid, itemid, qty_1, qty_2, qty_3, qty_4, qty_5, convertion_1, convertion_2, typeid, detaildate, detailtime, addressid, detaildocnum, starttime, endtime, duration, processd, processh, processid, addressdetail, remarkd, lotno, vanno, achievement, totaldt, totalps, gsph, createby, partnerid, sjnum, sjdate, reffnum, matnum, isdelete, trctypeid_ext, monthid_ext, trcid_ext, lineid_ext, price, amount, balamount, op1, op2, picname, updatedate, updatetime, updateid) FROM stdin;
\.
COPY dbo.td_transaction_delete (regid, trctypeid, monthid, trcid, lineid, itemid, qty_1, qty_2, qty_3, qty_4, qty_5, convertion_1, convertion_2, typeid, detaildate, detailtime, addressid, detaildocnum, starttime, endtime, duration, processd, processh, processid, addressdetail, remarkd, lotno, vanno, achievement, totaldt, totalps, gsph, createby, partnerid, sjnum, sjdate, reffnum, matnum, isdelete, trctypeid_ext, monthid_ext, trcid_ext, lineid_ext, price, amount, balamount, op1, op2, picname, updatedate, updatetime, updateid) FROM '$$PATH$$/3105.dat';

--
-- Name: td_transaction_delete_regid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.td_transaction_delete_regid_seq', 1, false);


--
-- Name: td_transaction_regid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.td_transaction_regid_seq', 1, false);


--
-- Data for Name: th_order; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.th_order (regid, trctypeid, monthid, trcid, docnum, docdate, doctime, userid, userupdateid, updatetime, remarkh, isdelete) FROM stdin;
\.
COPY dbo.th_order (regid, trctypeid, monthid, trcid, docnum, docdate, doctime, userid, userupdateid, updatetime, remarkh, isdelete) FROM '$$PATH$$/3107.dat';

--
-- Name: th_order_regid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.th_order_regid_seq', 1, false);


--
-- Data for Name: th_transaction; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.th_transaction (regid, trctypeid, monthid, trcid, docnum, docdate, doctime, docdate_ext, userid, partnerid, picname, docnum_2, docdate_2, docnum_3, docdate_3, shiftid, createdate, lastupdate, userupdateid, lineid, fromareaid, remarkh, statusid, op1, op2) FROM stdin;
\.
COPY dbo.th_transaction (regid, trctypeid, monthid, trcid, docnum, docdate, doctime, docdate_ext, userid, partnerid, picname, docnum_2, docdate_2, docnum_3, docdate_3, shiftid, createdate, lastupdate, userupdateid, lineid, fromareaid, remarkh, statusid, op1, op2) FROM '$$PATH$$/3109.dat';

--
-- Name: th_transaction_regid_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.th_transaction_regid_seq', 1, false);


--
-- PostgreSQL database dump complete
--

